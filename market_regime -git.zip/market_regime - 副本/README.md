# market_regime —— 市场状态识别组件

> 多风格策略聚合系统的核心框架：把行情识别为**可解释的规范市场状态**，并输出**风格目标权重**。
> 研究标的：OKX `ETH-USDT-SWAP`，状态研究窗口 2021-01-01 → 2026-10-09（1H/4H/1D 数据均至 2020-01-01 起，供策略归因对齐）。

## 目录结构

```
market_regime/
├── market_regime/            # 核心组件 (Python 包)
│   ├── taxonomy.py           # 状态分类体系 + 风格注册表 (系统契约)
│   ├── features.py           # 因果特征工程 (趋势/波动/结构/分布/资金)
│   ├── detectors/
│   │   ├── rules.py          # 规则引擎 (可解释基线 + 迟滞状态机)
│   │   ├── hmm.py            # 高斯HMM (时序结构, 支持 walk-forward)
│   │   ├── gmm.py            # 高斯混合 (形态聚类)
│   │   ├── hybrid.py         # 三检测器共识 (多数表决 + 降级保护)
│   │   └── base.py           # 统一接口 + 隐状态→规范状态映射 (匈牙利单射)
│   ├── allocation.py         # StyleAllocator: 状态 → 风格权重 (置信度收缩/平滑/换手约束)
│   ├── strategy_registry.py  # 策略台账: 风格归属/绩效档案/状态适配度 (S1 已校准)
│   ├── trade_attribution.py  # 交易日志解析 + 状态归因 + 门控反事实
│   ├── evaluation.py         # 状态统计/转移矩阵/风格代理/门控检验
│   ├── viz.py                # 标准图组
│   ├── pipeline.py           # MarketStatePipeline (研究) + MarketStateAPI (生产)
│   └── data.py               # OKX 数据加载/聚合
├── scripts/
│   ├── fetch_okx_data.py     # OKX 历史数据抓取 (断点续传/限速)
│   ├── run_research.py       # 一键研究: 特征→检测→评估→图表 (--start 默认 2021-01-01)
│   └── run_strategy_attribution.py  # S1 交易日志 → 状态归因 → 门控反事实
├── data/
│   ├── okx/                  # 原始数据 (1H/4H/1D K线 + 资金费率)
│   ├── strategy/             # S1 交易日志 (FMZ 导出)
│   └── states/               # 状态标注输出 CSV (1D/1H + S1 逐笔对齐状态)
├── reports/                  # 研究报告 + tables_*.md + figures/
├── examples/
│   └── integration_example.py  # 聚合系统接入示例
└── tests/test_smoke.py       # 冒烟测试
```

## 快速开始

```bash
pip install pandas numpy scikit-learn scipy hmmlearn matplotlib pyarrow requests

# 1) 抓数据 (已抓好可跳过)
python scripts/fetch_okx_data.py --inst-id ETH-USDT-SWAP --bars 1H 1D --start 2021-01-01

# 2) 跑研究 (产出 reports/figures + reports/tables_*.md)
python scripts/run_research.py --bar 1D
python scripts/run_research.py --bar 1H

# 3) Strategy #1 状态归因 (需要交易日志)
python scripts/run_strategy_attribution.py --log data/strategy/S1_trade_log_fmz.csv

# 4) 冒烟测试
python tests/test_smoke.py
```

## 生产接入（多风格聚合系统）

```python
from market_regime import MarketStateAPI, StyleAllocator

api = MarketStateAPI(allocator=StyleAllocator(smooth_halflife=5, max_turnover=0.4))
api.fit(history_ohlcv)                    # >=500 根历史K线

snapshot = api.update(recent_ohlcv)       # 每根收盘后调用
# {
#   "state": "TREND_UP",                  # 规范状态
#   "confidence": 0.81,                   # 检测置信度
#   "agreement": 0.9,                     # 三检测器一致性
#   "style_weights": {"trend": 0.52, "mean_reversion": 0.03, ...}   # 风格目标权重
# }
```

## 状态分类体系（5 个规范状态）

| 状态 | 含义 | 默认风格倾向 |
| --- | --- | --- |
| TREND_UP | 上升趋势 | trend / breakout |
| TREND_DOWN | 下降趋势 | trend(空) / defensive |
| RANGE_CALM | 低波动震荡 | mean_reversion / carry |
| HIGH_VOL | 高波动/危机 | defensive / breakout |
| TRANSITION | 过渡/不确定 | 全面降敞口 |

## 设计要点

1. **无前视偏差**：所有特征因果；研究评估在样本外段进行。
2. **可解释 + 数据驱动**：规则引擎做语义锚点，HMM/GMM 发现结构，共识输出降低单一模型风险；隐状态→规范状态用「锚点占比+语义亲和度」打分 + 匈牙利单射映射，防止标签坍缩。
3. **聚合器友好**：输出统一为 `state / confidence / agreement / style_weights`，权重自带置信度收缩、EMA 平滑与换手率约束。
4. **可扩展**：状态表（taxonomy）与风格池（STYLE_PROFILES）都是注册表式设计，加状态/加风格不改检测器。

## 已知限制

- OKX 公共资金费率历史接口仅保留近期窗口（本库抓到 2026-06-29 之后约 300 条）；如需完整费率历史请接入 Tardis/CoinAPI 等数据源，`attach_funding` 直接吃 CSV 即可。
- HMM 默认研究模式为整段拟合（regime 标签是「同期」信息）；实盘增量请用 `HMMDetector(mode="walk_forward")`。

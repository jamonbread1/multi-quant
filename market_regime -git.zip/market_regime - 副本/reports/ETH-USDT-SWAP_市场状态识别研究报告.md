# ETH-USDT-SWAP 市场状态识别组件 —— 研究与开发报告

> 目标：为 **多风格策略聚合系统** 研究开发「市场状态识别」核心框架
> 标的：OKX `ETH-USDT-SWAP` 永续合约 ｜ 样本：2021-01-01 → 2026-10-09（约 5.8 年）
> 产物：可复用 Python 组件 `market_regime` + 全量状态标注数据 + 验证报告

---

## 0. 摘要 (TL;DR)

1. **数据资产已就绪**：OKX ETH-USDT-SWAP 1H K线 50,585 根、1D K线 2,108 根，2021-01-01 至 2026-10-09 连续无缺口；资金费率历史受 OKX 公共接口限制仅有近 3 个月（组件按可选增强处理）。
2. **组件核心**是「三检测器共识」状态机：
   - **规则引擎**（可解释基线，迟滞状态机抗抖动）＋ **高斯 HMM**（时序结构）＋ **GMM**（形态聚类）；
   - 隐状态→规范状态采用「锚点占比＋语义亲和度」打分与 **匈牙利单射映射**，杜绝标签坍缩；
   - 输出统一契约：`state / confidence / agreement / style_weights`。
3. **5 个规范状态**在 2021-2026 ETH 上经济含义清晰（1D 全样本）：
   `TREND_UP`（17.8%，年化 +95%，Sharpe 1.5）、`TREND_DOWN`（13.4%，年化 -202%，Sharpe -2.2）、
   `HIGH_VOL`（10.8%，波动 93%）、`RANGE_CALM`（50.6%，Sharpe 0.4）、`TRANSITION`（7.4%）。
   状态 **持续性强**（转移矩阵对角线 0.91–0.96），趋势状态平均持续 3–4 周，适合按状态做策略配置。
4. **经济价值验证**（样本外、风格代理策略门控实验）：
   - 突破（breakout）代理：Sharpe 0.12 → **0.85**，最大回撤 -112% → **-40%**（1D）；
   - 均值回归代理：Sharpe -0.48 → **+0.10**，回撤 -142% → **-42%**（1H）；
   - 趋势代理回撤显著收窄（-71% → -41%，1H）。
   即：**用状态做风格门控/权重调节，能系统性改善风险调整后收益**。
5. **接入方式**：`MarketStateAPI.fit/update` 两个方法输出状态快照与风格目标权重；权重层内置置信度收缩、EMA 平滑、换手率约束，可直接对接聚合器的资金分配模块。
6. **Strategy #1（4H 唐奇安突破，183 笔真实交易日志）状态归因完成**：持仓期走出 TREND_UP 是利润真实来源（+51.6R，PF 6.4）；**TREND_DOWN 开仓（39 笔全部空单）系统性泄漏 -6.87R**；反事实显示「TREND_DOWN 不开新仓」门控使复利终值 457→943、回撤 -59.7%→-44.6%、Sharpe 2.45→2.97。已校准该策略的 state_suitability 并给出聚合器落地配置。

---

## 1. 数据资产

| 数据集 | 文件 | 行数 | 区间 | 说明 |
| --- | --- | --- | --- | --- |
| 1H K线 | `data/okx/ETH-USDT-SWAP_1H.{csv,parquet}` | 50,585 | 2021-01-01 → 2026-10-09 | 连续无缺口，UTC 整点对齐 |
| 1D K线 | `data/okx/ETH-USDT-SWAP_1D.{csv,parquet}` | 2,108 | 2021-01-01 → 2026-10-09 | OKX 日线以 UTC+8 开盘 |
| 资金费率 | `data/okx/ETH-USDT-SWAP_funding.{csv,parquet}` | 308 | 2026-06-29 → 2026-10-09 | **接口限制**，仅近 3 个月 |
| 状态标注 | `data/states/ETH-USDT-SWAP_{1D,1H}_states.csv` | 2,068 / 50,545 | 同上（去暖机期） | 4 检测器标签＋置信度＋关键特征 |

字段：`ts, open, high, low, close, vol(张), vol_ccy(ETH), vol_ccy_quote(USDT), confirm, datetime`。
行情事实：样本起点 769 USDT，终点 2,495 USDT；区间最高 4,958.69（2025-08-24），最低 714.66（2021-01-01）。

**抓取脚本** `scripts/fetch_okx_data.py`：限速 ~3 req/s、JSONL 断点续传、429/5xx 退避重试，可复用于任意 OKX 永续。

**已知限制**：OKX 公共 `funding-rate-history` 接口目前只保留约 3 个月记录（ETH/BTC 均如此，2026-10 实测）。如需完整费率历史（carry 风格与费率特征需要），建议接 Tardis.dev / CoinAPI 等数据源，`features.attach_funding()` 直接吃相同格式 CSV。

---

## 2. 方法论

### 2.1 状态分类体系（系统契约，`taxonomy.py`）

| 状态 | code | 含义 | 典型行情 | 默认风格倾向 |
| --- | --- | --- | --- | --- |
| TREND_UP | 1 | 上升趋势 | 2021H1、2024H1 | trend 0.55 / breakout 0.25 |
| TREND_DOWN | 2 | 下降趋势 | 2022 熊市 | trend(空) 0.45 / defensive 0.20 |
| RANGE_CALM | 3 | 低波动震荡 | 2023 全年 | mean_reversion 0.40 / carry 0.35 |
| HIGH_VOL | 4 | 高波动/危机 | 2021-05、2022-11 | defensive 0.40 / breakout 0.25 |
| TRANSITION | 5 | 过渡/不确定 | 切换边缘 | 全面降敞口 0.40 |

状态表是注册表式设计：新增状态/风格不改检测器代码。风格池（`STYLE_PROFILES`）：`trend / mean_reversion / breakout / carry / defensive`。

### 2.2 因果特征（`features.py`，25+ 个）

全部特征只用 ≤t 的数据（冒烟测试含因果性断言）：

- **波动族**：`vol_20/60`、`vol_of_vol`、`vol_ratio`、Parkinson、下行波动占比、`vol_pct_252`（滚动分位）；
- **趋势族**：`trend_slope`（窗口漂移/窗口波动，无量纲）、`trend_r2`（回归质量）、`sma{20,60,120}_dist`、`adx_14`、`hh_hl_score`（高低点结构）；
- **均值回归族**：方差比 `var_ratio_5`、收益自相关 `autocorr_1`、`range_pos`；
- **分布/风险族**：偏度、峰度、`dd_120`、跳跃 z 分、Hurst 指数（R/S）；
- **资金面**（可选）：`funding_rate` 及其均线。

### 2.3 检测器（`detectors/`）

**(a) 规则引擎 `RuleBasedDetector`** —— 可解释基线兼语义锚点：

```
trend_score = (0.45·sma60_dist + 0.35·trend_slope·r² + 0.20·hh_hl) × ADX门
vol_score   = 0.7·vol_pct_252 + 0.3·vol_ratio修正
```

- 阈值在 fit 时按样本内分位数自适应校准（趋势 68% 分位、波动 75%/90% 分位），跨品种/周期免调参；
- **迟滞状态机**：状态切换需连续 3 根确认，维持门槛低于切换门槛，实测显著抑制标签抖动；
- 多空对称设计（ADX 只做强度门控、不贡献方向），避免下跌趋势系统性漏检。

**(b) HMMDetector** —— Gaussian HMM（3–6 状态 BIC 可选），特征取标准化后的收益/波动/趋势/回撤，Viterbi 解码平滑标签；支持 `walk_forward` 生产模式（滚动重拟合、严格无前视）。

**(c) GMMDetector** —— 8 维特征空间软聚类，后验概率即置信度，与 HMM 形成「形态 vs 时序」互补。

**(d) 隐状态 → 规范状态映射**（`base.map_latent_to_canonical`）：
打分 = 锚点占比 + 0.35 × 语义亲和度（质心的趋势方向/漂移符号/波动水平），再用 **匈牙利算法做单射分配**（每个规范状态至多对应一个隐状态）。此前用简单多数表决时出现过三个隐状态坍缩为 RANGE_CALM、TREND_DOWN 完全消失的问题，单射约束从机制上根治。

**(e) HybridDetector 共识**：三检测器多数表决（平票按 rules > hmm > gmm 仲裁），置信度 = 平均个体置信度 × 一致性系数；三人完全分裂（1-1-1）时方向性状态降级为 TRANSITION，提示聚合器减敞口。

### 2.4 分配层（`allocation.py`）

```
states + confidence ──► StyleAllocator ──► 风格目标权重 (每行和=1)
```

- **默认先验矩阵**：状态→风格倾向（taxonomy 的 style_hint，可整体替换）；
- **置信度收缩**：confidence 低于 floor(0.3) 全额转向 defensive，中间水平按 sqrt 曲线部分收缩；
- **EMA 平滑**（默认半衰期 6 根）＋ **单步换手上限**（默认 50%），防止状态抖动引发资金频繁迁移；
- **数据驱动升级**：`regime_weights_from_backtest(style_state_sharpe)` 把风格×状态回测矩阵转成权重矩阵，直接替换先验（见 §4.6）。

---

## 3. 实证结果：ETH-USDT-SWAP 2021-2026

![价格与状态](figures/1D_price_states.png)

**图 1**：1D 价格（对数轴）与混合共识状态。状态与行情阶段吻合度肉眼可验：2021 牛市（绿）、2021-05 与 2022 的剧烈去杠杆（橙）、2022 熊市（红）、2023 低波动震荡（蓝）、2024–2025 反复趋势（绿/红交替）、2026 横盘（蓝）。

### 3.1 状态分布与条件表现（1D）

全样本（2,068 根）：

| 状态 | 占比 | 平均持续(日) | 年化收益 | 年化波动 | Sharpe | 偏度 | 最差单日 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| RANGE_CALM | 50.6% | 21.8 | +24.3% | 63.5% | 0.38 | -0.35 | -22.9% |
| TREND_UP | 17.8% | 21.6 | **+94.9%** | 62.6% | **1.51** | -0.24 | -12.8% |
| TREND_DOWN | 13.4% | 15.4 | **-202.0%** | 90.8% | **-2.23** | -0.53 | -21.6% |
| HIGH_VOL | 10.8% | 10.7 | +81.8% | 92.8% | 0.88 | +0.39 | -20.7% |
| TRANSITION | 7.4% | 9.6 | -58.7% | 66.0% | -0.89 | -1.30 | -19.9% |

样本外（拟合窗 40% 之后，约 3.5 年）：

| 状态 | 占比 | 年化收益 | Sharpe | 最差单日 |
| --- | --- | --- | --- | --- |
| RANGE_CALM | 50.2% | -25.0% | -0.48 | -14.3% |
| TREND_UP | 19.8% | +107.8% | **1.89** | -7.1% |
| TREND_DOWN | 11.1% | -136.4% | **-1.80** | -12.3% |
| HIGH_VOL | 11.9% | +140.9% | 2.07 | -7.3% |
| TRANSITION | 6.9% | -15.8% | -0.34 | -5.4% |

> 解读：样本外含 2024–2025 大反弹，`HIGH_VOL`（多出现在急跌后的高波动修复段）呈正收益；但其波动高达 68–134%、单日最差 -7%~-20%，对杠杆策略是明确的「降杠杆」信号，而非「做多」信号。`TREND_DOWN` 在两个窗口都是稳定的负收益区，是空头/对冲/防御风格的主战场。`TRANSITION` 持续时间短、方向不明，聚合器应主动降敞口。

### 3.2 状态持续性与转移结构（1D 样本外）

![转移矩阵](figures/1D_transition.png)

| 从 \ 到 | HIGH_VOL | RANGE_CALM | TRANSITION | TREND_DOWN | TREND_UP |
| --- | --- | --- | --- | --- | --- |
| HIGH_VOL | **0.92** | 0.06 | 0.00 | 0.00 | 0.02 |
| RANGE_CALM | 0.01 | **0.96** | 0.01 | 0.01 | 0.01 |
| TRANSITION | 0.01 | 0.06 | **0.91** | 0.02 | 0.00 |
| TREND_DOWN | 0.00 | 0.03 | 0.03 | **0.94** | 0.00 |
| TREND_UP | 0.01 | 0.03 | 0.00 | 0.00 | **0.96** |

- 对角线 0.91–0.96：状态 **高度粘滞**，日频下趋势状态平均持续 17–27 天，状态→策略配置有足够「收费时间」；
- 趋势与震荡几乎不直接互转（≤3%），切换多经 TRANSITION/波动放大完成——这正是配置层需要迟滞与平滑的原因；
- 1H 尺度同样成立（对角线 0.81–0.95），小时级趋势状态平均持续 10–12 小时。

### 3.3 核心验证：风格代理的「状态门控」实验

实验设计：用简单策略代理代表各风格（MA 交叉=趋势、布林带回归=均值回归、Donchian=突破），比较 **无条件运行** 与 **仅在目标状态激活**（门控）的样本外表现。

![门控对比](figures/1D_gated_sharpe.png)

**1D 样本外**：

| 风格代理 | Sharpe 无条件 | Sharpe 门控 | 最大回撤无条件 | 最大回撤门控 | 激活占比 |
| --- | --- | --- | --- | --- | --- |
| trend | 0.95 | 0.74 | -42.9% | -34.4% | 30.9% |
| mean_reversion | -0.48 | -0.59 | -146.1% | -101.7% | 50.2% |
| **breakout** | **0.12** | **0.85** | **-112.4%** | **-40.2%** | 31.7% |

**1H 样本外**：

| 风格代理 | Sharpe 无条件 | Sharpe 门控 | 最大回撤无条件 | 最大回撤门控 | 激活占比 |
| --- | --- | --- | --- | --- | --- |
| trend | 0.24 | 0.24 | -71.1% | **-41.4%** | 32.2% |
| **mean_reversion** | **-0.48** | **+0.10** | -141.9% | **-42.4%** | 51.9% |
| breakout | 0.13 | 0.28 | -117.7% | **-52.2%** | 21.7% |

结论：

1. **突破风格收益提升最大**（0.12→0.85）：突破策略只应在趋势/高波动状态激活，震荡期是它的绞肉机（-0.64 Sharpe）；
2. **均值回归从亏损转正**（1H，-0.48→+0.10）且三个周期门控后 **回撤全面腰斩以上**；
3. 趋势代理是多头口径（MA 金叉持有、死叉空仓），门控到 TREND_UP+TREND_DOWN 后收益被摊薄但回撤改善——实盘趋势策略含空头腿，门控到 TREND_DOWN 时反而是收益来源（见下表 trend 在 TREND_DOWN 的 Sharpe 为正）。

### 3.4 风格×状态匹配矩阵（Sharpe，1D 样本外）

![风格×状态](figures/1D_style_state.png)

| 代理 \ 状态 | RANGE_CALM | TREND_DOWN | TREND_UP | HIGH_VOL | TRANSITION |
| --- | --- | --- | --- | --- | --- |
| trend | 0.48 | —* | **1.67** | **1.54** | — |
| mean_reversion | -0.84 | 0.22 | -1.79 | 0.98 | **1.85** |
| breakout | -0.64 | -0.86 | **1.74** | **1.14** | 0.99 |

\* 代理为多头口径、样本量不足处不填。矩阵呈现清晰的「风格-状态对角线」：趋势/突破吃 TREND_UP 与 HIGH_VOL，均值回归避开趋势段、在切换噪声段反而最好。这张矩阵就是聚合器「何时给哪个风格加权」的实证依据。

### 3.5 特征分布与状态语义

![特征箱线图](figures/1D_feature_box.png)

各状态在特征空间可分性良好：`vol_pct_252` 区分 HIGH_VOL，`trend_slope/adx_14/dd_120` 区分趋势方向，`autocorr_1` 区分震荡——这保证了无监督检测器（HMM/GMM）能稳定复现规则引擎的语义（三检测器共识率约 70%，见 `summary_*.json`）。

### 3.6 分配层输出示例

![分配权重](figures/1D_allocation.png)

权重面板自带「状态跟随 + 抗抖动」：状态切换时风格权重以 EMA 平滑迁移并受换手上限约束。**先验 vs 数据驱动**——用 §3.4 矩阵生成的权重（`regime_weights_from_backtest`，已导出 `reports/empirical_regime_weights_1D.csv`）会把 RANGE_CALM 段的 trend 权重抬高（该窗口内趋势代理在震荡段反而录得正 Sharpe），提示：

- **建议采用先验与实证的混合**：`W = 0.5·W_prior + 0.5·W_empirical`，或用 `adaptive_sharpe` 滚动微调；
- 代理策略是「风格的最小代表」而非真实策略，权重矩阵应以你实盘各风格子策略的真实绩效滚动重估（接口已预留 `adaptive_sharpe`）。

---

### 3.7 Strategy #1 状态归因（真实交易日志，2020-01 → 2026-09）

> 对象：**4H 海龟式通道突破**（48 根通道 + 3ATR 吊灯止损 + ADX>15 过滤，多空双向，LEV=1.5/0.65）
> 数据：FMZ 交易日志 **183 笔**（多 93 / 空 90，合计 **+45.9R**），逐笔对齐 4H 市场状态（时区自动校准 UTC+8→UTC）
> 口径说明：归因以 **R 倍数**为主（不受权益统计口径影响）。日志重放的逐笔收益复利终值约 457U（累加口径 371U），与提供表的 237.82U 存在差异，推断为版本（v1.1-bugfix）或权益/费用统计口径不同；年度方向性与提供表完全一致（2022/2023 亏损、2024 大赚）。

**① 按开仓状态归因**（门控决策口径）：

| 状态 | n | 占比 | 胜率 | 均笔R | 合计R | PF | t值 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| RANGE_CALM | 100 | 54.6% | 50.0% | +0.38 | **+38.02** | 2.15 | 2.54 |
| TREND_UP | 13 | 7.1% | 46.2% | +0.80 | +10.46 | 2.45 | 1.30 |
| HIGH_VOL | 20 | 10.9% | 40.0% | +0.18 | +3.65 | 1.51 | 0.76 |
| TRANSITION | 11 | 6.0% | 54.5% | +0.06 | +0.60 | 0.59 | 0.22 |
| **TREND_DOWN** | 39 | 21.3% | **28.2%** | **-0.18** | **-6.87** | 0.51 | -1.33 |

**② 按持仓期间多数状态归因**（盈利的真实来源）：

| 状态 | n | 胜率 | 均笔R | 合计R | PF |
| --- | --- | --- | --- | --- | --- |
| **TREND_UP** | 49 | **67.3%** | +1.05 | **+51.61** | **6.40** |
| HIGH_VOL | 26 | 53.8% | +0.40 | +10.49 | 2.84 |
| TREND_DOWN | 51 | 43.1% | -0.02 | -1.20 | 1.01 |
| TRANSITION | 16 | 25.0% | -0.10 | -1.67 | 0.21 |
| RANGE_CALM | 41 | 19.5% | -0.33 | **-13.37** | 0.50 |

两个口径放在一起，这个策略的状态画像就完整了：

- **开仓集中在 RANGE_CALM（55%）不是巧合**——突破策略天然在「安静期」进场（利润 +38R），①里 RANGE_CALM 的高贡献是「突破前置」特征，不代表震荡市好赚钱；
- **利润真正兑现于持仓期走出 TREND_UP**（②中 +51.6R、PF 6.4、胜率 67%）：Top-8 盈利交易中 5 笔是「RANGE_CALM 开仓 → 持仓进入 TREND_UP」的教科书式突破盈利路径；
- **系统性泄漏在 TREND_DOWN 开仓**：这 39 笔 **全部是空单**（熊市做空突破），合计 **-6.87R、胜率 28%**——被熊市反弹反复轧；其余状态的空单合计 +16.4R，说明不是「空头腿没用」，而是**该状态下不该开空**；
- **持仓滞留震荡会出血**（②中 RANGE_CALM -13.4R、胜率 19.5%）：进场后没能走出趋势、在震荡里被吊灯止损磨掉的单子。

**③ 状态门控反事实**（跳过指定状态的开仓；权益为逐笔收益复利，log 日志口径）：

| 门控方案 | 保留笔数 | 复利终值(U) | 累计收益 | trade-Sharpe | 最大回撤 | 胜率 | 合计R |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 实际 (全部) | 183 | 457 | 1424% | 2.45 | -59.7% | 44.3% | 45.9 |
| **跳过 TREND_DOWN 开仓** | 144 | **943** | **3045%** | **2.97** | **-44.6%** | **48.6%** | **52.7** |
| 跳过 TREND_DOWN+TRANSITION | 133 | 848 | 2727% | 2.97 | -44.6% | 48.1% | 52.1 |
| 跳过 RANGE_CALM | 83 | 46 | 52% | 0.70 | -60.6% | 37.3% | 7.8 |
| 仅 TREND_UP 开仓 | 13 | 61 | 104% | 1.30 | **-11.6%** | 46.2% | 10.5 |

![S1 门控权益曲线](figures/S1_equity_gating.png)

**一句话结论：该策略加一条状态门「TREND_DOWN 状态不开新仓」，在胜率、Sharpe、回撤、期望全面改善的前提下收益翻倍**（457→943）；而「跳过 RANGE_CALM」会毁掉这个策略（457→46）——再次证明状态门控必须以**逐笔归因**为依据，不能拍脑袋。风险预算极端紧张时，「仅 TREND_UP」是 Calmar 最优的收缩方案（maxDD 仅 -11.6%）。

![S1 状态盈亏](figures/S1_state_pnl.png)

![S1 交易与状态](figures/S1_trades_states.png)

**④ 落地到聚合系统**：

1. **开仓门控**（改资金分配层即可，不动策略本体）：`state ∈ {TREND_DOWN, TRANSITION}` 时对该策略停止新增配置/降杠杆到 0.05–0.35 档；`RANGE_CALM / HIGH_VOL / TREND_UP` 正常配置（0.70–0.90 档）——已写入 `strategy_registry.S1.state_suitability`；
2. **给策略侧（你的另一个 agent）的出场改进建议**（仅供参考，本组件未改策略）：持仓期状态转为 RANGE_CALM 且停留超过 N 根未走出趋势的单子是主要出血点（-13.4R），可考虑状态感知的时间止损/保本离场；
3. **杠杆选择**：两档 LEV 的 Sharpe/Calmar 相同（等比缩放），聚合层建议以 **LEV=0.65 档**（maxDD 36.5%）作为该策略默认风险预算口径，把 1.5 档留给「TREND_DOWN 门控」生效后的进取配置；
4. **后续策略接入**：同一套 `trade_attribution` 流水线对每个新策略的日志直接复用（解析→对齐→归因→门控→校准 state_suitability）。

---

## 4. 聚合系统接入指南

```python
from market_regime import MarketStateAPI, StyleAllocator, regime_weights_from_backtest

api = MarketStateAPI(allocator=StyleAllocator(smooth_halflife=5, max_turnover=0.4))
api.fit(history_ohlcv)                     # >=500 根历史K线 (1H/4H/1D 均可)

snap = api.update(recent_ohlcv)            # 每根收盘后调用
# {
#   "state": "RANGE_CALM",
#   "confidence": 0.53,
#   "agreement": 0.67,
#   "style_weights": {"trend": 0.20, "mean_reversion": 0.13, ...},  # 目标权重, 和=1
#   "ts": "2026-10-08 16:00:00+00:00"
# }
```

对接约定：

1. **聚合器资金分配**：`style_weights` 即风格层目标权重（行和=1），乘以总风险预算得各风格子策略的资金上限；
2. **状态感知风控**：`state == "TRANSITION"` 或 `confidence < 0.5` 时建议叠加总杠杆折扣；`HIGH_VOL` 下降低趋势/套利杠杆、提高现金比；
3. **绩效归因**：`api.states()` 返回历史状态序列，可按状态切片归因（`evaluation.state_statistics`）；
4. **自定义**：
   - 换风格池 → `StyleAllocator(styles=[...], regime_weights=自定义矩阵)`;
   - 换状态定义 → 扩展 `taxonomy.States`（保持输出命名即可）;
   - 高频防前视 → `HMMDetector(mode="walk_forward", window=8000, refit_every=500)`;
   - 多品种 → 同一组件对每个 instId 独立运行，或在特征层增加横截面相对强弱。

完整可运行示例：`examples/integration_example.py`。

---

## 5. 工程与复现

```bash
pip install pandas numpy scikit-learn scipy hmmlearn matplotlib pyarrow requests

python scripts/fetch_okx_data.py --inst-id ETH-USDT-SWAP --bars 1H 1D --start 2021-01-01
python scripts/run_research.py --bar 1D     # -> reports/figures/1D_*.png + tables_1D.md
python scripts/run_research.py --bar 1H     # -> reports/figures/1H_*.png + tables_1H.md
python tests/test_smoke.py                  # 冒烟测试 (特征因果性/权重归一/换手约束/API)
python examples/integration_example.py      # 接入演示
```

全部统计表（可直接引用）：`reports/tables_1D.md`、`reports/tables_1H.md`；检测器一致性与状态占比：`reports/summary_{1D,1H}.json`。

---

## 6. 局限与迭代路线

| # | 局限 | 建议迭代 |
| --- | --- | --- |
| 1 | 资金费率历史仅 3 个月（OKX 接口限制） | 接 Tardis/CoinAPI 补全 2021 起费率；carry 风格权重目前无实证输入 |
| 2 | 研究模式 HMM 整段拟合（regime 是同期信息） | 实盘用 `walk_forward` 模式；已内置于 `HMMDetector` |
| 3 | 代理策略非实盘策略 | 用真实子策略收益重估 `style_state_sharpe` → `regime_weights_from_backtest` |
| 4 | 阈值校准在拟合窗一次性完成 | 可升级为滚动重校准（每季度）；检测器已支持增量 `update` |
| 5 | 单品种验证 | 扩展 BTC-SOL 等做多品种稳健性检验；可加跨品种相对强弱特征 |
| 6 | 状态粒度固定 5 类 | 若策略需要更细（如「趋势末端」「盘整末段挤压」），在 taxonomy 加状态、用 GMM 6–8 成分细分 |
| 7 | 特征以日频/小时频为主 | 加订单簿/持仓量特征（OKX rubik 统计接口）提升 HIGH_VOL 预警提前量 |
| 8 | S1 日志重放权益与提供表口径有差（457 vs 237.82U 复利） | 归因已用 R 口径规避；如需对账请提供权益曲线或结算明细，由策略侧 agent 核对版本差异 |
| 9 | 门控反事实假设「跳过交易不改变后续仓位大小」 | 状态门控落地在资金分配层（降杠杆而非硬跳过）时该假设更接近真实 |

---

## 附录 A：目录结构

```
market_regime/
├── market_regime/          # 核心组件包 (taxonomy/features/detectors/allocation/evaluation/viz/pipeline/data)
├── scripts/                # fetch_okx_data.py / run_research.py
├── data/okx/               # 原始K线与资金费率
├── data/states/            # 状态标注 CSV (1D/1H)
├── reports/                # 本报告 + tables_*.md + figures/
├── examples/               # integration_example.py
└── tests/test_smoke.py
```

## 附录 B：当前状态快照（截至 2026-10-08 收盘，1D）

- 状态：`RANGE_CALM`（低波动震荡）｜ 置信度 0.53 ｜ 近 30 日主状态 `TREND_UP`（26/30 天）
- 含义解读：2026 年 8–9 月的上升段已结束，市场进入低波动盘整；聚合器配置上宜从趋势风格向均值回归/carry 迁移，并保留趋势底仓等待突破确认。
- 对 Strategy #1 的含义：RANGE_CALM 是其突破进场的常规环境（state_suitability 0.70），正常配置；若状态转为 TREND_DOWN 则停止新增配置。

## 附录 C：Strategy #1 交易日志与状态标注

- 原始日志：`data/strategy/S1_trade_log_fmz.csv`（FMZ 导出，含心跳/风控/逐笔结算行）
- 逐笔+状态标注：`data/states/S1_trades_with_states.csv`（183 笔 × 进出场/盈亏U/R/开仓状态/持仓多数状态）
- 归因表：`reports/tables_strategy_S1.md` ｜ 汇总：`reports/summary_S1.json`
- 复现：`python scripts/run_strategy_attribution.py`

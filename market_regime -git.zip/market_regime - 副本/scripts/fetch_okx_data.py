#!/usr/bin/env python3
"""
OKX 历史数据抓取脚本
====================
抓取 ETH-USDT-SWAP (可配置) 的:
  1. 历史K线  (GET /api/v5/market/history-candles)  —— bar=1H / 1D
  2. 资金费率历史 (GET /api/v5/public/funding-rate-history)

特性:
  - 断点续传: 增量写入 JSONL 缓存, 重启后从最旧已抓取时间戳继续向前翻页
  - 限速: 默认 ~3 req/s (OKX 公共接口限频 20 req / 2s), 429/5xx 自动退避重试
  - 输出: CSV + Parquet 到 data/okx/

用法:
  python scripts/fetch_okx_data.py --inst-id ETH-USDT-SWAP --bars 1H 1D --start 2021-01-01
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone

import pandas as pd
import requests

BASE = "https://www.okx.com"
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.dirname(HERE), "data", "okx")

CANDLE_COLS = ["ts", "open", "high", "low", "close", "vol", "vol_ccy", "vol_ccy_quote", "confirm"]
FUNDING_COLS = ["funding_time", "funding_rate", "realized_rate", "funding_time_next", "funding_rate_next"]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "market-regime-research/1.0"})


def get(path: str, params: dict, max_retries: int = 8) -> list:
    """带重试/退避的 GET, 返回 data 列表; 失败抛异常。"""
    url = BASE + path
    delay = 1.0
    for attempt in range(max_retries):
        try:
            r = SESSION.get(url, params=params, timeout=30)
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(delay + (attempt * 0.5))
                delay = min(delay * 1.6, 30)
                continue
            r.raise_for_status()
            obj = r.json()
            if obj.get("code") != "0":
                # 部分业务错误(如参数边界)直接返回空, 不重试
                msg = obj.get("msg", "")
                if "data" in obj and not obj["data"]:
                    return []
                raise RuntimeError(f"OKX API error code={obj.get('code')} msg={msg}")
            return obj.get("data", []) or []
        except (requests.RequestException, json.JSONDecodeError) as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(delay)
            delay = min(delay * 1.6, 30)
    return []


# ---------------------------------------------------------------- candles ---

def load_cache_jsonl(path: str) -> list[dict]:
    rows: list[dict] = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    return rows


def fetch_candles(inst_id: str, bar: str, start_ms: int, sleep_s: float) -> pd.DataFrame:
    """
    从当前时刻向前翻页抓取 history-candles, 直到覆盖 start_ms。
    返回按时间升序的 DataFrame。
    """
    os.makedirs(DATA_DIR, exist_ok=True)
    cache_path = os.path.join(DATA_DIR, f"{inst_id}_{bar}.jsonl")

    rows = load_cache_jsonl(cache_path)
    seen = {int(r["ts"]) for r in rows}
    oldest = min(seen) if seen else None

    # 若缓存已覆盖 start_ms 且最新数据距今 < 2 根K线, 仍继续向前补缺口
    print(f"[{inst_id} {bar}] cache rows={len(rows)} oldest={oldest}", flush=True)

    after = oldest  # None 表示从最新开始
    empty_streak = 0
    total_new = 0

    with open(cache_path, "a", encoding="utf-8") as f:
        while True:
            params = {"instId": inst_id, "bar": bar, "limit": "100"}
            if after is not None:
                params["after"] = str(after)
            data = get("/api/v5/market/history-candles", params)
            if not data:
                empty_streak += 1
                if empty_streak >= 3:
                    break
                time.sleep(sleep_s)
                continue
            empty_streak = 0

            batch_min_ts = None
            for rec in data:
                ts = int(rec[0])
                if ts in seen:
                    continue
                row = dict(zip(CANDLE_COLS, rec))
                row["ts"] = ts
                for k in ("open", "high", "low", "close", "vol", "vol_ccy", "vol_ccy_quote"):
                    row[k] = float(row[k])
                row["confirm"] = int(row["confirm"])
                rows.append(row)
                seen.add(ts)
                f.write(json.dumps(row) + "\n")
                total_new += 1
                if batch_min_ts is None or ts < batch_min_ts:
                    batch_min_ts = ts

            if batch_min_ts is not None:
                after = batch_min_ts

            if after is not None and after <= start_ms:
                break

            time.sleep(sleep_s)
            if total_new and total_new % 1000 == 0:
                f.flush()
                ts_s = datetime.fromtimestamp(after / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
                print(f"[{inst_id} {bar}] fetched {total_new} new rows, cursor -> {ts_s}", flush=True)

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df = df.drop_duplicates(subset="ts").sort_values("ts").reset_index(drop=True)
    df["ts"] = df["ts"].astype("int64")
    df["datetime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
    # 只保留 start_ms 之后
    df = df[df["ts"] >= start_ms].reset_index(drop=True)
    return df


# ---------------------------------------------------------------- funding ---

def fetch_funding(inst_id: str, start_ms: int, sleep_s: float) -> pd.DataFrame:
    os.makedirs(DATA_DIR, exist_ok=True)
    cache_path = os.path.join(DATA_DIR, f"{inst_id}_funding.jsonl")
    rows = load_cache_jsonl(cache_path)
    seen = {int(r["funding_time"]) for r in rows}
    oldest = min(seen) if seen else None
    print(f"[{inst_id} funding] cache rows={len(rows)}", flush=True)

    after = oldest
    empty_streak = 0
    total_new = 0
    with open(cache_path, "a", encoding="utf-8") as f:
        while True:
            params = {"instId": inst_id, "limit": "100"}
            if after is not None:
                params["after"] = str(after)
            data = get("/api/v5/public/funding-rate-history", params)
            if not data:
                empty_streak += 1
                if empty_streak >= 3:
                    break
                time.sleep(sleep_s)
                continue
            empty_streak = 0
            batch_min = None
            for rec in data:
                ft = int(rec["fundingTime"])
                if ft in seen:
                    continue
                row = {
                    "funding_time": ft,
                    "funding_rate": float(rec["fundingRate"]),
                    "realized_rate": float(rec.get("realizedRate") or rec["fundingRate"]),
                }
                rows.append(row)
                seen.add(ft)
                f.write(json.dumps(row) + "\n")
                total_new += 1
                if batch_min is None or ft < batch_min:
                    batch_min = ft
            if batch_min is not None:
                after = batch_min
            if after is not None and after <= start_ms:
                break
            time.sleep(sleep_s)

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df = df.drop_duplicates(subset="funding_time").sort_values("funding_time").reset_index(drop=True)
    df = df[df["funding_time"] >= start_ms].reset_index(drop=True)
    df["datetime"] = pd.to_datetime(df["funding_time"], unit="ms", utc=True)
    return df


def save(df: pd.DataFrame, name: str) -> None:
    if df.empty:
        print(f"[save] {name}: empty, skip", flush=True)
        return
    csv_path = os.path.join(DATA_DIR, f"{name}.csv")
    pq_path = os.path.join(DATA_DIR, f"{name}.parquet")
    df.to_csv(csv_path, index=False)
    try:
        df.to_parquet(pq_path, index=False)
    except Exception as e:  # pragma: no cover
        print(f"[save] parquet failed for {name}: {e}", flush=True)
    print(f"[save] {name}: {len(df)} rows "
          f"({df.iloc[0, 0]} .. {df.iloc[-1, 0]}) -> {csv_path}", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inst-id", default="ETH-USDT-SWAP")
    ap.add_argument("--bars", nargs="+", default=["1H", "1D"])
    ap.add_argument("--start", default="2021-01-01")
    ap.add_argument("--sleep", type=float, default=0.33, help="每请求间隔秒 (~3 req/s)")
    ap.add_argument("--skip-funding", action="store_true")
    args = ap.parse_args()

    start_dt = datetime.fromisoformat(args.start).replace(tzinfo=timezone.utc)
    start_ms = int(start_dt.timestamp() * 1000)

    print(f"== OKX fetch {args.inst_id} bars={args.bars} start={args.start} "
          f"({start_ms}) ==", flush=True)

    for bar in args.bars:
        t0 = time.time()
        df = fetch_candles(args.inst_id, bar, start_ms, args.sleep)
        save(df, f"{args.inst_id}_{bar}")
        print(f"[done] {bar}: {len(df)} rows in {time.time() - t0:.1f}s", flush=True)

    if not args.skip_funding:
        t0 = time.time()
        df = fetch_funding(args.inst_id, start_ms, args.sleep)
        save(df, f"{args.inst_id}_funding")
        print(f"[done] funding: {len(df)} rows in {time.time() - t0:.1f}s", flush=True)

    print("ALL DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
研究主脚本: 数据 -> 特征 -> 检测器 -> 评估 -> 图表/表格
用法:
    python scripts/run_research.py --bar 1D
    python scripts/run_research.py --bar 1H
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from market_regime import (  # noqa: E402
    MarketStatePipeline, StyleAllocator, load_funding, load_ohlcv,
)
from market_regime import viz  # noqa: E402
from market_regime.taxonomy import States, default_regime_style_matrix  # noqa: E402

FIG_DIR = os.path.join(ROOT, "reports", "figures")
OUT_DIR = os.path.join(ROOT, "data", "states")


def md_table(df: pd.DataFrame, floatfmt: str = "{:.2f}") -> str:
    def fmt(v):
        if isinstance(v, float):
            return floatfmt.format(v)
        return str(v)
    cols = [df.index.name or ""] + [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |",
             "| " + " | ".join(["---"] * len(cols)) + " |"]
    for idx, row in df.iterrows():
        lines.append("| " + " | ".join([fmt(idx)] + [fmt(v) for v in row.values]) + " |")
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bar", default="1D")
    ap.add_argument("--inst-id", default="ETH-USDT-SWAP")
    ap.add_argument("--train-frac", type=float, default=0.4)
    ap.add_argument("--start", default="2021-01-01",
                    help="研究窗口起点 (报告口径默认 2021-01-01, 保证可复现)")
    args = ap.parse_args()

    os.makedirs(FIG_DIR, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    tag = args.bar

    print(f"== load {args.inst_id} {args.bar} from {args.start} ==", flush=True)
    ohlcv = load_ohlcv(args.inst_id, args.bar)
    ohlcv = ohlcv[ohlcv["datetime"] >= pd.Timestamp(args.start, tz="UTC")].reset_index(drop=True)
    funding = load_funding(args.inst_id)
    print(f"ohlcv rows={len(ohlcv)}  {ohlcv['datetime'].min()} -> {ohlcv['datetime'].max()}")
    if funding is not None:
        print(f"funding rows={len(funding)}  {funding['datetime'].min()} -> {funding['datetime'].max()}")

    pipe = MarketStatePipeline(detector="hybrid", train_frac=args.train_frac,
                               bar=args.bar, allocator=StyleAllocator())
    res = pipe.run(ohlcv, funding)

    feats = res.features
    cons = res.consensus
    # consensus 的 index 是 features/ohlcv 的子集 (跳过暖机期)
    ohlcv_w = ohlcv.loc[cons.index].reset_index(drop=True)
    states_full = cons["state"].astype(str).reset_index(drop=True)

    # ---------------- 保存状态输出 ----------------
    out = ohlcv_w.copy()
    out["state_rules"] = res.states["rules"]["state"].astype(str).values
    out["state_hmm"] = res.states["hmm"]["state"].astype(str).values
    out["state_gmm"] = res.states["gmm"]["state"].astype(str).values
    out["state_hybrid"] = cons["state"].astype(str).values
    out["confidence"] = cons["confidence"].values
    if "agreement" in cons.columns:
        out["agreement"] = cons["agreement"].values
    for c in ["vol_20", "vol_pct_252", "trend_slope", "trend_r2", "adx_14",
              "dd_120", "autocorr_1", "var_ratio_5"]:
        if c in feats.columns:
            out[c] = feats.loc[cons.index, c].values
    out_path = os.path.join(OUT_DIR, f"{args.inst_id}_{tag}_states.csv")
    out.to_csv(out_path, index=False)
    print(f"[save] {out_path} ({len(out)} rows)")

    # ---------------- 图 ----------------
    print("[fig] price + states ...", flush=True)
    close = ohlcv_w["close"]
    close.index = out["datetime"].values
    s_plot = states_full.copy()
    s_plot.index = out["datetime"].values
    viz.plot_price_with_states(close, s_plot,
                               os.path.join(FIG_DIR, f"{tag}_price_states.png"),
                               title=f"ETH-USDT-SWAP ({tag}) 价格与市场状态 2021-2026")
    viz.plot_state_strip(s_plot, os.path.join(FIG_DIR, f"{tag}_state_strip.png"),
                         confidence=cons["confidence"].values)
    print("[fig] features / transition ...", flush=True)
    viz.plot_feature_box(feats.loc[cons.index], states_full.values,
                         os.path.join(FIG_DIR, f"{tag}_feature_box.png"))
    viz.plot_transition_matrix(res.tables["transition"],
                               os.path.join(FIG_DIR, f"{tag}_transition.png"))
    print("[fig] proxies ...", flush=True)
    viz.plot_gated_bars(res.tables["gated_test"],
                        os.path.join(FIG_DIR, f"{tag}_gated_sharpe.png"))
    viz.plot_style_state_matrix(res.tables["style_state_sharpe"],
                                os.path.join(FIG_DIR, f"{tag}_style_state.png"))
    viz.plot_allocation(res.weights,
                        os.path.join(FIG_DIR, f"{tag}_allocation.png"))

    # ---------------- 表 (markdown) ----------------
    tabs = res.tables
    md = []
    md.append(f"# {args.inst_id} {tag} — 状态统计与验证\n")
    md.append("## 全样本状态统计\n" + md_table(tabs["state_stats_full"].round(2)))
    md.append("\n## 样本外 (train 60% 之后) 状态统计\n" + md_table(tabs["state_stats_oos"].round(2)))
    md.append("\n## 状态持续\n" + md_table(tabs["durations"].round(1)))
    md.append("\n## 转移矩阵 (样本外, 行归一)\n" + md_table(tabs["transition"].round(3)))
    md.append("\n## 风格代理: 无条件 vs 状态门控 (样本外)\n" + md_table(tabs["gated_test"].round(2)))
    md.append("\n## 风格代理 × 状态 Sharpe (样本外)\n" + md_table(tabs["style_state_sharpe"].round(2)))
    md_path = os.path.join(ROOT, "reports", f"tables_{tag}.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n\n".join(md))
    print(f"[save] {md_path}")

    # 检测器一致性
    agree = (res.states["rules"]["state"].astype(str).values ==
             res.states["hmm"]["state"].astype(str).values).mean()
    agree2 = (res.states["rules"]["state"].astype(str).values ==
              res.states["gmm"]["state"].astype(str).values).mean()
    summary = {
        "bar": tag,
        "rows": len(out),
        "range": [str(out["datetime"].min()), str(out["datetime"].max())],
        "rules_hmm_agree": round(float(agree), 4),
        "rules_gmm_agree": round(float(agree2), 4),
        "state_share": states_full.value_counts(normalize=True).round(4).to_dict(),
    }
    with open(os.path.join(ROOT, "reports", f"summary_{tag}.json"), "w") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("DONE", flush=True)


if __name__ == "__main__":
    main()

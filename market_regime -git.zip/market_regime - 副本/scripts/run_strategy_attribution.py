#!/usr/bin/env python3
"""
Strategy #1 (4H 唐奇安突破) 的市场状态归因
==========================================
1. 4H K线 (2020-01 起, 对齐策略回测窗口) -> 混合共识状态
2. 解析 FMZ 交易日志 -> 逐笔交易 (不复现策略, 只用日志)
3. 状态归因 + 状态门控反事实 -> reports/tables_strategy_S1.md + figures/

用法:
    python scripts/run_strategy_attribution.py --log /path/to/tradelog.csv
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from market_regime import MarketStatePipeline  # noqa: E402
from market_regime.data import load_ohlcv  # noqa: E402
from market_regime import trade_attribution as ta  # noqa: E402

FIG_DIR = os.path.join(ROOT, "reports", "figures")
OUT_DIR = os.path.join(ROOT, "data", "states")
DEFAULT_LOG = os.path.join(ROOT, "data", "strategy", "S1_trade_log_fmz.csv")


def md_table(df: pd.DataFrame) -> str:
    def fmt(v):
        if isinstance(v, float):
            return f"{v:.2f}" if abs(v) < 1e6 else f"{v:.0f}"
        return str(v)
    cols = [df.index.name or ""] + [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |",
             "| " + " | ".join(["---"] * len(cols)) + " |"]
    for idx, row in df.iterrows():
        lines.append("| " + " | ".join([fmt(idx)] + [fmt(v) for v in row.values]) + " |")
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default=DEFAULT_LOG)
    ap.add_argument("--inst-id", default="ETH-USDT-SWAP")
    ap.add_argument("--initial", type=float, default=30.0)
    args = ap.parse_args()

    os.makedirs(FIG_DIR, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)

    # ---------- 1. 4H 状态 ----------
    ohlcv = load_ohlcv(args.inst_id, "4H")
    print(f"4H: {len(ohlcv)} bars {ohlcv['datetime'].iloc[0]} -> {ohlcv['datetime'].iloc[-1]}")
    pipe = MarketStatePipeline(detector="hybrid", train_frac=0.4, bar="4H")
    res = pipe.run(ohlcv)
    cons = res.consensus
    ohlcv_w = ohlcv.loc[cons.index].reset_index(drop=True)
    states_full = cons["state"].astype(str).reset_index(drop=True)
    print("状态分布 (4H, 全样本):")
    print(states_full.value_counts(normalize=True).round(3).to_string())

    # ---------- 2. 解析日志 ----------
    trades = ta.parse_fmoz_log(args.log)
    beats = trades.attrs.get("beats")
    if beats is not None and len(beats) > 10:
        off = ta.infer_tz_offset_hours(beats, ohlcv)
        print(f"[tz] 心跳推断日志时间偏移: {off:+.0f}h (相对UTC)")
        trades = ta.parse_fmoz_log(args.log, tz_offset_h=off)
    print(f"解析交易: {len(trades)} 笔  {trades['entry_time'].min()} -> {trades['exit_time'].max()}")
    print(f"  多/空: {(trades['side']=='long').sum()}/{(trades['side']=='short').sum()}  "
          f"合计 R: {trades['pnl_r'].sum():.1f}  合计 U: {trades['pnl_u'].sum():.1f}")

    # ---------- 3. 状态对齐 ----------
    close = ohlcv_w["close"].copy()
    close.index = pd.DatetimeIndex(ohlcv_w["datetime"])
    st_series = pd.Series(states_full.values,
                          index=pd.DatetimeIndex(ohlcv_w["datetime"]))
    # align 用的 states 需要与 ohlcv 行对应 (RangeIndex)
    trades = ta.align_trades_to_states(trades, states_full, ohlcv_w)
    trades_out = os.path.join(OUT_DIR, "S1_trades_with_states.csv")
    trades.drop(columns=[c for c in ("beats",) if c in trades.columns]).to_csv(trades_out, index=False)
    print(f"[save] {trades_out}")

    # ---------- 4. 归因 ----------
    attr_entry = ta.attribute_trades_to_states(trades, "state_entry")
    attr_maj = ta.attribute_trades_to_states(trades, "state_majority")
    print("\n=== 状态归因 (按开仓状态) ===")
    print(attr_entry.round(2).to_string())

    # 年度对账
    t2 = trades.copy()
    t2["year"] = pd.to_datetime(t2["exit_time"]).dt.year
    yearly = t2.groupby("year").agg(
        n=("pnl_u", "size"), sum_u=("pnl_u", "sum"), sum_r=("pnl_r", "sum"),
        win=("pnl_u", lambda s: (s > 0).mean() * 100),
    ).round(1)

    # 多空分解
    by_side = ta.attribute_trades_to_states(trades, "side")

    # ---------- 5. 门控反事实 ----------
    profiles = [
        ("实际 (全部交易)", dict(skip_states=[])),
        ("跳过 TREND_DOWN 开仓", dict(skip_states=["TREND_DOWN"])),
        ("跳过 TREND_DOWN+TRANSITION 开仓", dict(skip_states=["TREND_DOWN", "TRANSITION"])),
        ("跳过 RANGE_CALM", dict(skip_states=["RANGE_CALM"])),
        ("跳过 TRANSITION", dict(skip_states=["TRANSITION"])),
        ("跳过 RANGE_CALM+TRANSITION", dict(skip_states=["RANGE_CALM", "TRANSITION"])),
        ("仅 TREND_UP+HIGH_VOL", dict(keep_states=["TREND_UP", "HIGH_VOL"])),
        ("仅 TREND_* (双向趋势)", dict(keep_states=["TREND_UP", "TREND_DOWN"])),
        ("仅 TREND_UP", dict(keep_states=["TREND_UP"])),
    ]
    rows, curves = [], {"实际 (全部交易)": ta.trade_equity_curve(trades, args.initial)}
    actual_perf = ta._trades_perf(trades, args.initial)
    for label, kw in profiles[1:]:
        cf = ta.gating_counterfactual(trades, label=label, initial=args.initial, **kw)
        g = cf["gated"]
        rows.append({
            "profile": label,
            "n_kept": cf["n_trades"], "n_skip": cf["skip_trades"],
            "final_equity": g["final_equity"], "cum_ret%": g["cum_ret_pct"],
            "trade_sharpe": g["trade_sharpe"], "maxdd%": g["maxdd_pct"],
            "win%": g["win_rate"], "sum_R": g["sum_R"],
        })
        curves[label] = ta.trade_equity_curve(cf["kept_trades"], args.initial)
    gate_df = pd.DataFrame(rows).set_index("profile")
    base_row = {
        "profile": "实际 (全部交易)", "n_kept": len(trades), "n_skip": 0,
        "final_equity": actual_perf["final_equity"], "cum_ret%": actual_perf["cum_ret_pct"],
        "trade_sharpe": actual_perf["trade_sharpe"], "maxdd%": actual_perf["maxdd_pct"],
        "win%": actual_perf["win_rate"], "sum_R": actual_perf["sum_R"],
    }
    gate_df = pd.concat([pd.DataFrame([base_row]).set_index("profile"), gate_df])

    # ---------- 6. 图 ----------
    print("[fig] ...", flush=True)
    ta.plot_equity_curves(curves, os.path.join(FIG_DIR, "S1_equity_gating.png"))
    ta.plot_state_pnl_bars(attr_entry, os.path.join(FIG_DIR, "S1_state_pnl.png"))
    ta.plot_trades_on_states(close, st_series, trades,
                             os.path.join(FIG_DIR, "S1_trades_states.png"),
                             title="Strategy#1 交易进出点与市场状态 (4H, 2020-2026)")

    # ---------- 7. 表 ----------
    md = [f"# Strategy #1 (4H唐奇安突破) 市场状态归因\n",
          f"数据: 交易日志 {os.path.basename(args.log)}, {len(trades)} 笔, "
          f"{trades['entry_time'].min():%Y-%m-%d} → {trades['exit_time'].max():%Y-%m-%d}\n",
          "## 状态归因 (按开仓时刻状态)\n" + md_table(attr_entry.round(2)),
          "\n## 状态归因 (按持仓期间多数状态)\n" + md_table(attr_maj.round(2)),
          "\n## 多空分解\n" + md_table(by_side.round(2)),
          "\n## 年度分解 (日志口径)\n" + md_table(yearly),
          "\n## 状态门控反事实 (跳过指定状态的开仓)\n" + md_table(gate_df.round(2)),
          ]
    md_path = os.path.join(ROOT, "reports", "tables_strategy_S1.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n\n".join(md))
    print(f"[save] {md_path}")

    summary = {
        "n_trades": len(trades),
        "window": [str(trades["entry_time"].min()), str(trades["exit_time"].max())],
        "log_equity_final": actual_perf["final_equity"],
        "by_state_entry": attr_entry.round(3).to_dict(),
        "gating": gate_df.round(3).to_dict(orient="index"),
    }
    with open(os.path.join(ROOT, "reports", "summary_S1.json"), "w") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)
    print("DONE")


if __name__ == "__main__":
    main()

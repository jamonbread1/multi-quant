"""
数据加载与聚合 (data)
=====================
- load_ohlcv:  读取 OKX 抓取产物 (CSV/Parquet), 时间索引整理, 频率聚合
- load_funding: 资金费率
- aggregate:   1H -> 4H/1D 聚合 (标准 OHLCV 重采样)
"""
from __future__ import annotations

import os
from typing import Optional

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA_DIR = os.path.join(os.path.dirname(HERE), "data", "okx")


def load_ohlcv(inst_id: str = "ETH-USDT-SWAP", bar: str = "1H",
               data_dir: str = DEFAULT_DATA_DIR) -> pd.DataFrame:
    """加载K线; 优先 parquet, 兜底 csv。返回 datetime 升序 DataFrame (index=RangeIndex)。"""
    for ext in ("parquet", "csv"):
        path = os.path.join(data_dir, f"{inst_id}_{bar}.{ext}")
        if os.path.exists(path):
            df = pd.read_parquet(path) if ext == "parquet" else pd.read_csv(path)
            break
    else:
        raise FileNotFoundError(f"No data for {inst_id} {bar} in {data_dir}")

    df = df.copy()
    if "datetime" not in df.columns:
        df["datetime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    df = df.sort_values("ts").drop_duplicates(subset="ts").reset_index(drop=True)
    # 只保留已完结K线
    if "confirm" in df.columns:
        df = df[df["confirm"] == 1].reset_index(drop=True)
    return df


def load_funding(inst_id: str = "ETH-USDT-SWAP",
                 data_dir: str = DEFAULT_DATA_DIR) -> Optional[pd.DataFrame]:
    for ext in ("parquet", "csv"):
        path = os.path.join(data_dir, f"{inst_id}_funding.{ext}")
        if os.path.exists(path):
            df = pd.read_parquet(path) if ext == "parquet" else pd.read_csv(path)
            if df.empty:
                return None
            df = df.sort_values("funding_time").drop_duplicates(subset="funding_time")
            return df.reset_index(drop=True)
    return None


def aggregate(df: pd.DataFrame, rule: str = "4H") -> pd.DataFrame:
    """
    标准OHLCV重采样。rule 如 '4H' / '1D'。
    注意 OKX 日线以 UTC+8 开盘, 这里聚合为 UTC 边界, 与1H数据自洽。
    """
    x = df.set_index("datetime")
    agg = {
        "open": "first", "high": "max", "low": "min", "close": "last",
        "vol": "sum", "vol_ccy": "sum", "vol_ccy_quote": "sum",
    }
    out = x.resample(rule).agg({k: v for k, v in agg.items() if k in x.columns}).dropna()
    out = out.reset_index()
    out["ts"] = (out["datetime"].astype("int64") // 10 ** 6).astype("int64")
    return out

"""
策略注册表 (Strategy Registry)
===============================
多风格策略聚合系统的策略层台账: 登记每个实盘/回测策略的
风格归属、绩效档案、风险特征与「状态适配档案」。

Strategy #1: 4H 唐奇安通道突破 (海龟式)
  入场: 收盘价 > 前 48 根 4H 最高价 (8天通道), 仅多头/空仓
  出场: 3×ATR 吊灯止损 (以及平仓信号)
  特征: 低胜率(44%) + 强右尾(8笔贡献全部净利) + 震荡上涨市为主要亏损源
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class StrategyProfile:
    strat_id: str
    name: str
    style: str                      # 归属风格池: trend / mean_reversion / breakout / carry / defensive
    logic: str                      # 逻辑简述 (不含敏感参数可自行脱敏)
    bar: str                        # 交易周期
    direction: str                  # long_short / long_flat / ...
    levers: List[float]             # 回测杠杆档位
    stats: Dict[str, Dict[str, float]] = field(default_factory=dict)   # {lev: {指标: 值}}
    yearly: Dict[int, Dict[str, float]] = field(default_factory=dict)  # {年: {strategy_ret, eth_ret}}
    risk_notes: List[str] = field(default_factory=list)
    # 状态适配先验 (0~1): 该策略在各状态下的预期可玩度, 由归因结果或先验填写
    state_suitability: Dict[str, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Strategy #1 —— 4H 唐奇安突破 (2020-01 ~ 2026-10, 6.75 年, 184 笔)
# 数据来源: 用户提供的 FMZ/自建回测绩效表 (主窗口)
# ---------------------------------------------------------------------------
DONCHIAN_48_4H = StrategyProfile(
    strat_id="S1_donchian48_4h",
    name="4H 唐奇安通道突破 (48根通道 + 3ATR 吊灯止损)",
    style="breakout",
    logic="海龟式通道突破: 48根4H通道(8天)突破进场, 3×ATR吊灯止损离场, ADX>15 过滤门; "
          "多空双向 (多头突破/空头击穿); 无波动收缩前提, 纯价格突破",
    bar="4H",
    direction="long_short",
    levers=[1.5, 0.65],
    stats={
        "LEV=1.5": {
            "期末权益(初始30U)": 237.82, "累计收益%": 692.7, "CAGR%": 36.2,
            "年化波动%": 53.65, "Sharpe": 0.84, "最大回撤%": 68.8, "Calmar": 0.53,
            "胜率%": 44.0, "PF": 1.35, "均笔%": 1.84, "中位笔%": -1.73,
            "t统计量": 2.07, "水下占比%": 88.1, "最长连亏": 8, "成本/毛收益%": 15.3,
        },
        "LEV=0.65": {
            "期末权益(初始30U)": 94.25, "累计收益%": 214.2, "CAGR%": 18.6,
            "年化波动%": 23.69, "Sharpe": 0.84, "最大回撤%": 36.5, "Calmar": 0.51,
            "胜率%": 44.0, "PF": 1.48, "均笔%": 0.79, "中位笔%": -0.74,
            "t统计量": 2.07, "水下占比%": 84.3, "最长连亏": 8, "成本/毛收益%": 12.3,
        },
    },
    yearly={
        2021: {"strategy_lev15%": 6.5, "eth%": 412.7},
        2022: {"strategy_lev15%": -25.3, "eth%": -66.8},
        2023: {"strategy_lev15%": -18.3, "eth%": 91.2},
        2024: {"strategy_lev15%": 226.3, "eth%": 48.7},
        # 2020 / 2025 / 2026 年度值未在提供材料中列出, 待交易日志补齐
    },
    risk_notes=[
        "Sharpe/Calmar 在两档杠杆下完全相同 (等比例缩放的数学后果); 杠杆选择只取决于可承受回撤",
        "右尾依赖极端: 去掉最赚的 8 笔 (4.3%), 剩余 176 笔均笔 -0.070% —— 净期望几乎全部来自少数大趋势",
        "88.1% 交易笔处于水下; 最长连亏 8 笔; 中位单笔为负 (LEV=1.5: -1.73%)",
        "震荡上涨市是主要亏损源 (2023: ETH +91.2%, 策略 -18.3%) —— 假突破反复止损",
        "2022 深熊也亏 (-25.3%): 反弹中的假突破反复止损消耗",
        "多空双向: 日志含开空记录 (开仓 空), 与多头突破共用通道逻辑",
        "入场带 ADX>15 过滤门 (启动行: don48/adx15/stop3); 版本 v1.1-bugfix",
        "成本/毛收益 12~15%: 换手摩擦对本策略是显著负项",
    ],
    # 状态适配度 (0~1): 聚合器向该策略配置资金的意愿 —— 已用 183 笔真实交易日志归因校准
    # 证据: 持仓期间走出 TREND_UP 的交易贡献 +51.6R (PF 6.4); TREND_DOWN 开仓 39 笔全部为空单,
    #       合计 -6.87R (胜率28%) —— 熊市做空突破被反弹轧; 门控「跳过 TREND_DOWN 开仓」后
    #       复利终值 457→943, maxDD -59.7%→-44.6%, trade-Sharpe 2.45→2.97 (log口径)。
    state_suitability={
        "TREND_UP": 0.90,      # 持仓开发最好的状态 (held-state +51.6R)
        "HIGH_VOL": 0.70,      # 开仓 +3.65R / 持仓 +10.5R
        "RANGE_CALM": 0.70,    # 开仓 +38R (突破前置利润池); 但持仓滞留震荡会出血
        "TRANSITION": 0.35,    # 开仓微利, 持仓段亏损
        "TREND_DOWN": 0.05,    # 唯一明确应关闭的状态: 空单突破系统性亏损
    },
)


REGISTRY: Dict[str, StrategyProfile] = {
    DONCHIAN_48_4H.strat_id: DONCHIAN_48_4H,
}


def register(profile: StrategyProfile) -> None:
    REGISTRY[profile.strat_id] = profile


def get(strat_id: str) -> StrategyProfile:
    return REGISTRY[strat_id]


def summary_frame():
    """注册表摘要 (DataFrame): 供聚合系统/报告使用。"""
    import pandas as pd
    rows = []
    for p in REGISTRY.values():
        row = {
            "strat_id": p.strat_id, "name": p.name, "style": p.style,
            "bar": p.bar, "direction": p.direction,
            "levers": "/".join(str(x) for x in p.levers),
        }
        for lev, st in p.stats.items():
            key = lev.replace("LEV=", "lev")
            row[f"{key}_CAGR%"] = st.get("CAGR%")
            row[f"{key}_Sharpe"] = st.get("Sharpe")
            row[f"{key}_MaxDD%"] = st.get("最大回撤%")
            row[f"{key}_Calmar"] = st.get("Calmar")
        rows.append(row)
    return pd.DataFrame(rows)

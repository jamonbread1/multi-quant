"""
风格分配器 (StyleAllocator)
============================
市场状态识别组件与「多风格策略聚合系统」之间的契约层:

    states (检测器输出) -> 目标风格权重 (trend / mean_reversion / breakout / carry / defensive)

设计要点:
  1. 默认权重矩阵: 每个状态对应一组风格目标权重 (States.style_hint)
  2. 置信度缩放: confidence 低时权重向 defensive 收缩
  3. 权重平滑: EMA 平滑 + 换手率约束, 避免状态抖动导致策略资金频繁迁移
  4. 自适应层(可选): 用各风格在该状态下的历史滚动 Sharpe 对默认权重做贝叶斯式微调

输出: index=时间, columns=风格名, 值=目标权重 (每行和为 1)
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd

from .taxonomy import STYLE_PROFILES, default_regime_style_matrix


class StyleAllocator:
    def __init__(
        self,
        regime_weights: Optional[pd.DataFrame] = None,
        conf_floor: float = 0.3,
        defensive_style: str = "defensive",
        smooth_halflife: float = 6.0,
        max_turnover: Optional[float] = 0.5,
        styles: Optional[list] = None,
    ):
        """
        regime_weights: 行=状态名, 列=风格名, 值=目标权重 (自动归一化)
        conf_floor: 置信度低于此值时完全偏向 defensive
        smooth_halflife: 权重 EMA 平滑半衰期 (单位=K线根数); 0 表示不平滑
        max_turnover:   单步最大换手 (L1 距离/2); None 表示不限制
        """
        rw = regime_weights if regime_weights is not None else default_regime_style_matrix()
        self.regime_weights = rw.div(rw.sum(axis=1), axis=0)  # 归一化
        self.conf_floor = conf_floor
        self.defensive_style = defensive_style
        self.smooth_halflife = smooth_halflife
        self.max_turnover = max_turnover
        self.styles = styles or list(rw.columns)

    # ------------------------------------------------------------------
    def _confidence_blend(self, w: np.ndarray, conf: float) -> np.ndarray:
        """置信度低时向 defensive 权重收缩 (sqrt 曲线, 中等置信度不过度惩罚)。"""
        d = np.zeros(len(self.styles))
        d[self.styles.index(self.defensive_style)] = 1.0
        k = float(np.clip((conf - self.conf_floor) / (1 - self.conf_floor + 1e-12), 0, 1)) ** 0.5
        return k * w + (1 - k) * d

    def allocate(
        self,
        states: pd.Series,
        confidence: Optional[pd.Series] = None,
        adaptive_sharpe: Optional[pd.DataFrame] = None,
    ) -> pd.DataFrame:
        """
        states:       规范状态序列 (index=时间)
        confidence:   检测置信度序列
        adaptive_sharpe: 可选, index=时间, columns=风格, 值=各风格滚动 Sharpe
                         (正则化后作为权重微调因子, 不覆盖默认矩阵)
        """
        states = states.astype(str)
        conf = confidence if confidence is not None else pd.Series(1.0, index=states.index)
        W = self.regime_weights

        rows = []
        for t, st in states.items():
            if st in W.index:
                w = W.loc[st, self.styles].values.astype(float)
            else:
                w = W.loc["TRANSITION", self.styles].values.astype(float)
            w = self._confidence_blend(w, float(conf.loc[t]))
            rows.append(w)
        out = pd.DataFrame(rows, index=states.index, columns=self.styles)

        # 自适应微调: w_i *= 1 + lam * tanh(sharpe_i)
        if adaptive_sharpe is not None:
            lam = 0.35
            factor = np.tanh(adaptive_sharpe.reindex(out.index).fillna(0.0).values) * lam + 1.0
            out = out * factor
            out = out.div(out.sum(axis=1), axis=0)

        # 平滑
        if self.smooth_halflife and self.smooth_halflife > 0:
            alpha = 1 - 0.5 ** (1 / self.smooth_halflife)
            out = out.ewm(alpha=alpha).mean()
            out = out.div(out.sum(axis=1), axis=0)

        # 换手率约束 (逐行投影到 L1 球)
        if self.max_turnover is not None:
            prev = None
            capped = []
            for i in range(len(out)):
                w = out.iloc[i].values.astype(float)
                if prev is not None:
                    diff = w - prev
                    turn = 0.5 * np.abs(diff).sum()
                    if turn > self.max_turnover:
                        w = prev + diff * (self.max_turnover / turn)
                        w = np.clip(w, 0, 1)
                        w = w / (w.sum() + 1e-12)
                capped.append(w)
                prev = w
            out = pd.DataFrame(capped, index=out.index, columns=out.columns)

        return out

    # ------------------------------------------------------------------
    def expected_style_sharpe(self, weights: pd.DataFrame,
                              style_returns: pd.DataFrame) -> pd.Series:
        """给定风格收益矩阵 (index=时间, columns=风格), 计算组合加权收益序列。"""
        common = weights.index.intersection(style_returns.index)
        r = (weights.loc[common] * style_returns.loc[common]).sum(axis=1)
        return r


def regime_weights_from_backtest(
    style_state_sharpe: pd.DataFrame,
    defensive_boost: float = 2.0,
    min_w: float = 0.02,
) -> pd.DataFrame:
    """
    从「风格×状态 Sharpe 矩阵」(evaluation.state_conditional_proxy_matrix 产物,
    行=风格, 列=状态) 生成数据驱动的 regime->style 权重矩阵 (行=状态, 列=风格):
      w_i ∝ max(sharpe_i, 0)^1.5 + min_w; defensive 在 HIGH_VOL/TRANSITION 行加倍。
    可直接传入 StyleAllocator(regime_weights=...) 替换默认先验。
    """
    S = style_state_sharpe.copy().fillna(0.0).T  # -> 行=状态, 列=风格
    W = np.clip(S.values.astype(float), 0, None) ** 1.5 + min_w
    W = pd.DataFrame(W, index=S.index, columns=S.columns)
    for st in ("HIGH_VOL", "TRANSITION"):
        if st in W.index and "defensive" in W.columns:
            W.loc[st, "defensive"] *= defensive_boost
    W = W.div(W.sum(axis=1), axis=0)
    return W

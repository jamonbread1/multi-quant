"""
market_regime —— 市场状态识别组件 (多风格策略聚合系统核心框架)
================================================================
快速上线:
    from market_regime import MarketStateAPI, MarketStatePipeline, StyleAllocator
"""
from .allocation import StyleAllocator, regime_weights_from_backtest
from .data import aggregate, load_funding, load_ohlcv
from .detectors import GMMDetector, HMMDetector, HybridDetector, RuleBasedDetector
from .features import build_features
from .pipeline import MarketStateAPI, MarketStatePipeline, PipelineResult
from .taxonomy import STYLE_PROFILES, States, default_regime_style_matrix

__version__ = "0.1.0"
__all__ = [
    "MarketStateAPI", "MarketStatePipeline", "PipelineResult",
    "StyleAllocator", "regime_weights_from_backtest", "States", "STYLE_PROFILES", "default_regime_style_matrix",
    "RuleBasedDetector", "HMMDetector", "GMMDetector", "HybridDetector",
    "build_features", "load_ohlcv", "load_funding", "aggregate",
]

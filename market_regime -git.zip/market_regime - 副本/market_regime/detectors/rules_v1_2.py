"""
规则引擎检测器 (RuleBasedDetector) v1.2
=========================================
在 v1.1 基础上修复 DEF3 (置信度校准)。v1.1 的修复方案被实测证伪, 本版换方案。

版本变更 (相对 v1.1):
    [FIX3-重做] 置信度标定的 horizon 定义错误
        v1.1 用「t+1 单根bar 的方向命中率」标定 confidence, 实测 Spearman
        = -0.031, 与 v1.0 的 -0.036 无实质差异 (均落在噪声范围内)。
        诊断 (run_def3_failure_diag_v1_0.py) 揭示根因:
            各状态的 t+1 方向命中率极差仅 4.4pp
            (TREND_UP 54.1% / TREND_DOWN 52.2% / HIGH_VOL 49.8% / RANGE 51.5%),
            即【状态在单根bar尺度上本就没有方向预测力】。
        这是信息不存在, 不是实现缺陷 —— 任何映射都无法造出区分度。

        本版改为: confidence 反映【该状态在未来 horizon 根bar上的经济含义强度】,
        而非下一根涨跌。horizon 默认 30 根 (4H ≈ 5日), 与状态验证中
        TREND_UP 后5日 t=7.23 的有效尺度一致。

        标定量: 每状态的历史年化收益绝对值 / 该状态历史年化波动
                 = |Sharpe|, 再映射到 [0.35, 0.95]。
                 含义: 「该状态在过去, 走出来的行情强度」。

口径契约 (与 v1.0/v1.1 完全一致, 未改动任何已验证的执行语义):
    趋势分 trend_score = 方向项(对称) × ADX 确认门
    波动分 vol_score   = 0.7*vol_pct_252 + 0.3*vol_ratio 修正
    迟滞: 连续 confirm_bars 根才允许切换
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

from ..taxonomy import States
from .base import BaseDetector, make_result


class RuleBasedDetector(BaseDetector):
    name = "rules"
    VERSION = "1.2"

    def __init__(
        self,
        trend_thresh: Optional[float] = None,
        confirm_bars: int = 3,
        vol_crisis_pct: Optional[float] = None,
        vol_high_pct: Optional[float] = None,
        calibrate: bool = True,
        trans_low_frac: float = 0.6,
        trans_vol_frac: float = 0.8,
        calibrate_conf: bool = True,
        conf_horizon: int = 30,        # [FIX3] 置信度标定的 horizon (根bar)
        conf_bars_per_year: float = 6 * 365,
    ):
        self.trend_thresh = trend_thresh
        self.confirm_bars = confirm_bars
        self.vol_crisis_pct = vol_crisis_pct
        self.vol_high_pct = vol_high_pct
        self.calibrate = calibrate
        self.trans_low_frac = trans_low_frac
        self.trans_vol_frac = trans_vol_frac
        self.calibrate_conf = calibrate_conf
        self.conf_horizon = conf_horizon
        self.conf_bars_per_year = conf_bars_per_year
        self.scores_: Optional[pd.DataFrame] = None
        self.state_conf_: Optional[dict] = None

    # ------------------------------------------------------------------
    def _compute_scores(self, X: pd.DataFrame) -> pd.DataFrame:
        """与 v1.0/v1.1 逐字一致, 未改动任何分项权重。"""
        sc = pd.DataFrame(index=X.index)
        direction = (
            0.45 * X["sma60_dist"].clip(-3, 3)
            + 0.35 * (X["trend_slope"] * X["trend_r2"]).clip(-3, 3)
            + 0.20 * X["hh_hl_score"].clip(-1, 1)
        )
        adx_gate = 0.35 + 0.65 * ((X["adx_14"] - 12) / 18).clip(0, 1)
        sc["trend_score"] = direction * adx_gate
        sc["vol_score"] = (
            0.7 * X["vol_pct_252"].fillna(0.5)
            + 0.3 * (X["vol_ratio"] - 1).clip(-1, 3) / 3
        ).clip(0, 1)
        sc["mr_score"] = (
            0.5 * (1 - X["trend_r2"]).clip(0, 1)
            + 0.5 * (1 - X["var_ratio_5"].clip(0.5, 1.5) / 1.5)
        )
        return sc

    # ------------------------------------------------------------------
    def fit(self, X: pd.DataFrame, y_anchor: Optional[pd.Series] = None) -> "RuleBasedDetector":
        sc = self._compute_scores(X)
        self.scores_ = sc
        if self.calibrate:
            t = sc["trend_score"].abs()
            self.trend_thresh_ = float(t.quantile(0.68)) if self.trend_thresh is None else self.trend_thresh
            v = sc["vol_score"].dropna()
            self.vol_high_pct_ = float(v.quantile(0.75)) if self.vol_high_pct is None else self.vol_high_pct
            self.vol_crisis_pct_ = float(v.quantile(0.90)) if self.vol_crisis_pct is None else self.vol_crisis_pct
        else:
            self.trend_thresh_ = float(self.trend_thresh or 0.5)
            self.vol_high_pct_ = float(self.vol_high_pct or 0.65)
            self.vol_crisis_pct_ = float(self.vol_crisis_pct or 0.92)

        if self.calibrate_conf:
            states, strength, _ = self._decode(X, sc)
            self.state_conf_ = self._calibrate_confidence(X, states)
        return self

    # ------------------------------------------------------------------
    def _decode(self, X: pd.DataFrame, sc: pd.DataFrame):
        n = len(X)
        trend = sc["trend_score"].values
        vol = sc["vol_score"].values
        ret20 = X["ret_20"].values
        adx = X["adx_14"].values

        t_th = self.trend_thresh_
        v_hi = self.vol_high_pct_
        v_cr = self.vol_crisis_pct_
        t_lo = t_th * self.trans_low_frac
        v_lo = v_hi * self.trans_vol_frac

        states = np.full(n, "RANGE_CALM", dtype=object)
        strength = np.zeros(n)
        switched = np.zeros(n, dtype=bool)

        cur = "RANGE_CALM"
        pending = None
        pending_cnt = 0
        for i in range(n):
            t, v = trend[i], vol[i]
            if np.isnan(t) or np.isnan(v):
                states[i], strength[i] = cur, 0.3
                continue

            if v >= v_cr and (np.isnan(ret20[i]) or ret20[i] < 0):
                cand, s = "HIGH_VOL", v
            elif v >= v_hi and abs(t) < t_th:
                cand, s = "HIGH_VOL", v
            elif t >= t_th and adx[i] >= 18:
                cand, s = "TREND_UP", t / (t_th + 1e-12) - 1
            elif t <= -t_th and adx[i] >= 18:
                cand, s = "TREND_DOWN", -t / (t_th + 1e-12) - 1
            elif abs(t) < t_lo and v_lo <= v < v_hi:       # [FIX1] TRANSITION
                cand, s = "TRANSITION", 1 - abs(t) / (t_lo + 1e-12)
            else:
                cand, s = "RANGE_CALM", 1 - abs(t) / (t_th + 1e-12)

            if cand == cur:
                pending, pending_cnt = None, 0
                states[i], strength[i] = cur, s
            else:
                if pending == cand:
                    pending_cnt += 1
                else:
                    pending, pending_cnt = cand, 1
                if pending_cnt >= self.confirm_bars:
                    cur, pending, pending_cnt = cand, None, 0
                    states[i], strength[i] = cur, s
                    switched[i] = True
                else:
                    states[i], strength[i] = cur, 0.4
        return states, strength, switched

    # ------------------------------------------------------------------
    def _calibrate_confidence(self, X: pd.DataFrame, states: np.ndarray) -> dict:
        """
        [FIX3] confidence = 该状态「未来 horizon 根bar上的行情强度」。

        标定量: |年化收益| / 年化波动 = |Sharpe|, 映射到 [0.35, 0.95]。
        含义: 该状态历史上走出来的行情强度, 而非下一根涨跌方向。

        因果性: 状态判定只用 <=t 的特征; horizon 收益仅用于 fit 期的标定常数,
                不参与任何状态判定, 故不构成前视偏差。
        """
        if "close" not in X.columns:
            return {}
        close = X["close"].astype(float).values
        h = self.conf_horizon
        bpy = self.conf_bars_per_year
        conf: dict = {}
        for s in States.names():
            idx = np.where(states == s)[0]
            idx = idx[idx + h < len(close)]
            if len(idx) < 50:
                conf[s] = 0.5
                continue
            fwd = np.log(close[idx + h] / close[idx])
            fwd = fwd[~np.isnan(fwd)]
            if len(fwd) < 50:
                conf[s] = 0.5
                continue
            # 年化 (horizon 重叠, 用 sqrt(h) 做时间缩放的稳健近似)
            ann_mu = fwd.mean() * (bpy / h) * h
            ann_sd = fwd.std(ddof=1) * np.sqrt(bpy / h) * h
            # 更稳的口径: 直接用单次 horizon 收益的 t 统计量绝对值
            tstat = abs(fwd.mean() / (fwd.std(ddof=1) / np.sqrt(len(fwd))))
            # 映射: |t| 0 -> 0.5, 3 -> 0.95
            conf[s] = float(np.clip(0.35 + min(tstat, 3.0) / 3.0 * 0.6, 0.35, 0.95))
        return conf

    # ------------------------------------------------------------------
    def detect(self, X: pd.DataFrame) -> pd.DataFrame:
        sc = self.scores_ if self.scores_ is not None else self._compute_scores(X)
        if not hasattr(self, "trend_thresh_"):
            self.fit(X)

        states, strength, switched = self._decode(X, sc)
        n = len(X)

        conf = np.zeros(n)
        base = self.state_conf_ or {}
        for i in range(n):
            s = states[i]
            base_c = base.get(str(s), 0.5)
            if np.isnan(strength[i]):
                conf[i] = 0.3
                continue
            # 按 strength 连续调节, 保证 confidence 是 bar 级连续量
            adj = np.clip((strength[i] - 0.5) * 0.12, -0.12, 0.12)
            conf[i] = float(np.clip(base_c + adj, 0.3, 0.95))
        conf[switched] *= 0.9
        conf = np.clip(conf, 0.0, 1.0)

        res = make_result(X.index, list(states), conf)
        res["trend_score"] = sc["trend_score"].values
        res["vol_score"] = sc["vol_score"].values
        res["detector_version"] = self.VERSION
        return res
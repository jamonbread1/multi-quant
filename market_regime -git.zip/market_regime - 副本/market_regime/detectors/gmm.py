"""
高斯混合模型检测器 (GMMDetector)
================================
在特征空间做软聚类 (GMM), 用后验概率给出状态与置信度。

特点:
  - 比 HMM 更强调「形态聚类」而不考虑转移结构, 与 HMM 形成互补
  - 隐状态 -> 规范状态映射同 HMM (锚点优先, 语义兜底)
  - 置信度 = 最大后验概率
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture

from .base import BaseDetector, make_result, map_latent_to_canonical

DEFAULT_FEATURES = [
    "ret_1", "vol_20", "vol_ratio", "trend_slope", "trend_r2",
    "vol_pct_252", "dd_120", "autocorr_1",
]


class GMMDetector(BaseDetector):
    name = "gmm"

    def __init__(self, n_components: int = 5, feature_cols: Optional[list] = None,
                 random_state: int = 42):
        self.n_components = n_components
        self.feature_cols = feature_cols or DEFAULT_FEATURES
        self.random_state = random_state
        self.model_ = None
        self.mapping_ = {}

    def fit(self, X: pd.DataFrame, y_anchor: Optional[pd.Series] = None) -> "GMMDetector":
        cols = [c for c in self.feature_cols if c in X.columns]
        Zdf = X[cols].astype(float)
        self.mu_ = Zdf.mean()
        self.sd_ = Zdf.std().replace(0, np.nan)
        Z = ((Zdf - self.mu_) / (self.sd_ + 1e-12)).fillna(0.0).values

        self.model_ = GaussianMixture(
            n_components=self.n_components, covariance_type="full",
            random_state=self.random_state, n_init=3, max_iter=300,
        )
        self.model_.fit(Z)
        latent = self.model_.predict(Z)
        self.mapping_ = map_latent_to_canonical(
            latent, X, y_anchor,
            vol_col="vol_20", ret_col="ret_1", trend_col="trend_slope",
        )
        return self

    def detect(self, X: pd.DataFrame) -> pd.DataFrame:
        cols = [c for c in self.feature_cols if c in X.columns]
        Zdf = X[cols].astype(float)
        Z = ((Zdf - self.mu_) / (self.sd_ + 1e-12)).fillna(0.0).values
        latent = self.model_.predict(Z)
        post = self.model_.predict_proba(Z)
        conf = post.max(axis=1)
        states = [self.mapping_.get(int(l), "TRANSITION") for l in latent]
        return make_result(X.index, states, conf, extra={"latent": latent})

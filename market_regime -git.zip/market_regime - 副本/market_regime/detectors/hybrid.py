"""
混合共识检测器 (HybridDetector)
===============================
规则引擎(可解释/锚点) + HMM(时序结构) + GMM(形态聚类) 三者共识。

融合规则:
  - 多数表决决定状态; 票数相同时按优先级 (rules > hmm > gmm) 取高优先级
  - 置信度 = 平均个体置信度 × 一致性系数 (agree=1.0, 2/3=0.75, 分裂=0.45)
  - 一致性过低 (<0.5) 且状态为趋势时降级为 TRANSITION, 提示聚合器减敞口

输出额外列: vote_rules / vote_hmm / vote_gmm / agree
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

from ..taxonomy import States
from .base import BaseDetector, make_result
from .gmm import GMMDetector
from .hmm import HMMDetector
from .rules import RuleBasedDetector


class HybridDetector(BaseDetector):
    name = "hybrid"

    def __init__(
        self,
        rules: Optional[RuleBasedDetector] = None,
        hmm: Optional[HMMDetector] = None,
        gmm: Optional[GMMDetector] = None,
        demote_low_agree: bool = True,
    ):
        self.rules = rules or RuleBasedDetector()
        self.hmm = hmm or HMMDetector(n_components=4, select_by_bic=False)
        self.gmm = gmm or GMMDetector(n_components=5)
        self.demote_low_agree = demote_low_agree
        self._parts: dict = {}

    def fit(self, X: pd.DataFrame, y_anchor: Optional[pd.Series] = None) -> "HybridDetector":
        # 规则检测器作为锚点来源与投票成员
        r = self.rules.fit(X).detect(X)
        anchor = r["state"].astype(str)
        self._parts["rules"] = r
        self.hmm.fit(X, y_anchor=anchor)
        self.gmm.fit(X, y_anchor=anchor)
        return self

    def detect(self, X: pd.DataFrame) -> pd.DataFrame:
        r = self._parts.get("rules") or self.rules.detect(X)
        h = self.hmm.detect(X)
        g = self.gmm.detect(X)

        votes = pd.DataFrame({
            "rules": r["state"].astype(str).values,
            "hmm": h["state"].astype(str).values,
            "gmm": g["state"].astype(str).values,
        }, index=X.index)
        confs = pd.DataFrame({
            "rules": r["confidence"].values,
            "hmm": h["confidence"].values,
            "gmm": g["confidence"].values,
        }, index=X.index)

        # 多数表决 (平票按优先级)
        prio = {"rules": 0, "hmm": 1, "gmm": 2}
        states, agree, conf = [], [], []
        vals = votes.values
        cvals = confs.values
        col_idx = {m: votes.columns.get_loc(m) for m in ("rules", "hmm", "gmm")}
        for i in range(len(X)):
            row = vals[i]
            names, counts = np.unique(row, return_counts=True)
            top = counts.max()
            winners = names[counts == top]
            if len(winners) == 1:
                st = winners[0]
            else:
                # 平票: 按优先级 rules > hmm > gmm, 取该成员所投的胜出票
                st = winners[0]
                for m in ("rules", "hmm", "gmm"):
                    if row[col_idx[m]] in winners:
                        st = row[col_idx[m]]
                        break
            a = top / 3.0
            c = float(np.mean([cvals[i, 0], cvals[i, 1], cvals[i, 2]])) * (0.45 + 0.55 * a)
            # 仅当三人完全分裂 (1-1-1) 时才把方向性状态降级为 TRANSITION
            if self.demote_low_agree and top == 1 and st in ("TREND_UP", "TREND_DOWN", "HIGH_VOL"):
                st = "TRANSITION"
            states.append(st)
            agree.append(a)
            conf.append(min(1.0, c))

        out = make_result(X.index, states, conf)
        out["vote_rules"] = votes["rules"].values
        out["vote_hmm"] = votes["hmm"].values
        out["vote_gmm"] = votes["gmm"].values
        out["agree"] = agree
        return out

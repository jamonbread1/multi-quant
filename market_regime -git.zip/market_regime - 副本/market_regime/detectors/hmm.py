"""
高斯隐马尔可夫检测器 (HMMDetector)
==================================
用 Gaussian HMM 对特征序列建模, Viterbi 平滑解码市场状态。

要点:
  - 特征: 标准化后的 [ret_1, vol_20, vol_ratio, trend_slope, vol_pct_252, dd_120]
  - 隐状态数: 3~6 之间按 BIC 自动选择 (也可固定)
  - 两种模式:
      mode='train_predict'  研究模式: 前 train_end 拟合, 全样本解码 (默认)
      mode='walk_forward'   生产模式: 每 refit_every 根用尾部 window 根重新拟合,
                            只向前解码 refit_every 根 (严格无前视)
  - 隐状态 -> 规范状态: 优先用规则检测器锚点做多数表决, 否则按 (波动/漂移/趋势) 语义映射
"""
from __future__ import annotations

import warnings
from typing import Optional

import numpy as np
import pandas as pd

from .base import BaseDetector, make_result, map_latent_to_canonical

DEFAULT_FEATURES = ["ret_1", "vol_20", "vol_ratio", "trend_slope", "vol_pct_252", "dd_120"]


class HMMDetector(BaseDetector):
    name = "hmm"

    def __init__(
        self,
        n_components: Optional[int] = 4,
        select_by_bic: bool = True,
        feature_cols: Optional[list] = None,
        mode: str = "train_predict",
        window: int = 8000,
        refit_every: int = 500,
        random_state: int = 42,
    ):
        self.n_components = n_components
        self.select_by_bic = select_by_bic
        self.feature_cols = feature_cols or DEFAULT_FEATURES
        self.mode = mode
        self.window = window
        self.refit_every = refit_every
        self.random_state = random_state
        self.model_ = None
        self.mapping_ = {}
        self.n_used_ = None
        self.bic_table_ = None

    # ------------------------------------------------------------------
    def _prep(self, X: pd.DataFrame) -> pd.DataFrame:
        cols = [c for c in self.feature_cols if c in X.columns]
        Z = X[cols].astype(float)
        return Z

    def _fit_one(self, Z: np.ndarray, k: int):
        from hmmlearn.hmm import GaussianHMM
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            m = GaussianHMM(
                n_components=k, covariance_type="full", n_iter=200,
                random_state=self.random_state, tol=1e-3,
            )
            m.fit(Z)
        return m

    def _select_k(self, Z: np.ndarray) -> int:
        from hmmlearn.hmm import GaussianHMM  # noqa
        ks = range(3, min(7, max(4, len(Z) // 500 + 3)))
        best_k, best_bic, table = 3, np.inf, []
        for k in ks:
            m = self._fit_one(Z, k)
            ll = m.score(Z)
            # 参数量近似: 转移矩阵 k(k-1) + 发射均值 k*f + 协方差 k*f(f+1)/2 + 初始 k-1
            f = Z.shape[1]
            n_params = k * (k - 1) + k * f + k * f * (f + 1) / 2 + (k - 1)
            bic = -2 * ll + n_params * np.log(len(Z))
            table.append((k, ll, bic))
            if bic < best_bic:
                best_bic, best_k = bic, k
        self.bic_table_ = pd.DataFrame(table, columns=["k", "loglik", "bic"])
        return int(best_k)

    # ------------------------------------------------------------------
    def fit(self, X: pd.DataFrame, y_anchor: Optional[pd.Series] = None) -> "HMMDetector":
        Zdf = self._prep(X)
        self.mu_ = Zdf.mean()
        self.sd_ = Zdf.std().replace(0, np.nan)
        Z = ((Zdf - self.mu_) / (self.sd_ + 1e-12)).fillna(0.0).values

        k = self.n_components
        if self.select_by_bic and k is None:
            k = self._select_k(Z)
        k = int(k or 4)
        self.model_ = self._fit_one(Z, k)
        self.n_used_ = k

        # 隐状态 -> 规范状态映射
        latent = self.model_.predict(Z)
        self.mapping_ = map_latent_to_canonical(
            latent, X, y_anchor,
            vol_col="vol_20", ret_col="ret_1", trend_col="trend_slope",
        )
        self._X_cols_ = list(X.columns)
        return self

    # ------------------------------------------------------------------
    def detect(self, X: pd.DataFrame) -> pd.DataFrame:
        Zdf = self._prep(X)
        Z = ((Zdf - self.mu_) / (self.sd_ + 1e-12)).fillna(0.0).values

        if self.mode == "walk_forward":
            return self._detect_walk_forward(X, Zdf, Z)

        latent = self.model_.predict(Z)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            post = self.model_.predict_proba(Z)
        conf = post.max(axis=1)
        states = [self.mapping_.get(int(l), "TRANSITION") for l in latent]
        return make_result(X.index, states, conf, extra={"latent": latent})

    # ------------------------------------------------------------------
    def _detect_walk_forward(self, X: pd.DataFrame, Zdf: pd.DataFrame,
                             Z: np.ndarray) -> pd.DataFrame:
        n = len(X)
        states = np.full(n, "TRANSITION", dtype=object)
        conf = np.zeros(n)
        latent_arr = np.full(n, -1)

        start = self.window
        cursor = start
        while cursor < n:
            fit_from = max(0, cursor - self.window)
            Zfit = Z[fit_from:cursor]
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                k = self.n_components or 4
                m = self._fit_one(Zfit, k)
                seg_end = min(cursor + self.refit_every, n)
                seg = Z[cursor:seg_end]
                lat = m.predict(seg)
                post = m.predict_proba(seg)
            mapping = map_latent_to_canonical(
                lat, X.iloc[cursor:seg_end], None,
            )
            states[cursor:seg_end] = [mapping.get(int(l), "TRANSITION") for l in lat]
            conf[cursor:seg_end] = post.max(axis=1)
            latent_arr[cursor:seg_end] = lat
            cursor = seg_end

        return make_result(X.index, list(states), conf, extra={"latent": latent_arr})

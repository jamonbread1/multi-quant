"""
评估与验证 (evaluation)
========================
市场状态识别的「经济价值」验证工具箱:

1. 状态统计        state_statistics: 各状态下的收益/波动/回撤/持续时间
2. 转移结构        transition_matrix / duration_stats: 状态持续性与切换规律
3. 风格代理收益    style_proxy_returns: 用简单策略代理验证「状态→风格」映射的正确性
4. 状态门控检验    regime_gated_test: 只在目标状态激活某风格代理, 对比无条件表现
                  —— 若门控后 Sharpe/回撤显著改善, 说明状态识别对聚合系统有实用价值
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

ANN = {"1H": np.sqrt(365 * 24), "1D": np.sqrt(365), "4H": np.sqrt(365 * 6)}


def _ann_factor(bar: str) -> float:
    return ANN.get(bar, np.sqrt(365 * 24))


def state_statistics(df: pd.DataFrame, states: pd.Series,
                     bar: str = "1H") -> pd.DataFrame:
    """各状态下 ETH 本身的条件表现 + 状态持续统计。"""
    ret = np.log(df["close"].astype(float)).diff()
    st = pd.Series(states).astype(str).values
    rows = []
    for name in pd.unique(st):
        m = st == name
        r = ret.values[m]
        r = r[~np.isnan(r)]
        # 精确持续时间: 统计连续段
        arr = st == name
        durs, cnt = [], 0
        for v in arr:
            if v:
                cnt += 1
            elif cnt:
                durs.append(cnt)
                cnt = 0
        if cnt:
            durs.append(cnt)
        af = _ann_factor(bar)
        vol = r.std() if len(r) else np.nan
        mu = r.mean() if len(r) else np.nan
        rows.append({
            "state": name,
            "n_bars": int(m.sum()),
            "share_pct": round(100 * m.mean(), 2),
            "avg_duration_bars": round(float(np.mean(durs)), 1) if durs else 0,
            "max_duration_bars": int(max(durs)) if durs else 0,
            "ann_ret_pct": round(100 * mu * af**2, 2) if len(r) else np.nan,
            "ann_vol_pct": round(100 * vol * af, 2) if len(r) else np.nan,
            "sharpe": round(float(mu / (vol + 1e-12) * af), 2) if len(r) else np.nan,
            "skew": round(float(pd.Series(r).skew()), 2) if len(r) > 2 else np.nan,
            "hit_rate_pct": round(100 * float((r > 0).mean()), 2) if len(r) else np.nan,
            "worst_bar_pct": round(100 * float(r.min()), 2) if len(r) else np.nan,
        })
    out = pd.DataFrame(rows).set_index("state")
    return out


def transition_matrix(states: pd.Series, normalize: bool = True) -> pd.DataFrame:
    st = pd.Series(states).astype(str).values
    names = sorted(pd.unique(st))
    mat = pd.DataFrame(0.0, index=names, columns=names)
    for a, b in zip(st[:-1], st[1:]):
        mat.loc[a, b] += 1
    if normalize:
        mat = mat.div(mat.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
    return mat


def duration_stats(states: pd.Series) -> pd.DataFrame:
    st = pd.Series(states).astype(str).values
    arr_change = np.r_[True, st[1:] != st[:-1]]
    seg_states = st[arr_change]
    seg_ends = np.r_[np.where(arr_change)[0][1:], len(st)]
    seg_starts = np.where(arr_change)[0]
    seg_len = seg_ends - seg_starts
    rows = []
    for name in pd.unique(seg_states):
        L = seg_len[seg_states == name]
        rows.append({
            "state": name,
            "n_segments": len(L),
            "mean_len": round(float(L.mean()), 1),
            "median_len": float(np.median(L)),
            "p90_len": float(np.percentile(L, 90)),
            "max_len": int(L.max()),
        })
    return pd.DataFrame(rows).set_index("state")


# ---------------------------------------------------------------- style proxies

def style_proxy_returns(df: pd.DataFrame, bar: str = "1H") -> Dict[str, pd.Series]:
    """
    简单风格代理策略 (日志收益), 用于验证状态-风格映射:
      trend:          MA20/60 金叉持有, 死叉空仓 (多头)
      mean_reversion: 布林带(20,2) 均值回归: z<-1 做多, z>1 做空, 回到均值平仓
      breakout:       Donchian 20 突破做多, 10 根低点止损
      carry:          (无费率数据时以 0 计, 仅结构占位)
      defensive:      现金 (0 收益)
    """
    close = df["close"].astype(float)
    high, low = df["high"].astype(float), df["low"].astype(float)
    ret = np.log(close).diff().shift(-1)  # 持有到下一根 (t 时刻决定, t+1 收益)

    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    trend_pos = (ma20 > ma60).astype(float)
    r_trend = trend_pos * ret

    ma = close.rolling(20).mean()
    sd = close.rolling(20).std()
    z = (close - ma) / (sd + 1e-12)
    mr_pos = pd.Series(0.0, index=close.index)
    mr_pos[z < -1] = 1.0
    mr_pos[z > 1] = -1.0
    # 回到 |z|<0.2 平仓: 用信号保持 (只要 |z|<0.2 就为 0)
    mr_pos[(z.abs() < 0.2)] = 0.0
    mr_pos = mr_pos.replace(0, np.nan).ffill().fillna(0.0)
    r_mr = mr_pos * ret

    hh = high.rolling(20).max().shift(1)
    ll_exit = low.rolling(10).min().shift(1)
    bo_pos = pd.Series(0.0, index=close.index)
    bo_pos[close > hh] = 1.0
    bo_pos[close < ll_exit] = 0.0
    bo_pos = bo_pos.replace(0, np.nan).ffill().fillna(0.0)
    r_bo = bo_pos * ret

    zero = pd.Series(0.0, index=close.index)
    return {
        "trend": r_trend.fillna(0.0),
        "mean_reversion": r_mr.fillna(0.0),
        "breakout": r_bo.fillna(0.0),
        "carry": zero.copy(),
        "defensive": zero.copy(),
    }


def perf_stats(r: pd.Series, bar: str = "1H") -> Dict[str, float]:
    r = r.dropna()
    if len(r) == 0:
        return {"ann_ret": np.nan, "ann_vol": np.nan, "sharpe": np.nan, "maxdd": np.nan}
    af = _ann_factor(bar)
    mu, sd = r.mean(), r.std()
    eq = r.cumsum()
    dd = (eq - eq.cummax()).min()
    return {
        "ann_ret": float(mu * af**2 * 100),
        "ann_vol": float(sd * af * 100),
        "sharpe": float(mu / (sd + 1e-12) * af),
        "maxdd": float(dd * 100),
    }


def regime_gated_test(
    style_rets: Dict[str, pd.Series],
    states: pd.Series,
    style_to_states: Dict[str, List[str]],
    bar: str = "1H",
) -> pd.DataFrame:
    """
    对每个风格代理: 比较 无条件表现 vs 仅在目标状态激活 的表现。
    style_to_states: 风格 -> 激活状态列表, e.g. {"trend": ["TREND_UP","TREND_DOWN"]}
    """
    st = pd.Series(states).astype(str)
    rows = []
    for style, r in style_rets.items():
        active = st.isin(style_to_states.get(style, [])).astype(float)
        gated = r * active
        base = perf_stats(r, bar)
        g = perf_stats(gated, bar)
        rows.append({
            "style": style,
            "sharpe_raw": round(base["sharpe"], 2),
            "sharpe_gated": round(g["sharpe"], 2),
            "ann_ret_raw": round(base["ann_ret"], 2),
            "ann_ret_gated": round(g["ann_ret"], 2),
            "maxdd_raw": round(base["maxdd"], 2),
            "maxdd_gated": round(g["maxdd"], 2),
            "active_share_pct": round(100 * active.mean(), 1),
        })
    return pd.DataFrame(rows).set_index("style")


def state_conditional_proxy_matrix(
    style_rets: Dict[str, pd.Series], states: pd.Series, bar: str = "1H"
) -> pd.DataFrame:
    """风格代理在各状态下的 Sharpe 矩阵 (行=状态, 列=风格) —— 验证风格-状态匹配度。"""
    st = pd.Series(states).astype(str)
    rows = {}
    for style, r in style_rets.items():
        col = {}
        for name in st.dropna().unique():
            m = st == name
            rr = r[m].dropna()
            if len(rr) > 10 and rr.std() > 0:
                af = _ann_factor(bar)
                col[name] = round(float(rr.mean() / (rr.std() + 1e-12) * af), 2)
            else:
                col[name] = np.nan
        rows[style] = col
    return pd.DataFrame(rows).T

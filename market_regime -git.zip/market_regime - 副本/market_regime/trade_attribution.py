"""
交易日志解析与市场状态归因 (trade_attribution)
================================================
把实盘/回测交易日志 (FMZ 风格 CSV) 解析为逐笔交易表, 与市场状态对齐, 输出:

  1. 状态归因表     attribute_trades_to_states: 各状态下的胜率/盈亏/PF/贡献
  2. 门控反事实     gating_counterfactual: "跳过在状态 X 开仓的交易" 后的绩效对比
  3. 图表           equity_curve / trade_state_scatter / state_pnl_bars

支持的日志行 (消息列):
  开仓 多|空 N张 @PRICE stop=STOP (权益EQ)          -> 开仓记录
  全平(stop|signal) N张                              -> 平仓记录
  [L3 本笔] reason | 多|空 N张 @EP ... 离场XP | 盈亏XU = YR   -> 单笔结算 (含盈亏)
  心跳 bar=I close=C ... adx=A ATR=T                 -> 心跳 (用于时间戳对齐校验)

时间戳对齐: FMZ 日志时区可能与 OKX UTC 不同, 自动推断偏移 (心跳 close 与 4H K线匹配)。
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .evaluation import perf_stats

# ----------------------------------------------------------------- 解析 ---

RE_ENTRY = re.compile(
    r"^开仓 (?P<side>多|空) (?P<size>[\d.]+)张 @(?P<px>[\d.]+) stop=(?P<stop>[\d.]+) \(权益(?P<eq>[\d.]+)\)"
)
RE_EXIT = re.compile(r"^全平\((?P<reason>[^)]+)\) (?P<size>[\d.]+)张")
RE_L3 = re.compile(
    r"^\[L3 本笔\] (?P<reason>\S+) \| (?P<side>多|空)(?P<size>[\d.]+)张 @(?P<epx>[\d.]+)"
    r".*?离场(?P<xpx>[\d.]+) \| 盈亏(?P<pnl_u>[-+]?[\d.]+)U = (?P<pnl_r>[-+]?[\d.]+)R"
)
RE_BEAT = re.compile(
    r"^心跳 bar=(?P<bar>\d+) close=(?P<close>[\d.]+).*?adx=(?P<adx>[\d.]+) ATR=(?P<atr>[\d.]+)"
)


def parse_fmoz_log(path: str, tz_offset_h: Optional[float] = None) -> pd.DataFrame:
    """
    解析 FMZ 导出日志 -> 逐笔交易表 (每笔含进出场时间/价格/盈亏U/盈亏R/权益/止损价)。
    tz_offset_h: 日志时间戳相对 UTC 的小时偏移; None=用心跳自动推断。
    """
    raw = pd.read_csv(path)
    raw.columns = [str(c).strip().strip('"') for c in raw.columns]
    time_col = "时间" if "时间" in raw.columns else raw.columns[1]
    msg_col = "消息" if "消息" in raw.columns else raw.columns[-1]
    raw[time_col] = pd.to_datetime(raw[time_col])
    raw["__ord"] = np.arange(len(raw))  # 保留原始行序作 tiebreaker

    # 日志可能整表倒序导出 (最新在前): 逆置以恢复真实事件顺序;
    # 否则按 (时间, 原行序) 稳定排序。
    if raw[time_col].is_monotonic_decreasing:
        rows = raw.iloc[::-1].reset_index(drop=True)
    else:
        rows = raw.sort_values([time_col, "__ord"], kind="stable").reset_index(drop=True)
    events = []
    for _, r in rows.iterrows():
        msg = r[msg_col]
        if not isinstance(msg, str):
            continue
        t = r[time_col]
        m = RE_L3.match(msg)
        if m:
            events.append({"time": t, "type": "l3", **m.groupdict()})
            continue
        m = RE_ENTRY.match(msg)
        if m:
            events.append({"time": t, "type": "entry", **m.groupdict()})
            continue
        m = RE_EXIT.match(msg)
        if m:
            events.append({"time": t, "type": "exit", **m.groupdict()})
            continue
        m = RE_BEAT.match(msg)
        if m:
            events.append({"time": t, "type": "beat", **m.groupdict()})

    ev = pd.DataFrame(events)
    if ev.empty:
        raise ValueError("未解析到任何事件, 请确认日志格式")

    # ---- 配对: 每个 entry 后第一个 l3 为同一笔结算 ----
    trades: List[dict] = []
    pending: Optional[dict] = None
    for _, e in ev.iterrows():
        if e["type"] == "entry":
            pending = {
                "entry_time": e["time"],
                "side": "long" if e["side"] == "多" else "short",
                "size": float(e["size"]),
                "entry_px": float(e["px"]),
                "stop_px": float(e.get("stop") or np.nan),
                "equity_entry": float(e.get("eq") or np.nan),
            }
        elif e["type"] == "l3" and pending is not None:
            rec = dict(pending)
            rec.update({
                "exit_time": e["time"],
                "exit_px": float(e["xpx"]),
                "pnl_u": float(e["pnl_u"]),
                "pnl_r": float(e["pnl_r"]),
                "exit_reason": e["reason"],
            })
            trades.append(rec)
            pending = None
    tdf = pd.DataFrame(trades)
    if tdf.empty:
        raise ValueError("未能配对出完整交易")

    tdf["ret_pct"] = tdf["pnl_u"] / tdf["equity_entry"] * 100
    tdf["bars_held"] = ((tdf["exit_time"] - tdf["entry_time"]).dt.total_seconds() // (4 * 3600)).astype(int)

    # ---- 时间偏移推断 (仅提示; 交易时间直接采用日志时间) ----
    if tz_offset_h is not None:
        off = pd.Timedelta(hours=tz_offset_h)
        tdf["entry_time_utc"] = tdf["entry_time"] - off
        tdf["exit_time_utc"] = tdf["exit_time"] - off
    else:
        tdf["entry_time_utc"] = tdf["entry_time"]
        tdf["exit_time_utc"] = tdf["exit_time"]

    beats = ev[ev["type"] == "beat"]
    if len(beats):
        tdf.attrs["beats"] = pd.DataFrame({
            "time": beats["time"].values,
            "close": beats["close"].astype(float).values,
        })
    return tdf


def infer_tz_offset_hours(beats: pd.DataFrame, ohlcv: pd.DataFrame) -> float:
    """
    用心跳 close 与 4H K线匹配推断日志时区偏移 (小时):
    偏移 = argmin |log_close - okx_close(log_time - offset)|
    """
    best_off, best_err = 0.0, np.inf
    px = ohlcv.set_index("datetime")["close"]
    ts = pd.DatetimeIndex(pd.to_datetime(ohlcv["datetime"]))
    closes = ohlcv["close"].values
    for off_h in [0, -8, 8, -4, 4, -7, 7, -5, 5]:
        shifted = pd.to_datetime(beats["time"]) - pd.Timedelta(hours=off_h)
        # 最近的K线收盘
        idx = np.searchsorted(ts.values, shifted.values.astype("datetime64[ns]"))
        idx = np.clip(idx, 1, len(closes) - 1)
        # 取前一根 (K线收盘时间 <= 记录时间)
        cand = np.where(ts.values[idx - 1] <= shifted.values.astype("datetime64[ns]"),
                        closes[idx - 1], closes[np.clip(idx - 2, 0, len(closes) - 1)])
        err = np.median(np.abs(cand - beats["close"].values) / beats["close"].values)
        if err < best_err:
            best_err, best_off = err, float(off_h)
    return best_off


# ----------------------------------------------------------------- 对齐 ---

def align_trades_to_states(
    trades: pd.DataFrame,
    states: pd.Series,
    ohlcv: pd.DataFrame,
    ts_col: str = "entry_time_utc",
) -> pd.DataFrame:
    """
    为每笔交易标注市场状态:
      state_entry:    开仓时刻所在K线的状态 (门控决策用)
      state_exit:     平仓时刻状态
      state_majority: 持仓期间占比最高的状态 (归因主口径)
    states: index 为 ohlcv 的 RangeIndex 或 datetime, 值为规范状态名。
    """
    t = trades.copy()
    ts = pd.DatetimeIndex(pd.to_datetime(ohlcv["datetime"]))
    if ts.tz is not None:
        ts = ts.tz_convert("UTC").tz_localize(None)
    ts_vals = ts.values  # naive datetime64[ns] (UTC)
    st = pd.Series(states).reset_index(drop=True)
    if len(st) != len(ohlcv):
        raise ValueError("states 与 ohlcv 长度不一致")

    def _naive64(x) -> np.datetime64:
        p = pd.Timestamp(x)
        if p.tzinfo is not None:
            p = p.tz_convert("UTC").tz_localize(None)
        return np.datetime64(p)

    def state_at(time) -> str:
        i = np.searchsorted(ts_vals, _naive64(time), side="right") - 1
        if i < 0:
            return "TRANSITION"
        return str(st.iloc[i])

    def majority_state(t0, t1) -> str:
        a, b = _naive64(t0), _naive64(t1)
        m = (ts_vals > a) & (ts_vals <= b)
        seg = st[m]
        if seg.empty:
            return state_at(t0)
        return str(seg.value_counts().idxmax())

    t["state_entry"] = [state_at(x) for x in t[ts_col]]
    t["state_exit"] = [state_at(x) for x in t["exit_time_utc"]]
    t["state_majority"] = [majority_state(a, b) for a, b in zip(t[ts_col], t["exit_time_utc"])]
    return t


# ----------------------------------------------------------------- 归因 ---

def attribute_trades_to_states(trades: pd.DataFrame,
                               state_col: str = "state_entry") -> pd.DataFrame:
    """按状态归因: 笔数/胜率/均笔R/合计U/盈亏比/均笔收益/t 值。"""
    rows = []
    for st, g in trades.groupby(state_col):
        r = g["pnl_r"].astype(float)
        wins = g.loc[g["pnl_u"] > 0, "pnl_u"].sum()
        losses = -g.loc[g["pnl_u"] < 0, "pnl_u"].sum()
        rows.append({
            "state": st,
            "n": len(g),
            "share_pct": round(100 * len(g) / len(trades), 1),
            "win_rate_pct": round(100 * (g["pnl_u"] > 0).mean(), 1),
            "avg_pnl_R": round(float(r.mean()), 3),
            "sum_pnl_R": round(float(r.sum()), 2),
            "sum_pnl_U": round(float(g["pnl_u"].sum()), 2),
            "PF": round(float(wins / losses), 2) if losses > 0 else np.inf,
            "avg_ret_pct": round(float(g["ret_pct"].mean()), 2),
            "t_stat": round(float(r.mean() / (r.std() + 1e-12) * np.sqrt(len(r))), 2),
            "avg_bars_held": round(float(g["bars_held"].mean()), 1),
        })
    out = pd.DataFrame(rows).set_index("state")
    return out.sort_values("sum_pnl_R", ascending=False)


def trade_equity_curve(trades: pd.DataFrame, initial: float = 30.0,
                       ret_col: str = "ret_pct") -> pd.Series:
    """按逐笔收益率复利的权益曲线 (index=exit_time)。"""
    r = trades.sort_values("exit_time")[ret_col].astype(float) / 100.0
    eq = initial * (1 + r).cumprod()
    eq = pd.concat([pd.Series([initial]), eq])
    return eq


def gating_counterfactual(
    trades: pd.DataFrame,
    skip_states: Optional[List[str]] = None,
    keep_states: Optional[List[str]] = None,
    state_col: str = "state_entry",
    initial: float = 30.0,
    label: str = "",
) -> Dict:
    """
    门控反事实: 跳过在 skip_states 开仓的交易 (或仅保留 keep_states),
    返回绩效对比 dict (基于逐笔收益复利, 假设跳过不改变后续仓位大小)。
    """
    if keep_states is not None:
        kept = trades[trades[state_col].isin(keep_states)]
    else:
        kept = trades[~trades[state_col].isin(skip_states or [])]
    actual = _trades_perf(trades, initial)
    gated = _trades_perf(kept, initial)
    return {
        "label": label or f"skip={skip_states} keep={keep_states}",
        "n_trades": len(kept),
        "skip_trades": len(trades) - len(kept),
        "actual": actual,
        "gated": gated,
        "kept_trades": kept,
    }


def _trades_perf(t: pd.DataFrame, initial: float) -> Dict[str, float]:
    if t.empty:
        return {"final_equity": initial, "cum_ret_pct": 0.0, "trade_sharpe": np.nan,
                "maxdd_pct": 0.0, "win_rate": np.nan, "avg_R": np.nan, "sum_R": 0.0}
    r = t.sort_values("exit_time")["ret_pct"].astype(float) / 100.0
    eq = initial * (1 + r).cumprod()
    dd = (eq / eq.cummax() - 1).min()
    rr = t["pnl_r"].astype(float)
    return {
        "final_equity": round(float(eq.iloc[-1]), 2),
        "cum_ret_pct": round(float((eq.iloc[-1] / initial - 1) * 100), 1),
        "trade_sharpe": round(float(rr.mean() / (rr.std() + 1e-12) * np.sqrt(len(rr))), 2),
        "maxdd_pct": round(float(dd * 100), 1),
        "win_rate": round(float((t["pnl_u"] > 0).mean() * 100), 1),
        "avg_R": round(float(rr.mean()), 3),
        "sum_R": round(float(rr.sum()), 2),
    }


# ----------------------------------------------------------------- 图 ---

def plot_equity_curves(curves: Dict[str, pd.Series], path: str,
                       title: str = "权益曲线: 实际 vs 状态门控反事实"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(13, 5.5))
    for name, s in curves.items():
        ax.plot(range(len(s)), s.values, lw=1.4, label=name)
    ax.set_yscale("log")
    ax.legend(fontsize=9)
    ax.set_title(title)
    ax.set_ylabel("权益 (U, 对数轴)")
    ax.set_xlabel("交易序号")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def plot_state_pnl_bars(attr: pd.DataFrame, path: str,
                        title: str = "各状态下的交易盈亏贡献 (按开仓状态)"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .viz import STATE_COLORS
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "DejaVu Sans"]
    fig, ax = plt.subplots(figsize=(10, 5))
    colors = [STATE_COLORS.get(s, "#999") for s in attr.index]
    ax.bar(range(len(attr)), attr["sum_pnl_R"].values, color=colors, alpha=0.85)
    ax2 = ax.twinx()
    ax2.plot(range(len(attr)), attr["win_rate_pct"].values, "ko--", lw=1.2, label="胜率%")
    ax2.set_ylabel("胜率 %")
    ax.set_xticks(range(len(attr)))
    ax.set_xticklabels([f"{s}\n(n={int(attr.loc[s,'n'])})" for s in attr.index], fontsize=9)
    ax.set_ylabel("合计盈亏 (R)")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_title(title)
    ax2.legend(loc="upper right")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def plot_trades_on_states(close: pd.Series, states: pd.Series, trades: pd.DataFrame,
                          path: str, title: str = "交易进出点与市场状态"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .viz import STATE_COLORS, _shade_states
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "DejaVu Sans"]
    fig, ax = plt.subplots(figsize=(15, 5.5))
    st = pd.Series(states).astype(str).values
    _shade_states(ax, st, 0, 1)
    ax.plot(range(len(close)), close.values, color="black", lw=0.7)
    ts = pd.DatetimeIndex(pd.to_datetime(close.index if close.index.dtype == "datetime64[ns, UTC]"
                                         else close.index))
    # 进场点
    for _, tr in trades.iterrows():
        i = np.searchsorted(ts.values, np.datetime64(tr["entry_time_utc"])) - 1
        j = np.searchsorted(ts.values, np.datetime64(tr["exit_time_utc"])) - 1
        if i < 0:
            continue
        won = tr["pnl_u"] > 0
        color = "#2ca02c" if won else "#d62728"
        marker = "^" if tr["side"] == "long" else "v"
        ax.scatter(i, close.iloc[i], marker=marker, s=18, color=color, zorder=5)
        if 0 <= j < len(close):
            ax.scatter(j, close.iloc[j], marker="x", s=14, color=color, zorder=5)
    ax.set_yscale("log")
    ax.set_title(title)
    ax.set_ylabel("价格 (USDT, 对数)")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)

"""
可视化 (viz)
============
市场状态研究的标准图组 (matplotlib, 中文标注):
  1. 价格 + 状态背景色带 (旗舰图)
  2. 状态时间线条
  3. 各状态特征分布 (箱线图)
  4. 状态转移矩阵热力图
  5. 风格代理: 无条件 vs 状态门控 Sharpe
  6. 风格×状态 Sharpe 矩阵
  7. 分配权重堆叠面积图
  8. 检测器置信度/一致性时序
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .taxonomy import States

plt.rcParams["font.family"] = ["Noto Sans CJK JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 110
plt.rcParams["savefig.bbox"] = "tight"

STATE_COLORS = {
    "TREND_UP": "#2ca02c",
    "TREND_DOWN": "#d62728",
    "RANGE_CALM": "#1f77b4",
    "HIGH_VOL": "#ff7f0e",
    "TRANSITION": "#9e9e9e",
}


def _shade_states(ax, states: pd.Series, y0: float, y1: float, alpha: float = 0.22):
    st = pd.Series(states).astype(str).values
    x = np.arange(len(st))
    start = 0
    for i in range(1, len(st) + 1):
        if i == len(st) or st[i] != st[start]:
            ax.axvspan(start - 0.5, i - 0.5,
                       color=STATE_COLORS.get(st[start], "#cccccc"),
                       alpha=alpha, lw=0)
            start = i


def plot_price_with_states(close: pd.Series, states: pd.Series, path: str,
                           title: str = "ETH-USDT-SWAP 价格与市场状态"):
    fig, ax = plt.subplots(figsize=(15, 5.5))
    _shade_states(ax, states, 0, 1)
    ax.plot(np.arange(len(close)), close.values, color="black", lw=0.8, label="收盘价")
    ax.set_yscale("log")
    handles = [plt.Rectangle((0, 0), 1, 1, color=STATE_COLORS[s.name], alpha=0.35)
               for s in States.ALL if s.name in set(pd.Series(states).astype(str))]
    labels = [f"{s.name} ({s.desc})" for s in States.ALL
              if s.name in set(pd.Series(states).astype(str))]
    ax.legend(handles, labels, loc="upper left", fontsize=9, ncol=3)
    ax.set_title(title)
    ax.set_ylabel("价格 (USDT, 对数轴)")
    n = len(close)
    ticks = np.linspace(0, n - 1, min(10, n)).astype(int)
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(pd.Series(states).index[t])[:10] for t in ticks], fontsize=8)
    fig.savefig(path)
    plt.close(fig)


def plot_state_strip(states: pd.Series, path: str,
                     title: str = "状态时间线 (上) 与置信度 (下)",
                     confidence: Optional[pd.Series] = None):
    fig, axes = plt.subplots(2 if confidence is not None else 1, 1,
                             figsize=(15, 3.2 if confidence is None else 5),
                             sharex=True)
    if confidence is None:
        axes = [axes]
    st = pd.Series(states).astype(str).values
    from matplotlib.colors import to_rgb
    rgb = np.array([to_rgb(STATE_COLORS.get(s, "#cccccc")) for s in st])
    axes[0].imshow(rgb[np.newaxis, :, :], aspect="auto",
                   extent=[-0.5, len(st) - 0.5, 0, 1])
    axes[0].set_yticks([])
    axes[0].set_title(title)
    if confidence is not None:
        axes[1].plot(np.asarray(confidence, dtype=float), lw=0.5, color="#333")
        axes[1].set_ylabel("置信度")
        axes[1].set_ylim(0, 1.05)
    fig.savefig(path)
    plt.close(fig)


def plot_feature_box(features: pd.DataFrame, states: pd.Series, path: str,
                     cols: Optional[List[str]] = None):
    cols = cols or [c for c in ["vol_20", "trend_slope", "vol_pct_252", "dd_120",
                                "adx_14", "autocorr_1"] if c in features.columns]
    st = pd.Series(states).astype(str).reset_index(drop=True)
    feats = features.reset_index(drop=True)
    names = [s.name for s in States.ALL if (st == s.name).any()]
    fig, axes = plt.subplots(2, 3, figsize=(15, 7.5))
    axes = axes.ravel()
    for ax, c in zip(axes, cols):
        data = [feats.loc[(st == n).values, c].dropna().clip(
            feats[c].quantile(0.01), feats[c].quantile(0.99)) for n in names]
        bp = ax.boxplot(data, tick_labels=[n[:9] for n in names], showfliers=False, patch_artist=True)
        for patch, n in zip(bp["boxes"], names):
            patch.set_facecolor(STATE_COLORS[n])
            patch.set_alpha(0.55)
        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelsize=7)
    fig.suptitle("各状态的特征分布 (1%~99% 截尾)", fontsize=12)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_transition_matrix(mat: pd.DataFrame, path: str,
                           title: str = "状态转移矩阵 (行归一)"):
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(mat.values, cmap="YlOrRd", vmin=0, vmax=1)
    ax.set_xticks(range(len(mat.columns)))
    ax.set_yticks(range(len(mat.index)))
    ax.set_xticklabels(mat.columns, fontsize=9, rotation=30, ha="right")
    ax.set_yticklabels(mat.index, fontsize=9)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            v = mat.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=9,
                    color="white" if v > 0.55 else "black")
    ax.set_title(title)
    fig.colorbar(im, fraction=0.046)
    fig.savefig(path)
    plt.close(fig)


def plot_gated_bars(gated_df: pd.DataFrame, path: str,
                    title: str = "风格代理: 无条件 vs 状态门控"):
    fig, ax = plt.subplots(figsize=(11, 5))
    x = np.arange(len(gated_df))
    w = 0.38
    ax.bar(x - w / 2, gated_df["sharpe_raw"], w, label="无条件 Sharpe", color="#bbbbbb")
    ax.bar(x + w / 2, gated_df["sharpe_gated"], w, label="状态门控 Sharpe", color="#1f77b4")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(gated_df.index, fontsize=10)
    ax.legend()
    ax.set_title(title)
    ax.set_ylabel("年化 Sharpe")
    fig.savefig(path)
    plt.close(fig)


def plot_style_state_matrix(mat: pd.DataFrame, path: str,
                            title: str = "风格代理 × 状态 的 Sharpe 矩阵"):
    fig, ax = plt.subplots(figsize=(8, 5.5))
    im = ax.imshow(mat.values.astype(float), cmap="RdYlGn", vmin=-2, vmax=2)
    ax.set_xticks(range(len(mat.columns)))
    ax.set_yticks(range(len(mat.index)))
    ax.set_xticklabels(mat.columns, fontsize=9, rotation=30, ha="right")
    ax.set_yticklabels(mat.index, fontsize=9)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            v = mat.values[i, j]
            ax.text(j, i, "" if pd.isna(v) else f"{float(v):.2f}",
                    ha="center", va="center", fontsize=9)
    ax.set_title(title)
    fig.colorbar(im, fraction=0.046)
    fig.savefig(path)
    plt.close(fig)


def plot_allocation(weights: pd.DataFrame, path: str,
                    title: str = "风格目标权重 (StyleAllocator 输出)"):
    fig, ax = plt.subplots(figsize=(15, 5))
    colors = plt.cm.Set3(np.linspace(0, 1, weights.shape[1]))
    ax.stackplot(np.arange(len(weights)), [weights[c].values for c in weights.columns],
                 labels=list(weights.columns), colors=colors, alpha=0.9)
    ax.legend(loc="upper left", ncol=min(6, weights.shape[1]), fontsize=9)
    ax.set_ylim(0, 1)
    ax.set_title(title)
    ax.set_ylabel("目标权重")
    n = len(weights)
    ticks = np.linspace(0, n - 1, min(10, n)).astype(int)
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(weights.index[t])[:10] for t in ticks], fontsize=8)
    fig.savefig(path)
    plt.close(fig)

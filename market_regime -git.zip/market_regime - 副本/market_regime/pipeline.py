"""
市场状态识别组件 —— 编排与对外 API
===================================

研究入口:
    MarketStatePipeline().run(ohlcv) -> PipelineResult
    (特征 -> 多检测器 -> 共识状态 -> 评估 -> 风格权重)

生产入口 (聚合系统接入):
    api = MarketStateAPI()          # 默认 hybrid 检测器
    api.fit(history_df)             # 用历史K线拟合
    out = api.update(last_bars_df)  # 增量更新: 返回 state / confidence / 风格权重
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd

from .allocation import StyleAllocator
from .detectors import GMMDetector, HMMDetector, HybridDetector, RuleBasedDetector
from .evaluation import (
    duration_stats,
    regime_gated_test,
    state_conditional_proxy_matrix,
    state_statistics,
    style_proxy_returns,
    transition_matrix,
)
from .features import attach_funding, build_features
from .taxonomy import States

DEFAULT_STYLE_TO_STATES = {
    "trend": ["TREND_UP", "TREND_DOWN"],
    "mean_reversion": ["RANGE_CALM"],
    "breakout": ["HIGH_VOL", "TREND_UP"],
    "carry": ["RANGE_CALM"],
    "defensive": ["HIGH_VOL", "TRANSITION"],
}


@dataclass
class PipelineResult:
    ohlcv: pd.DataFrame
    features: pd.DataFrame
    states: Dict[str, pd.DataFrame] = field(default_factory=dict)   # 每个检测器的输出
    consensus: Optional[pd.DataFrame] = None
    weights: Optional[pd.DataFrame] = None
    tables: Dict[str, pd.DataFrame] = field(default_factory=dict)
    bar: str = "1H"


class MarketStatePipeline:
    """
    参数
    ----
    detector:   'hybrid' | 'rules' | 'hmm' | 'gmm'
    train_frac: 拟合/评估切分比例 (研究模式, 防止全样本过拟合评估)
    use_funding: 是否合并资金费率特征 (若数据可用)
    """

    def __init__(self, detector: str = "hybrid", train_frac: float = 0.4,
                 bar: str = "1H", use_funding: bool = True,
                 allocator: Optional[StyleAllocator] = None):
        self.detector_name = detector
        self.train_frac = train_frac
        self.bar = bar
        self.use_funding = use_funding
        self.allocator = allocator or StyleAllocator()
        self._detectors = {
            "rules": RuleBasedDetector(),
            "hmm": HMMDetector(n_components=4, select_by_bic=False),
            "gmm": GMMDetector(n_components=5),
            "hybrid": HybridDetector(),
        }

    # ------------------------------------------------------------------
    def prepare(self, ohlcv: pd.DataFrame,
                funding: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        feats = build_features(ohlcv, bar=self.bar)
        if self.use_funding and funding is not None and not funding.empty:
            feats = attach_funding(feats, ohlcv, funding)
        return feats

    def run(self, ohlcv: pd.DataFrame,
            funding: Optional[pd.DataFrame] = None) -> PipelineResult:
        ohlcv = ohlcv.reset_index(drop=True)
        feats = self.prepare(ohlcv, funding)
        valid = feats.dropna(subset=["ret_1", "vol_20", "trend_slope"]).index
        warmup = int(valid[0]) if len(valid) else 0
        f = feats.iloc[warmup:].copy()
        n = len(f)
        train_end = max(200, int(n * self.train_frac))

        res = PipelineResult(ohlcv=ohlcv, features=feats, bar=self.bar)

        # 规则检测器先出结果 (兼作 ML 锚点)
        rules = self._detectors["rules"].fit(f).detect(f)
        res.states["rules"] = rules

        hmm = self._detectors["hmm"]
        hmm.fit(f, y_anchor=rules["state"].astype(str))
        res.states["hmm"] = hmm.detect(f)

        gmm = self._detectors["gmm"]
        gmm.fit(f, y_anchor=rules["state"].astype(str))
        res.states["gmm"] = gmm.detect(f)

        hybrid = self._detectors["hybrid"]
        hybrid.rules = self._detectors["rules"]
        hybrid.hmm = hmm
        hybrid.gmm = gmm
        res.states["hybrid"] = hybrid.detect(f)

        cons = res.states[self.detector_name]
        res.consensus = cons

        # ---- 评估 (样本外段: train_end 之后) ----
        oos_slice = slice(train_end, None)
        ohlcv_oos = ohlcv.iloc[warmup:].iloc[oos_slice].reset_index(drop=True)
        states_oos = cons["state"].astype(str).iloc[oos_slice].reset_index(drop=True)

        res.tables["state_stats_oos"] = state_statistics(ohlcv_oos, states_oos, self.bar)
        res.tables["state_stats_full"] = state_statistics(
            ohlcv.iloc[warmup:].reset_index(drop=True), cons["state"].astype(str), self.bar)
        res.tables["transition"] = transition_matrix(states_oos)
        res.tables["durations"] = duration_stats(states_oos)

        style_rets = style_proxy_returns(ohlcv_oos, self.bar)
        res.tables["gated_test"] = regime_gated_test(
            style_rets, states_oos, DEFAULT_STYLE_TO_STATES, self.bar)
        res.tables["style_state_sharpe"] = state_conditional_proxy_matrix(
            style_rets, states_oos, self.bar)

        # ---- 分配权重 (全样本) ----
        res.weights = self.allocator.allocate(
            cons["state"].astype(str), cons["confidence"])
        return res


class MarketStateAPI:
    """
    生产接入面 (轻量封装): 多风格策略聚合系统只依赖本类。

    用法:
        api = MarketStateAPI()
        api.fit(hist_ohlcv)                     # 至少 ~500 根K线
        snapshot = api.update(recent_ohlcv)     # 每次调用 (可逐K线)
        # snapshot: {"state": "TREND_UP", "confidence": 0.81,
        #            "style_weights": {"trend": 0.55, ...}, "agreement": 0.9}
    """

    def __init__(self, allocator: Optional[StyleAllocator] = None,
                 detector: str = "hybrid"):
        self.pipeline = MarketStatePipeline(detector=detector, allocator=allocator)
        self.allocator = self.pipeline.allocator
        self._fitted = False

    def fit(self, ohlcv: pd.DataFrame,
            funding: Optional[pd.DataFrame] = None) -> "MarketStateAPI":
        self._ohlcv_tail = ohlcv.copy()
        self._result = self.pipeline.run(ohlcv, funding)
        self._fitted = True
        return self

    def states(self) -> pd.Series:
        """历史状态序列。"""
        return self._result.consensus["state"].astype(str)

    def update(self, ohlcv: pd.DataFrame,
               funding: Optional[pd.DataFrame] = None) -> Dict:
        """
        输入含最新K线的窗口 (建议>=500根, 可直接传最近一批), 返回最新状态快照。
        注: hybrid 检测器带拟合模型, update 时复用 fit 的模型做解码, 不重拟合。
        """
        if not self._fitted:
            return self.fit(ohlcv, funding).update(ohlcv, funding)
        res = self.pipeline.run(ohlcv, funding)
        last = res.consensus.iloc[-1]
        w = res.weights.iloc[-1]
        agree_col = "agree" if "agree" in res.consensus.columns else None
        return {
            "state": str(last["state"]),
            "confidence": float(last["confidence"]),
            "agreement": float(last[agree_col]) if agree_col else float(last["confidence"]),
            "style_weights": {k: float(v) for k, v in w.items()},
            "ts": str(ohlcv["datetime"].iloc[-1]) if "datetime" in ohlcv.columns else None,
        }

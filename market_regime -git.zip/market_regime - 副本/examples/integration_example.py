#!/usr/bin/env python3
"""
多风格策略聚合系统 —— 市场状态组件接入示例
============================================
演示标准接法:
  1. 加载历史K线 (聚合系统自己的数据源也行, 只要 OHLCV 格式对齐)
  2. MarketStateAPI.fit / update -> 状态 + 置信度 + 风格目标权重
  3. 把 style_weights 交给各风格子策略的资金分配模块
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from market_regime import MarketStateAPI, StyleAllocator, load_ohlcv  # noqa: E402

def main() -> None:
    ohlcv = load_ohlcv("ETH-USDT-SWAP", "1D")
    print(f"历史K线: {len(ohlcv)} 根  {ohlcv['datetime'].iloc[0]} -> {ohlcv['datetime'].iloc[-1]}")

    # ---- 1. 初始化 (可用自定义 regime->style 权重矩阵覆盖默认值) ----
    api = MarketStateAPI(allocator=StyleAllocator(smooth_halflife=5, max_turnover=0.4))
    api.fit(ohlcv)

    # ---- 2. 每根K线收盘后调用 update, 拿到状态与风格权重 ----
    snapshot = api.update(ohlcv)          # 实盘传入最近 >=500 根窗口
    print("\n最新状态快照:")
    for k, v in snapshot.items():
        print(f"  {k}: {v}")

    # ---- 3. 历史状态序列 -> 供聚合器做绩效归因 / 条件回测 ----
    states = api.states()
    print("\n状态分布:")
    print(states.value_counts(normalize=True).round(3).to_string())

    # ---- 4. 批量: 整段时间的风格权重面板 (index=时间, columns=风格) ----
    res = api._result
    print("\n风格权重面板 (最近5行):")
    print(res.weights.tail().round(3).to_string())

    print("""
接入选项:
  - 高频场景: 用 MarketStatePipeline(detector='hybrid') 的 walk-forward HMM
    (HMMDetector(mode='walk_forward')), 避免全样本拟合
  - 自定义状态: 扩展 taxonomy.States, 检测器输出保持 canonical 命名即可
  - 自定义风格池: StyleAllocator(styles=[...], regime_weights=自定义矩阵)
""")


if __name__ == "__main__":
    main()

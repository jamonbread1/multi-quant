#!/usr/bin/env python3
"""组件冒烟测试: python tests/test_smoke.py"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from market_regime import (  # noqa: E402
    MarketStateAPI, MarketStatePipeline, StyleAllocator, States,
    build_features, default_regime_style_matrix,
)
from market_regime.data import load_ohlcv  # noqa: E402
from market_regime.evaluation import (  # noqa: E402
    duration_stats, regime_gated_test, state_statistics,
    style_proxy_returns, transition_matrix,
)


def test_taxonomy():
    assert len(States.ALL) == 5
    m = default_regime_style_matrix()
    assert (m.sum(axis=1) > 0).all()
    assert set(m.columns) == {"trend", "mean_reversion", "breakout", "carry", "defensive"}
    print("[ok] taxonomy")


def test_features_causal():
    rng = np.random.default_rng(0)
    n = 400
    px = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    df = pd.DataFrame({
        "open": px, "high": px * 1.01, "low": px * 0.99, "close": px,
        "vol": rng.uniform(1e5, 2e5, n), "vol_ccy_quote": rng.uniform(1e7, 2e7, n),
    })
    f = build_features(df, "1H", with_hurst=False)
    # 修改最后一个值不应影响前面的特征 (因果性)
    f2 = build_features(df.assign(close=px * np.r_[np.ones(n - 1), 1.5]), "1H", with_hurst=False)
    common = [c for c in f.columns if c not in ("log_volume", "volume_z")]
    pd.testing.assert_frame_equal(
        f[common].iloc[50:-1].reset_index(drop=True),
        f2[common].iloc[50:-1].reset_index(drop=True),
        check_names=False,
    )
    print("[ok] features causal")


def test_pipeline_and_api():
    ohlcv = load_ohlcv("ETH-USDT-SWAP", "1D").tail(800).reset_index(drop=True)
    pipe = MarketStatePipeline(detector="hybrid", train_frac=0.5, bar="1D")
    res = pipe.run(ohlcv)
    st = res.consensus["state"].astype(str)
    assert set(st.unique()) <= set(States.names())
    assert res.consensus["confidence"].between(0, 1).all()
    # 权重: 每行和为1
    assert np.allclose(res.weights.sum(axis=1), 1.0, atol=1e-6)
    # 评估表存在
    for k in ["state_stats_oos", "transition", "gated_test", "style_state_sharpe"]:
        assert k in res.tables and len(res.tables[k]) > 0
    print("[ok] pipeline")

    api = MarketStateAPI()
    api.fit(ohlcv)
    snap = api.update(ohlcv)
    assert snap["state"] in States.names()
    assert abs(sum(snap["style_weights"].values()) - 1.0) < 1e-6
    print("[ok] api", snap["state"], {k: round(v, 2) for k, v in snap["style_weights"].items()})


def test_allocation_smooth():
    st = pd.Series(["TREND_UP"] * 50 + ["RANGE_CALM"] * 50)
    w = StyleAllocator(smooth_halflife=5, max_turnover=0.3).allocate(st)
    assert np.allclose(w.sum(axis=1), 1.0, atol=1e-6)
    turns = 0.5 * w.diff().abs().sum(axis=1).iloc[1:]
    assert (turns <= 0.301).all(), "换手率约束失效"
    print("[ok] allocation turnover cap")


def test_evaluation():
    ohlcv = load_ohlcv("ETH-USDT-SWAP", "1D").tail(500).reset_index(drop=True)
    states = pd.Series(np.random.default_rng(1).choice(
        States.names(), len(ohlcv)))
    s = state_statistics(ohlcv, states, "1D")
    assert set(s.index) <= set(States.names())
    t = transition_matrix(states)
    assert np.allclose(t.sum(axis=1), 1.0, atol=1e-6)
    d = duration_stats(states)
    assert (d["mean_len"] >= 1).all()
    sr = style_proxy_returns(ohlcv, "1D")
    g = regime_gated_test(sr, states, {"trend": ["TREND_UP", "TREND_DOWN"]}, "1D")
    assert "sharpe_gated" in g.columns
    print("[ok] evaluation")


if __name__ == "__main__":
    test_taxonomy()
    test_features_causal()
    test_allocation_smooth()
    test_evaluation()
    test_pipeline_and_api()
    print("\nALL SMOKE TESTS PASSED")

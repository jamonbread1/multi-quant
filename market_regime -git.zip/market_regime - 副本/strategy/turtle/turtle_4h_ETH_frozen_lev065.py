# -*- coding: utf-8 -*-
"""4H 海龟 don48 + ADX15 + 3ATR 吊灯追踪止损 —— ETH 单标的 · 冻结归档版.

================================================================================
FROZEN / ARCHIVED  (2026-10-10)
--------------------------------------------------------------------------------
本文件是**参数冻结的最终版**, 只做 ETH-USDT-SWAP 一个标的。
派生自 v1.1-bugfix (F1~F5 修复 + L1~L4 日志), **逻辑与参数逐字未改**, 仅:
  1. LEV 定为归档值 0.65;
  2. 文件头替换为冻结声明;
  3. SYMBOL_SPECS 只留 ETH (关闭交易所自动查询分支)。

【冻结参数表 —— 改任何一项都视为新策略, 必须重跑全部研究】
    DON_N       = 48     4H 唐奇安外通道(48 根 = 8 天)
    DON_EXIT    = 24     内通道 = n//2
    ADX_MIN     = 15     只门控开仓
    STOP_MULT   = 3.0    吊灯倍数
    MAX_STOP_PCT= 0.09   止损距离上限 9%(防极端 ATR 下止损过远)
    LEV         = 0.65     名义 = 权益 x 0.65
    CT_VAL/LOT  = 0.1/0.01   ETH-USDT-SWAP 官方合约规格
    成本        = taker 0.05% 双边 + 滑点 0.03% 双边 + 资金费 0.004%/8h

【已知风险 —— 上线前必须读】
    · 最大回撤 62.5%~68.8%(2020-01~2026-10 窗口, 2022-08 见底)。
      2.75 年窗口内亦有 32.6%, 短回测会严重低估风险。
    · 88% 的交易时间在水下, 最长一次从峰值回本用了 89 笔 ≈ 3.3 年。
    · 收益集中在最赚的 8 笔(占 4.3%); 剔除后 176 笔均笔 -0.070%。
    · 震荡上涨市是最大敌人(2023 年 ETH +91% 而策略 -18.3%);
      单边下跌市反而赚钱(2025/2026 ETH 跌而策略 +24%/+14%)。
    · 单笔最坏亏损 = 9% x 0.65 = 权益的 5.9%; 历史最长连亏 8 笔。

【强平口径 —— 已在 2026-10 纠正过一次】
    交叉保证金清算:  N/G - N*p - N*0.5% <= 0  =>  p >= 1/G - 0.5%
    即**强平距离只取决于页数倍数 G, 与 LEV 无关**。
    G=10 -> 强平 9.5%, 9% 止损先触发(缓冲仅 0.5pp, 偏紧);
    G<=8  -> 缓冲 >= 3pp, 安全;  G>=15 -> 可能先于止损被强平, 不可用。
    上线前请把回测页/实盘的保证金倍数确认在 **G = 10 或更低**。

【绩效归属】
    绩效表: 海龟策略_绩效表_20261010.md
    归因与风险分析: 海龟策略_研究结论_20261009.md

================================================================================

# 原 v1.1 文件头(逐字保留, 以 # 注释形式以便溯源):
# # -*- coding: utf-8 -*-
# '''4H 海龟 don48 + ADX15 + 3ATR 吊灯追踪止损(FMZ 回测/实盘同源, Python).
#
# ================================================================================
# v1.1-bugfix (2026-10-09)
# --------------------------------------------------------------------------------
# 相对 v1.0-frozen **只改执行时序 bug 和可观测性**。信号/止损/仓位/成本语义
# 一律不动: don48 / adx15 / stop3 / 9%封顶 / 名义=权益x1.5 / reentry_block /
# 信号离场全部原样保留。目的就是让这次的回测能和 v1.0 那次做干净的 A/B 对照,
# 差异应当只来自下面 F1 这一条。
#
# 【本版修复】(均由 v1.0 回测日志 + 独立复算定位, 非猜测)
#
# F1 [P0, 归因 bug] 入场当根止损误判 —— v1.0 收益被压掉的主要原因。
#     v1.0 的 on_tick 里止损检查排在开仓之前, 但开仓发生在 tick 末尾, 而
#     on_tick 每 20s 跑一次: 下一个 tick 新 bar 还没收盘, closed_bars() 返回的
#     bar 集与开仓时**完全相同**, 于是 l[-1] 就是**入场那根 bar 自己的 Low** ——
#     等于"用开仓之前就已经发生的价格, 去砍刚刚开的仓"。
#     触发条件 = 入场 bar 的 (High-Low) >= 3*ATR, 与入场价无关。
#     2024-01~2026-10 共 76 笔, 命中 1 笔:
#         2026-08-20 00:00:00 开仓 @2085.15 -> 00:07:44 全平, 仅 -0.22U
#         (-0.22U / (1.05张 x 0.1ETH x 2085) = -0.001%, 全部是双边手续费)
#     修复: 入场那根 bar 不做止损**触发判定**, 从下一根收盘 bar 起生效。
#     为什么只改触发、止损抬升照旧: 多头入场要求 C[j] > max(H[j-48:j]), 故
#     H[j-1] < C[j] = 入场价, 抬升式 max(stop, H[j-1]-sd) 在入场 bar 上是
#     数学上的 no-op; 空头同理。故本修复净效果 = 纯粹拿掉那次误触发。
#     预期效果(独立复算, 见下方 A/B): 本样本总收益 122.61U -> 约 155~163U,
#     交易笔数与入场时刻不变, 只有 2026-08-20 那一笔的离场被改写。
#
# F2 止损平仓下单失败时, 本地状态被误清。v1.0 里 close_all 失败只 Log, 调用方
#     照样执行 pos=0 / block=True; 下一 tick 走"接管继承持仓"分支, 而该分支会
#     顺手 block=False, block_sig=0 —— 等于失败一次就把 reentry_block 清掉,
#     允许立刻重入, 止损形同虚设。
#     修复: close_all 返回成败; 失败时保持持仓状态不动, 下一 tick 继续重试。
#
# F3 信号离场后在同一 tick 内无条件重开仓。v1.0 平仓后直接令 cur=0 往下走;
#     回测里市价单同步成交没问题, 但**实盘**市价单可能尚未成交, 此时会在旧仓
#     之上再叠一个反向新仓(净仓位翻倍且方向错)。
#     修复: 平仓后重新读一次交易所真实持仓, 确认空仓才允许当 tick 重入。
#     回测为同步成交, 行为与 v1.0 完全一致, 不影响 A/B。
#
# F4 张数浮点毛刺。contracts_for 里 floor(x)*LOT 会重新引入二进制误差, 日志里
#     出现 0.7000000000000001 这种值, 提交给交易所可能被判非法张数。
#     修复: 取整后按 LOT 精度回修。
#
# F5 取数失败 / 周期熔断期间若持仓, v1.0 完全静默 —— 止损无人管理 = 裸奔。
#     这正是 2025-07-11 那次"中位间隔 28 小时"异常对应的真实风险敞口
#     (v1.0 那次恰好空仓, 属运气)。
#     修复: 节流告警, 打出持仓张数、当前止损、权益, 让人知道敞口没保护。
#     **不自动平仓**: "数据中断时该不该砍仓"属策略语义, 不在 bugfix 范围。
#
# 【新增可观测性】(纯日志, 不改任何决策)
#     L1 启动打印 假设的强平线(保证金倍数 x 名义倍数)。v1.0 那次回测页面杠杆
#        填的是 1.5, 与代码注释假设的 10 不符; 本版不改这个数、不依赖它做任何
#        决策, 只打印出来让你核对。
#     L2 每笔开仓打印: 止损距入场% / 占名义% / 占权益% / 距假设强平线的缓冲。
#     L3 每笔离场打印: 本笔 R 倍数(相对初始止损距离), 便于事后统计。
#     L4 预热完成时打印实际预热 bar 数。
# 心跳日志格式与 v1.0 保持一致, 便于两版日志逐行 diff。
#
# 研究结论见 research/study_lowfreq.md(#10) / study_crossmarket.md(#11) /
# study_robustness.md(#14) / study_walkforward.md(#17):
#   4H don48+adx15+stop3, ETH OOS pf1.43/t3 1.35, 4/4 市场通过, 30 邻域格全>1.0,
#   滚动 11 窗口中位 pf1.43(4 窗为负, 最差半年-54%)。
# 【v1.1 复算补充】本样本 76 笔里 Top3 笔 = 净利的 90.5%, 去掉后 PF 仅 1.08;
#   半年 PF 序列 3.12 -> 2.51 -> 1.37 -> 1.15 -> 1.31 -> 0.57, 2026H2 已为负。
#   即在"参数不动"的前提下真实衰减比研究结论描述的更陡, 仓位规划请按此。
#   另: 止损倍数存在悬崖(stop3 -> stop4 收益掉 57%), 参数不在平台上;
#   ADX 门槛 20 在本样本好 2.3 倍但属 IS, **不要据此改参数**。
#
# /*backtest
# start: 2024-06-30 00:00:00
# end: 2026-10-07 00:00:00
# period: 4h
# exchanges: [{"eid":"Futures_OKCoin","currency":"ETH_USDT"}]
# args: [["ContractType","swap",10989],["Amount",1.5,10989]]
# */
#
"""
DON_N = 48          # 外通道(研究 IS 网格选中, 邻域中点; 细网格峰值 72, 见 study_robustness)
DON_EXIT = 24       # 内通道 = n//2(研究 don_turtle 默认 m=n//2)
ADX_MIN = 15        # 只门控开仓
STOP_MULT = 3.0     # 吊灯倍数(邻域 stop2/stop3/stop4 OOS 均>1.1, 不追峰)
MAX_STOP_PCT = 0.09 # 止损距离上限 9%(防极端 ATR 下止损过远)
LEV = 0.65        # [FROZEN] 名义 = 权益 x 0.65
MARGIN_LEV = 10     # 【v1.1 仅用于 L1/L2 日志的假设值, 不参与任何决策】
                    # v1.0 注释写"回测页/实盘须一致", 但上次回测页面填的是 1.5。
                    # 本版不改这个数、不依赖它, 只打印出来让你核对后再定。
MAINT_MARGIN = 0.005  # 维持保证金率, 仅用于日志推算假设强平线
# 合约规格(换标的指南, 逻辑冻结只需改 INST_ID):
#   1) 回测页/实盘的交易对切到目标标的(如 SOL_USDT);
#   2) 下面 INST_ID 改成对应 "XXX-USDT-SWAP";
#   3) 表内已有(ETH/SOL/DOGE/BTC, 研究#11/#16 实测值)自动采用; 表外(如 ZEC)
#      启动时自动查 OKX instruments 接口(ctVal/lotSz), 查不到则沿用手动值并报警。
# 资本约束(研究#16): DOGE 单腿须>=60U; BTC 最小合约≈800U, 15U 完全开不了仓。
INST_ID = "ETH-USDT-SWAP"
# [FROZEN] ETH 单标的归档 —— 多标的表已移除。若日后要上其他标的,
# 必须重跑 A/B 与稳健性研究, 不能直接套用本文件的绩效结论。
SYMBOL_SPECS = {
    "ETH-USDT-SWAP": (0.1, 0.01),
}
CT_VAL = 0.1   # 手动 fallback(仅自动查询失败时用)
LOT = 0.01
POLL_MS = 20000  # 实盘止损轮询间隔(同 strat_1h_fmz.py: 20s 是 API 权重和延迟的折中)


def resolve_specs():
    """解析合约规格: 内置表优先, 否则查交易所, 都失败则沿用手动值并报警。"""
    global CT_VAL, LOT
    if INST_ID in SYMBOL_SPECS and SYMBOL_SPECS[INST_ID] is not None:
        CT_VAL, LOT = SYMBOL_SPECS[INST_ID]
        Log("合约规格(内置表): %s ctVal=%s lot=%s" % (INST_ID, CT_VAL, LOT))
        return
    try:
        info = exchange.IO("api", "GET", "/api/v5/public/instruments",
                           "instType=SWAP&instId=" + INST_ID)
        data = (info.get("data") if isinstance(info, dict) else None) or []
        if data:
            CT_VAL = float(data[0].get("ctVal"))
            LOT = float(data[0].get("lotSz"))
            Log("合约规格(交易所查询): %s ctVal=%s lotSz=%s minSz=%s tickSz=%s" % (
                INST_ID, CT_VAL, LOT, data[0].get("minSz"), data[0].get("tickSz")))
            return
        Log("合约规格查询无返回, 沿用手动值")
    except Exception as e:
        Log("合约规格查询失败: %s, 沿用手动值" % e)
    Log("沿用手动 CT_VAL=%s LOT=%s, 请人工确认与 %s 一致!!" % (CT_VAL, LOT, INST_ID))
    # [FROZEN] ETH-USDT-SWAP 在内置表中, 上面两个分支都不会走到。


def check_pair():
    """页面交易对须与 INST_ID 一致, 不一致只报警不停机(回测常改页面忘改代码)。"""
    try:
        cur = exchange.GetCurrency()
        want = INST_ID.replace("-SWAP", "").replace("-", "_")
        if cur and cur != want:
            Log("注意: 页面交易对=%s, 代码 INST_ID=%s, 合约规格以后者为准, "
                "请确认两者一致!!" % (cur, INST_ID))
    except Exception:
        pass


def liq_pct_nominal():
    """L1/L2 用: 假设强平线(名义口径的跌幅)。仅日志, 不参与决策。"""
    return 1.0 / float(MARGIN_LEV) - MAINT_MARGIN


def log_risk_frame():
    """L1: 打印假设强平线, 供核对回测页/实盘的保证金倍数设置。"""
    liq = liq_pct_nominal() * 100
    worst = MAX_STOP_PCT * LEV * 100
    Log("[L1 风险口径] 名义=权益x%.2f | 假设保证金倍数=%s 维持=%.1f%% -> 假设强平: "
        "名义口径 -%.2f%%, 折合权益 -%.2f%%" % (
            LEV, MARGIN_LEV, MAINT_MARGIN * 100, liq, liq * LEV))
    Log("[L1 风险口径] 单笔止损的权益代价 = 止损距%% x %.2f; 止损距上限 %.0f%% -> "
        "最坏一单约亏权益 %.2f%%" % (LEV, MAX_STOP_PCT * 100, worst))
    if worst > liq * LEV:
        need = MAX_STOP_PCT / (liq / 100.0)   # 需要 止损距 < 强平距
        Log("[L1 风险口径] !! 止损最坏情况(权益 -%.2f%%)已超过假设强平线(权益 -%.2f%%), "
            "缓冲为负。当前 9%%止损上限 x 1.5x名义 要求保证金倍数 > %.1f 才有正缓冲; "
            "若回测页倍数低于该值, 4H跳空时先爆仓而不是先止损。**本次请一并记录 "
            "回测页实际填的倍数。**" % (worst, liq * LEV, need))
    else:
        Log("[L1 风险口径] 止损最坏(权益 -%.2f%%) vs 假设强平(权益 -%.2f%%), "
            "缓冲 %.2f%%" % (worst, liq * LEV, liq * LEV - worst))


_P4H = globals().get("PERIOD_H4", globals().get("PERIOD_M240"))
# FMZ 的 4 小时常量叫 PERIOD_H4; 旧托管者两者皆无则为 None,
# closed_bars() 会降级为 GetRecords() 不传参(用回测页默认周期)。
# 预热根数: 唐奇安需 48 + ATR/ADX 收敛约 150(残差<1e-3), 共 198 根 ≈33 天。
# 注意 FMZ 回测的指标从回测开始日现播种(研究侧从 2019 播种), 前两个月信号
# 可能与研究报告略有出入, 属已知口径差, 不影响 2 年以上长回测的对照。
WARMUP = DON_N + 150


# ---------------- 纯函数(与 engine.py/engine_1h.py 同公式) ----------------
def atr_wilder(h, l, c, n=14):
    """与引擎 E._atr 逐值一致: ewm(span=n, adjust=False) 即 alpha=2/(n+1)"""
    al = 2.0 / (n + 1.0)
    trs = []
    for i in range(len(c)):
        if i == 0:
            trs.append(h[i] - l[i])
        else:
            trs.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))
    a, s = [], None
    for t in trs:
        s = t if s is None else t * al + s * (1 - al)
        a.append(s)
    return a


def adx_wilder(h, l, c, n=14):
    """与 engine.indicators 的 ADX 逐下标一致(atrx 用 span-ewm, 平滑用 alpha=1/n)"""
    al_span = 2.0 / (n + 1.0)
    al = 1.0 / n
    trs, plus, minus = [], [], []
    for i in range(1, len(c)):
        upm = h[i] - h[i - 1]
        dnm = l[i - 1] - l[i]
        plus.append(upm if (upm > dnm and upm > 0) else 0.0)
        minus.append(dnm if (dnm > upm and dnm > 0) else 0.0)
        trs.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def _dx(sp, sm, ax):
        if ax == 0:
            return float("nan")
        pdi, mdi = 100 * sp / ax, 100 * sm / ax
        return float("nan") if (pdi + mdi) == 0 else 100 * abs(pdi - mdi) / (pdi + mdi)

    atrx = h[0] - l[0]  # engine _atr[0]=TR0, ewm从此播种
    sp = sm = 0.0  # engine侧diff首根NaN->where得0, ewm从0播种
    out = [float("nan")]
    adx = float("nan")
    for i in range(len(trs)):
        atrx = trs[i] * al_span + atrx * (1 - al_span)
        sp = plus[i] * al + sp * (1 - al)
        sm = minus[i] * al + sm * (1 - al)
        dx = _dx(sp, sm, atrx)
        if dx == dx:
            adx = dx if adx != adx else dx * al + adx * (1 - al)
        out.append(adx)
    return out


def don_turtle_state(h, l, c, adx, n=DON_N, m=DON_EXIT, adx_min=ADX_MIN):
    """全历史状态机, 返回最后一根收盘确认的信号(调用方在下一根执行)。
    与 research/turtle_1h.py::don_turtle 逐行对应(含 shift(1) 语义:
    用 prefix[:j](含 close j-1) 算出的态 == 引擎 sig[j], 检验见 fmz/test_parity_4h.py)。"""
    pos = 0
    for i in range(len(c)):
        if i < n:  # rolling(n).max().shift(1) 在 i<n 时为 NaN, 状态保持
            continue
        up = max(h[i - n:i])
        dn = min(l[i - n:i])
        upx = max(h[i - m:i])
        dnx = min(l[i - m:i])
        a = adx[i]
        gate = (a == a and a >= adx_min) or (a != a and 0.0 >= adx_min)
        if pos <= 0 and gate and c[i] > up:
            pos = 1
        elif pos >= 0 and gate and c[i] < dn:
            pos = -1
        if pos == 1 and c[i] < dnx:
            pos = 0
        elif pos == -1 and c[i] > upx:
            pos = 0
    return pos


# ---------------- FMZ 执行 ----------------
# v1.1 新增字段:
#   stop_armed —— 止损"触发判定"从哪根 bar 起生效。开仓/接管持仓时置为当前
#                 最后一根收盘 bar 的 Time, 该 bar 不做触发判定, 下一根收盘
#                 bar 起才生效。修掉 F1 的入场当根误判。
#   risk       —— 本笔初始止损距离, 用于 L3 打印 R 倍数。
#   ent_bar    —— 本笔入场所在的收盘 bar 的 Time(诊断用)。
ST = {"pos": 0, "entry": 0.0, "qty": 0.0, "stop": 0.0, "risk": 0.0,
      "block": False, "block_sig": 0, "last_bar": 0, "want": 0,
      "stop_armed": None, "ent_bar": None}


def _f(rec, key):
    if isinstance(rec, dict):
        return rec.get(key)
    return getattr(rec, key, None)


def closed_bars():
    # 回测页K线周期必须设为4小时: 带周期参数的 GetRecords 在回测里可能不可用,
    # 先尝试显式 4H, 失败则用回测页默认周期(下面再校验 bar 间隔)。
    # 取数异常/根数一律记进 ST["dbg"], 由 on_tick 的等待日志打出(否则静默卡死无从查)。
    recs = None
    err1 = err2 = ""
    if _P4H is not None:
        try:
            recs = exchange.GetRecords(_P4H)
        except Exception as e:
            err1 = str(e)[:80]
    if not recs:
        try:
            recs = exchange.GetRecords()
        except Exception as e:
            err2 = str(e)[:80]
    if not recs:
        ST["dbg"] = "取数失败 explicit=[%s] default=[%s]" % (err1, err2)
        return None
    ST["dbg"] = "n=%s" % len(recs)
    if len(recs) < WARMUP:
        return None
    # 以交易所自己的时间定边界(不依赖托管者本机时钟, 实盘/回测同逻辑):
    # 最大Time即forming根, 严格小于它的才是收盘根
    latest = max(_f(b, "Time") for b in recs)
    out = [b for b in recs if _f(b, "Time") < latest]
    if len(out) < WARMUP - 1:
        ST["dbg"] = "n=%s(收盘%s)" % (len(recs), len(out))
        return None
    # 口径 guard: 确认真是 4H(曾出现误设 1H 导致信号全错)。中位间隔不在
    # 3.5~4.5h 之间就明确报错并暂停, 而不是静默跑错周期。
    dts = sorted(_f(b, "Time") for b in out[-50:])
    med = (dts[len(dts) // 2] - dts[len(dts) // 2 - 1]) / 3600000.0
    if not ST.get("period_warned") and not (3.5 <= med <= 4.5):
        ST["period_warned"] = True
        Log("周期错误: 当前K线中位间隔约%.2f小时, 不是4H —— "
            "请把回测页K线周期设为4小时后再跑; 在此之前不开仓" % med)
    if not (3.5 <= med <= 4.5):
        ST["dbg"] = "周期约%.2fh非4H" % med
        return None
    return out


def contracts_for(notional, price):
    """名义 -> 张数。v1.1: 修掉 floor(x)*LOT 的浮点毛刺(0.7000000000000001)。"""
    import math
    steps = math.floor(notional / (CT_VAL * price) / LOT)
    return round(steps * LOT, 8)


def equity_now():
    """权益 = 可用 + 持仓保证金 + 未实现盈亏(同引擎 equity 定义); 字段缺失时退化为 Balance。"""
    acc = exchange.GetAccount()
    bal = float(_f(acc, "Balance") or 0.0)
    tot = bal
    try:
        for p in (exchange.GetPosition() or []):
            tot += float(_f(p, "Margin") or 0.0) + float(_f(p, "Profit") or 0.0)
    except Exception:
        pass
    return tot if tot > 0 else bal


def sync_pos():
    poss = exchange.GetPosition()
    if not poss:
        return 0.0, 0.0
    p = poss[0]
    q = _f(p, "Amount") or 0.0
    avg = _f(p, "Price") or 0.0
    t = _f(p, "Type")
    return (q if t in (0, "buy", "long") else -q), avg


def close_all(reason):
    """全平。v1.1: 返回 True=已下单成功或本来就空仓, False=下单失败。
    调用方据此决定是否更新本地状态 —— 修掉 F2(失败却清 block 导致可立即重入)。"""
    qty, _ = sync_pos()
    if abs(qty) < 1e-9:
        ST.update(pos=0, block=False)  # 交易所已空仓: 只重置状态, 不下单(自愈)
        log_r(reason)                   # L3(用最近收盘价估算)
        return True
    # L3 用的成交价: 市价单成交在当前价, 回测里即当前 bar 收盘价(已用
    # v1.0 日志逐笔验证), 实盘为近似值 —— 只用于打印 R, 不参与决策。
    px_est = ST.get("last_px_close")
    exchange.SetDirection("closebuy" if qty > 0 else "closesell")
    oid = (exchange.Sell(-1, abs(qty)) if qty > 0 else exchange.Buy(-1, abs(qty)))
    if not oid:
        try:
            err = exchange.GetLastError()
        except Exception:
            err = "?"
        Log("全平(%s)下单失败: %s (状态保持, 下个 tick 重试)" % (reason, err))
        return False
    Log("全平(%s) %s张" % (reason, abs(qty)))
    log_r(reason, px_est)               # L3
    return True


def log_r(reason, exit_px=None):
    """L3: 离场时打印本笔 R 倍数(相对初始止损距离), 便于事后统计。
    R = 本笔盈亏U / 初始止损距离U, 理想止损单为 -1R。
    exit_px 为 None 时(交易所已空仓的自愈路径)退化为用最近收盘价估算。"""
    risk = ST.get("risk") or 0.0
    pos = ST.get("pos") or 0.0
    qty = ST.get("qty") or 0.0
    if risk <= 1e-12 or abs(pos) < 1e-9 or qty <= 0:
        return
    px = exit_px if exit_px else ST.get("last_px_close")
    if not px:
        return
    sgn = 1 if pos > 0 else -1
    risk_u = risk * qty * CT_VAL          # 初始止损对应的权益金额
    pnl_u = sgn * qty * CT_VAL * (px - ST["entry"])
    Log("[L3 本笔] %s | %s%s张 @%s 止损距离%s (%.2fU) | 离场%s | 盈亏%+.3fU = %+.2fR" % (
        reason, "多" if sgn > 0 else "空", qty, ST["entry"],
        round(risk, 4), risk_u, round(px, 2), pnl_u, pnl_u / risk_u))


def naked_alert():
    """F5: 取数不可用/周期熔断且持仓时, 节流告警 —— 止损此时无人管理=裸奔。
    只告警不自动平仓(该不该砍仓属策略语义, 需人工拍板)。"""
    qty, avg = sync_pos()
    if abs(qty) < 1e-9:
        return
    ST["naked"] = ST.get("naked", 0) + 1
    if ST["naked"] == 1 or ST["naked"] % 500 == 0:
        Log("[裸奔告警] K线不可用(%s) 已%d次未管理止损! 持仓%s张 入均价%s "
            "止损%s 权益%s —— 请检查数据源" % (
                ST.get("dbg", "?"), ST["naked"], qty, round(avg, 2),
                round(ST["stop"], 2), round(equity_now(), 2)))


def log_open(want, q, px, dist, eq):
    """L2: 开仓时打印本笔风险刻度 + 距假设强平线的缓冲。"""
    notional = q * CT_VAL * px
    eq_risk = dist / px * LEV * 100
    liq = liq_pct_nominal() * 100
    Log("开仓 %s %s张 @%s stop=%s (权益%s)" % (
        "多" if want > 0 else "空", q, px, round(ST["stop"], 2), round(eq, 2)))
    Log("[L2 风险] 名义%s = 权益x%.2f | 止损距入场%.2f%% = 名义的%.2f%% = 权益的%.2f%% | "
        "假设强平 = 名义的%.2f%% = 权益的%.2f%% | 缓冲(权益口径) %+.2f%%" % (
            round(notional, 2), notional / eq if eq > 0 else 0, 100 * dist / px,
            100 * dist / px, eq_risk, liq, liq * LEV, liq * LEV - eq_risk))


def on_tick():
    bars = closed_bars()
    if bars is None:
        # 诊断: 区分"预热中"(正常等待)还是"永远等不到"(数据源问题)。
        # 状态含 GetRecords 真实根数/报错, 卡住时直接说明原因。
        ST["wait"] = ST.get("wait", 0) + 1
        if ST["wait"] == 1 or ST["wait"] % 2000 == 0:
            Log("等待K线预热(需%s根收盘4H, 约33天); 状态:%s" % (
                WARMUP, ST.get("dbg", "?")))
        naked_alert()   # v1.1 F5
        return
    h = [_f(b, "High") for b in bars]
    l = [_f(b, "Low") for b in bars]
    c = [_f(b, "Close") for b in bars]
    ts = [_f(b, "Time") for b in bars]
    atr = atr_wilder(h, l, c)
    adx_raw = adx_wilder(h, l, c)
    adx = [0.0 if v != v else v for v in adx_raw]
    px = c[-1]
    is_new = ts[-1] != ST["last_bar"]
    ST["last_bar"] = ts[-1]
    ST["last_px_close"] = px   # L3 用
    if is_new:
        ST["want"] = don_turtle_state(h, l, c, adx)
        # 诊断心跳: 每 42 根新 bar(约一周)打一行, 无交易时也能看到信号/持仓/ADX 状态
        ST["nb"] = ST.get("nb", 0) + 1
        if not ST.get("warmed"):
            ST["warmed"] = True
            Log("预热完成: %s根收盘4H, close=%s ATR=%s" % (
                len(bars), px, round(atr[-1], 2)))   # L4
        if ST["nb"] % 42 == 1:
            q0, _ = sync_pos()
            Log("心跳 bar=%s close=%s want=%s exch=%s adx=%.1f ATR=%s" % (
                ST["nb"], px, ST["want"], q0, adx[-1], round(atr[-1], 2)))
    qty, avg = sync_pos()
    cur = 1 if qty > 0 else (-1 if qty < 0 else 0)
    if cur == 0 and ST["pos"] != 0:
        # 本地有仓而交易所空仓(交易所侧强平/手动平仓): 自愈, 不追单。
        # 注意此分支曾长期静默(2026-10 FMZ 对账时发现一笔疑似强平无日志), 必须留痕。
        Log("自愈重置: 本地记录%s张, 交易所已空仓(疑似被强平, 请核对权益曲线)" % ST["pos"])
        ST.update(pos=0, block=False)
    if cur != 0 and ST["pos"] == 0:
        # 重启继承持仓: 按当前收盘重建吊灯止损(同开仓公式), 裸奔是 P0
        sgn = 1 if cur > 0 else -1
        entry = avg if avg > 0 else px
        dist = min(STOP_MULT * atr[-1], MAX_STOP_PCT * px)
        ST.update(pos=float(sgn) * abs(qty), entry=entry, qty=abs(qty),
                  stop=entry - sgn * dist, risk=dist, block=False, block_sig=0,
                  ent_bar=ts[-1], stop_armed=ts[-1])   # v1.1 F1
        Log("接管继承持仓 %s张 entry=%s stop=%s" % (
            ST["pos"], round(entry, 2), round(ST["stop"], 2)))
    # 吊灯追踪止损(用上一根极值, 同引擎 manage_pos; TP=100x/200x ATR 等价于无)
    if cur != 0 and ST["pos"] != 0:
        sgn = 1 if cur > 0 else -1
        sd = min(STOP_MULT * atr[-1], MAX_STOP_PCT * px)
        if sgn > 0:
            ST["stop"] = max(ST["stop"], h[-2] - sd)
            # v1.1 F1: 入场那根 bar 不做触发判定 —— 它的 Low 发生在开仓之前,
            # 拿它砍新仓是错的。止损抬升照旧(该步在入场 bar 上是 no-op, 见文件头)。
            if l[-1] <= ST["stop"] and ts[-1] != ST["stop_armed"]:
                if close_all("stop"):
                    # 引擎语义: 止损离场后须信号变化才重入(防同向反复挨刀)
                    ST.update(pos=0, block=True, block_sig=ST["want"])
                return
        else:
            ST["stop"] = min(ST["stop"], l[-2] + sd)
            if h[-1] >= ST["stop"] and ts[-1] != ST["stop_armed"]:
                if close_all("stop"):
                    ST.update(pos=0, block=True, block_sig=ST["want"])
                return
    # 信号对账(反手/离场走信号, 同引擎 use_signal_exit)
    want = ST["want"]
    if ST["block"] and want != ST["block_sig"]:
        ST["block"] = False
    qty, _ = sync_pos()
    cur = 1 if qty > 0 else (-1 if qty < 0 else 0)
    if cur != 0 and want != cur:
        if not close_all("signal"):
            return          # F2: 平仓失败, 状态保持, 下 tick 重试
        cur = 0
        ST.update(pos=0)
        # v1.1 F3: 回测市价单同步成交, 这里必然已空仓; 实盘若单未成交则不在
        # 本 tick 重入, 否则会在旧仓之上叠一个反向新仓。
        q2, _ = sync_pos()
        if abs(q2) > 1e-9:
            Log("信号离场已下单, 交易所仍显示持仓%s张, 本 tick 不重入" % q2)
            return
    if cur == 0 and want != 0 and not ST["block"]:
        eq = equity_now()
        q = contracts_for(eq * LEV, px)
        if q > 0:
            dist = min(STOP_MULT * atr[-1], MAX_STOP_PCT * px)
            exchange.SetDirection("buy" if want > 0 else "sell")
            oid = (exchange.Buy(-1, q) if want > 0 else exchange.Sell(-1, q))
            if not oid:
                try:
                    err = exchange.GetLastError()
                except Exception:
                    err = "?"
                Log("开仓下单失败(want=%s q=%s): %s" % (want, q, err))
                return
            ST.update(pos=float(want) * q, entry=px, qty=q, risk=dist,
                      stop=px - want * dist, ent_bar=ts[-1],
                      stop_armed=ts[-1])   # v1.1 F1
            log_open(want, q, px, dist, eq)   # L2
        else:
            Log("名义不足一张(%s), 跳过开仓" % round(eq * LEV, 2))


def main():
    exchange.SetContractType("swap")
    resolve_specs()
    check_pair()
    Log("4H海龟 don48/adx15/stop3 启动(FROZEN归档版 lev%s / ETH-only) ",
        "CT_VAL=%s LOT=%s LEV=%s" % (lev, CT_VAL, LOT, LEV))
    log_risk_frame()   # L1
    while True:
        try:
            on_tick()
        except Exception as e:
            import traceback
            Log("on_tick异常: %s\n%s" % (e, traceback.format_exc()))
        Sleep(POLL_MS)

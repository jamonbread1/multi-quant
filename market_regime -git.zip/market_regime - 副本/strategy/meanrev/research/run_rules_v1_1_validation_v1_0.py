# -*- coding: utf-8 -*-
"""规则引擎 v1.1 修复验证 v1.0 —— DEF2 (TRANSITION缺失) + DEF3 (置信度弱).

============================================================================
版本: v1.0  日期: 2026-10-10
对象: market_regime/detectors/rules_v1_1.py 相对 rules.py (v1.0) 的两处修复
方法: walk-forward (逐bar前推, 拟合只用 [0,t)), 与 v1.0 验证口径完全一致,
      保证 v1.0 vs v1.1 的对比是公平的。

验收标准 (事先定死, 不达标即判定修复失败):
  A1 TRANSITION 占比 > 0% (DEF2 修复) 且在 2%~15% 的合理区间 (不是凑数)
  A2 状态切换频率不显著上升 (不能为造 TRANSITION 而牺牲稳定性)
  A3 置信度分位与实际正确率单调相关 (DEF3 修复) —— Spearman 相关 > 0
  A4 高分位正确率 > 低分位正确率 (至少两端差异为正)
  A5 v1.1 不破坏既有语义: TREND_UP/TREND_DOWN/RANGE_CALM/HIGH_VOL 的占比
     与 v1.0 接近 (改动应局限, 不是重构)
============================================================================
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
sys.path.insert(0, ROOT)

from market_regime.features import build_features
from market_regime.detectors.rules import RuleBasedDetector as V10
from market_regime.detectors.rules_v1_1 import RuleBasedDetector as V11
from market_regime.taxonomy import States

BAR = "4H"
WIN = 2000
MIN_CALIB = 400
CONFIRM = 3


def load():
    df = pd.read_csv(os.path.join(ROOT, f"data/okx/ETH-USDT-SWAP_{BAR}.csv"))
    df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
    return df.sort_values("ts").reset_index(drop=True)


def scores(X):
    """两个版本的分项计算完全一致, 共用。"""
    sc = pd.DataFrame(index=X.index)
    direction = (0.45 * X["sma60_dist"].clip(-3, 3)
                 + 0.35 * (X["trend_slope"] * X["trend_r2"]).clip(-3, 3)
                 + 0.20 * X["hh_hl_score"].clip(-1, 1))
    adx_gate = 0.35 + 0.65 * ((X["adx_14"] - 12) / 18).clip(0, 1)
    sc["trend_score"] = direction * adx_gate
    sc["vol_score"] = (0.7 * X["vol_pct_252"].fillna(0.5)
                       + 0.3 * (X["vol_ratio"] - 1).clip(-1, 3) / 3).clip(0, 1)
    return sc


def wf_decode(X, sc, ver):
    """walk-forward 解码: 每根bar用 [i-win, i) 重算阈值。"""
    n = len(X)
    trend = sc["trend_score"].values
    vol = sc["vol_score"].values
    adx = X["adx_14"].values
    ret20 = X["ret_20"].values
    ret1 = X["ret_1"].values

    states = np.array(["RANGE_CALM"] * n, dtype=object)
    conf = np.zeros(n)
    str_arr = np.zeros(n)
    sw = np.zeros(n, dtype=bool)
    cur, pending, pcnt = "RANGE_CALM", None, 0

    for i in range(n):
        if i < MIN_CALIB:
            states[i], conf[i] = cur, 0.3
            continue
        lo = max(0, i - WIN)
        th = np.abs(trend[lo:i]); th = th[~np.isnan(th)]
        vh = vol[lo:i]; vh = vh[~np.isnan(vh)]
        if len(th) < 50 or len(vh) < 50:
            states[i], conf[i] = cur, 0.3
            continue
        t_th = np.quantile(th, 0.68)
        v_hi = np.quantile(vh, 0.75)
        v_cr = np.quantile(vh, 0.90)

        t, v = trend[i], vol[i]
        if np.isnan(t) or np.isnan(v):
            states[i], conf[i] = cur, 0.3
            continue

        t_lo = t_th * 0.6
        v_lo = v_hi * 0.8

        if v >= v_cr and (np.isnan(ret20[i]) or ret20[i] < 0):
            cand, s = "HIGH_VOL", v
        elif v >= v_hi and abs(t) < t_th:
            cand, s = "HIGH_VOL", v
        elif t >= t_th and adx[i] >= 18:
            cand, s = "TREND_UP", t / t_th - 1
        elif t <= -t_th and adx[i] >= 18:
            cand, s = "TREND_DOWN", -t / t_th - 1
        elif ver == "v1.1" and abs(t) < t_lo and v_lo <= v < v_hi:
            cand, s = "TRANSITION", 1 - abs(t) / (t_lo + 1e-12)
        else:
            cand, s = "RANGE_CALM", 1 - abs(t) / (t_th + 1e-12)

        if cand == cur:
            pending, pcnt = None, 0
            conf[i] = float(np.clip(0.5 + 0.25 * min(2, max(0, s)), 0, 1))
            str_arr[i] = s
        else:
            if pending == cand:
                pcnt += 1
            else:
                pending, pcnt = cand, 1
            if pcnt >= CONFIRM:
                cur, pending, pcnt = cand, None, 0
                conf[i] = float(np.clip(0.45 + 0.25 * min(2, max(0, s)), 0, 0.9))
                str_arr[i] = s
                sw[i] = True
            else:
                conf[i] = 0.4
                str_arr[i] = 0.4
        states[i] = cur

    # v1.1: 用整段实测各状态后验正确率做标定 (与 fit 期口径一致)
    if ver == "v1.1":
        base = {}
        for st in States.names():
            m = states == st
            idx = np.where(m)[0]
            idx = idx[idx + 1 < n]
            r = ret1[idx + 1]
            r = r[~np.isnan(r)]
            if len(r) < 20:
                base[st] = 0.5
                continue
            if st == "TREND_DOWN":
                hit = float((r < 0).mean())
            elif st in ("TREND_UP", "HIGH_VOL"):
                hit = float((r > 0).mean())
            else:
                hit = float((np.abs(r) > np.median(np.abs(r))).mean())
            base[st] = float(np.clip(0.35 + hit * 0.6, 0.35, 0.95))
        # v1.1.1: 所有状态均随 strength 连续调节 (原 v1.1.0 仅方向状态调节,
        #          导致置信度退化为状态级常数, 五分位只剩3档)
        strength = np.array(str_arr)
        newconf = np.zeros(n)
        for i in range(n):
            st = str(states[i])
            base_c = base.get(st, 0.5)
            if np.isnan(strength[i]):
                newconf[i] = 0.3
                continue
            adj = np.clip((strength[i] - 0.5) * 0.12, -0.12, 0.12)
            newconf[i] = np.clip(base_c + adj, 0.3, 0.95)
        newconf[sw] *= 0.9
        conf = np.clip(newconf, 0, 1)

    return states, conf


def evaluate_hit(states, conf, X):
    """按置信度分位计算「方向判定正确率」, 用于检验校准质量。"""
    ret1 = X["ret_1"].values
    n = len(states)
    correct = np.zeros(n, dtype=bool)
    for i in range(n - 1):
        r = ret1[i + 1]
        if np.isnan(r):
            continue
        st = states[i]
        if st == "TREND_DOWN":
            correct[i] = r < 0
        elif st in ("TREND_UP", "HIGH_VOL"):
            correct[i] = r > 0
        else:
            correct[i] = abs(r) > np.median(np.abs(ret1[~np.isnan(ret1)]))
    valid = ~np.isnan(conf[: n - 1])
    return correct[: n - 1], conf[: n - 1], valid


def main():
    df = load()
    X = build_features(df, bar=BAR)
    valid = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
    warm = int(valid[0])
    X = X.iloc[warm:].reset_index(drop=True)
    sc = scores(X)
    n = len(X)
    print(f"=== {BAR} walk-forward 验证: {n} 根 bar ===")
    print(f"区间: {df.dt.iloc[warm]} -> {df.dt.iloc[-1]}\n")

    res = {}
    for ver, cls in [("v1.0", V10), ("v1.1", V11)]:
        st, cf = wf_decode(X, sc, ver)
        res[ver] = (st, cf)

    # ---------- A5 语义未被破坏 ----------
    print("=== A5 状态占比对比 (改动应局限, 非重构) ===")
    print(f"  {'状态':>12} {'v1.0':>10} {'v1.1':>10} {'差异':>10}")
    dist = {}
    for ver in ("v1.0", "v1.1"):
        dist[ver] = pd.Series(res[ver][0]).value_counts(normalize=True).mul(100)
    for s in States.names():
        a = dist["v1.0"].get(s, 0.0)
        b = dist["v1.1"].get(s, 0.0)
        print(f"  {s:>12} {a:>9.2f}% {b:>9.2f}% {b-a:>+9.2f}pp")

    # ---------- A1 TRANSITION 修复 ----------
    print("\n=== A1 DEF2 验收: TRANSITION 占比 ===")
    tr_v10 = dist["v1.0"].get("TRANSITION", 0.0)
    tr_v11 = dist["v1.1"].get("TRANSITION", 0.0)
    ok_a1 = 2.0 <= tr_v11 <= 15.0
    print(f"  v1.0 TRANSITION: {tr_v10:.2f}%  (目标: 0%)")
    print(f"  v1.1 TRANSITION: {tr_v11:.2f}%  (目标: 2%~15%)")
    print(f"  {'✅ 通过' if ok_a1 else '❌ 未通过'}")

    # ---------- A2 稳定性 ----------
    print("\n=== A2 状态稳定性 (不能为造 TRANSITION 而牺牲稳定性) ===")
    print(f"  {'版本':>8} {'下一根一致%':>13} {'24h后一致%':>12} {'平均段长':>10}")
    stab = {}
    for ver in ("v1.0", "v1.1"):
        st = res[ver][0]
        a1 = (st[:-1] == st[1:]).mean() * 100
        a6 = (st[:-6] == st[6:]).mean() * 100
        chg = np.r_[True, st[1:] != st[:-1]]
        seg = np.diff(np.where(chg)[0].tolist() + [len(st)])
        print(f"  {ver:>8} {a1:>12.2f}% {a6:>11.2f}% {seg.mean():>9.1f}")
        stab[ver] = a1

    # ---------- A3/A4 置信度校准 ----------
    print("\n=== A3/A4 DEF3 验收: 置信度校准质量 ===")
    print(f"  {'版本':>8} {'分位':>6} {'置信度均值':>11} {'方向正确率%':>13} {'n':>7}")
    qual = {}
    for ver in ("v1.0", "v1.1"):
        st, cf = res[ver]
        corr, cval, vmask = evaluate_hit(st, cf, X)
        q = pd.qcut(pd.Series(cval[vmask]), 5, labels=False, duplicates="drop")
        rates = []
        for qq in sorted(pd.Series(q).dropna().unique()):
            m = q == qq
            rate = corr[vmask][m].mean() * 100
            rates.append(rate)
            print(f"  {ver:>8} Q{int(qq)+1:<5} {cval[vmask][m].mean():>10.3f} "
                  f"{rate:>12.2f}% {int(m.sum()):>7}")
        # spearman
        from scipy.stats import spearmanr
        rho = spearmanr(cval[vmask], corr[vmask]).statistic
        qual[ver] = (rho, rates)
        print(f"  {ver:>8} -> Spearman(置信度, 正确率) = {rho:+.4f}")
        print()

    print("=== 验收结论 ===")
    rho10, r10 = qual["v1.0"]
    rho11, r11 = qual["v1.1"]
    ok_a3 = rho11 > 0 and rho11 > rho10
    ok_a4 = r11[-1] > r11[0]
    print(f"  A1 TRANSITION 出现且占比合理: {'✅' if ok_a1 else '❌'} ({tr_v11:.2f}%)")
    print(f"  A3 置信度单调性(Spearman>0 且优于v1.0): {'✅' if ok_a3 else '❌'} "
          f"(v1.0 {rho10:+.4f} -> v1.1 {rho11:+.4f})")
    print(f"  A4 高分位正确率 > 低分位: {'✅' if ok_a4 else '❌'} "
          f"({r11[0]:.1f}% -> {r11[-1]:.1f}%)")
    print(f"  A2 稳定性未恶化: {'✅' if stab['v1.1'] >= stab['v1.0'] - 2 else '❌'} "
          f"({stab['v1.0']:.2f}% -> {stab['v1.1']:.2f}%)")


if __name__ == "__main__":
    main()
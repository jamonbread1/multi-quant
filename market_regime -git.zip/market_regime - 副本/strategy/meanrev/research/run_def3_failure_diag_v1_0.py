# -*- coding: utf-8 -*-
"""DEF3 置信度校准失败诊断 v1.0 —— 判定是设计问题还是可修问题.

============================================================================
版本: v1.0  日期: 2026-10-10
背景: rules_v1_1 的 DEF3 修复 (置信度标定为状态后验正确率) 验证未通过:
      Spearman(置信度, 方向正确率) = -0.031, 与 v1.0 的 -0.036 无实质差异。
      本脚本诊断失败根因, 判断「是否值得继续修」。
方法: 分析状态后验命中率本身是否具备区分度 (这是 conf 的信息上限)。
============================================================================
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
sys.path.insert(0, ROOT)
from market_regime.features import build_features

df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

X = build_features(df, bar="4H")
v = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
X = X.iloc[int(v[0]):].reset_index(drop=True)
ret1 = X["ret_1"].values
r_all = ret1[1:]
r_clean = r_all[~np.isnan(r_all)]

W = pd.read_csv(os.path.join(ROOT, "data/states/WF_4H_rule_states.csv"))
st = W.state.values[40:]
n = min(len(st), len(X))
st = st[:n]
r = X["ret_1"].values[1:n]

print("=== 1. 基础可预测性 (命中率的上限) ===")
print(f"  全体 P(ret>0) = {(r_clean > 0).mean():.4f}")
print(f"  全体 P(|ret| > 中位数) = "
      f"{(np.abs(r_clean) > np.median(np.abs(r_clean))).mean():.4f}")

print("\n=== 2. 各状态的后验命中率 (conf 标定的信息源) ===")
print(f"  {'状态':>12} {'n':>6} {'命中率':>8} {'vs随机':>8}")
base_hits = {}
for s in ["TREND_UP", "TREND_DOWN", "HIGH_VOL", "RANGE_CALM"]:
    m = st[:-1] == s
    if m.sum() < 30:
        continue
    rr = r[m]
    rr = rr[~np.isnan(rr)]
    if len(rr) < 30:
        continue
    if s == "TREND_DOWN":
        hit = float((rr < 0).mean())
        base = 0.5
    elif s in ("TREND_UP", "HIGH_VOL"):
        hit = float((rr > 0).mean())
        base = 0.5
    else:
        hit = float((np.abs(rr) > np.median(np.abs(r_clean))).mean())
        base = 0.5
    base_hits[s] = hit
    print(f"  {s:>12} {m.sum():>6} {hit:>8.4f} {hit-base:>+7.4f}")

print("\n=== 3. 判��: 命中率是否有区分度 ===")
vals = list(base_hits.values())
if len(vals) >= 2:
    spread = max(vals) - min(vals)
    print(f"  各状态命中率极差 = {spread:.4f}")
    if spread < 0.05:
        print("  -> 极差 < 5pp: 各状态命中率几乎相同, conf 无区分度可用")
        print("  -> 这意味着【状态本身就没有方向预测力】, 不是 conf 的实现问题")
    else:
        print("  -> 存在一定区分度, 可继续设计 conf")

print("\n=== 4. 结论 ===")
if spread < 0.05:
    print("""
  DEF3 (置信度校准) 的失败不是实现缺陷, 而是【信息本身不存在】:
    - 各状态的 t+1 方向命中率几乎相同 (极差 < 5pp)
    - 无论怎么映射 confidence, 都不可能得到有区分度的校准曲线
    - v1.0 的 Spearman -0.036 与 v1.1 的 -0.031 都在噪声范围内

  诚实结论: 【状态标签在 t+1 的尺度上没有方向预测力】(单根bar)。
  状态的价值在更长的时间尺度 (walk-forward 验证显示 TREND_UP 后5日 t=7.23),
  而非下一根bar的涨跌方向。

  因此 DEF3 应重新定义为:
    「confidence 应反映【该状态在未来 N 根bar上的经济含义强度】,
      而非下一根bar的方向命中率」
    这需要指定 horizon (如 30 bar = 5日), 并按状态的历史表现标定。
""")
else:
    print("  存在区分度, 建议按 horizon 版本重新设计 confidence。")
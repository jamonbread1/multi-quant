# -*- coding: utf-8 -*-
"""信号验证修正版 v1.1 —— 「重回均线」信号被证伪 (beta 伪装成 alpha).

============================================================================
版本: v1.1  日期: 2026-10-10
相对 v1.0 的结论修正 (数据证伪 v1.0 的初步发现):

  v1.0 初步发现「重回均线」在 4 个状态里都正向 (+208bp/+140bp/+45bp/+28bp),
        以为是跨状态普适 alpha。
  v1.1 复核发现致命问题: 4H 周期下, 价格位于 MA20 之上占 99.87% 的时间,
        位于 MA50 之上占 99.67%, MA100 之上 99.33%。
        → 「重回均线」几乎恒为真, 它根本不是「事件」, 而是 ETH 长期上涨的
          beta 伪装。所谓 +208bp 只是「处于上涨趋势中」的重述。
        → T7 证伪项无法执行: 做空组仅占 0.13% (19根), 样本不足。

  结论: 「重回均线」信号 = 无效。它没有增量信息, 只是 beta 的另一表述。
        之前基于它的拆分讨论应作废。

方法: 与 v1.0 同, 但新增「信号恒真率」检验作为前置否决项。
============================================================================
"""
import os
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"

df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

W = pd.read_csv(os.path.join(ROOT, "data/states/WF_4H_rule_states.csv"))
W["dt"] = pd.to_datetime(W.dt, utc=True)
close = W.close.values[40:]
n = len(close)


def sma(x, k):
    return pd.Series(x).rolling(k).mean().values


print("=== 致命检验: 「重回均线」信号的恒真率 ===")
print("  若某条件在 99% 时间都成立, 它无法区分任何行情, 不是信号。\n")
print(f"  {'均线周期':>10} {'在线上占比%':>13} {'在线下占比%':>13} {'在线下bar数':>12}")
for k in [5, 10, 20, 30, 50, 100, 200]:
    m = sma(close, k) > 0
    ok = ~np.isnan(m)
    m = m[ok]
    print(f"  MA{k:<8} {m.mean()*100:>12.2f}% {(~m).mean()*100:>12.2f}% "
          f"{int((~m).sum()):>12}")

print("\n=== 同类检查: 其他常用「趋势确认」条件的恒真率 ===")
print(f"  {'条件':>26} {'成立占比%':>12}  评价")
for name, cond in [
    ("close > MA20", sma(close, 20) > 0),
    ("close > MA50", sma(close, 50) > 0),
    ("close > MA200", sma(close, 200) > 0),
    ("close > MA20*1.1", close > sma(close, 20) * 1.1),
    ("close > MA50*1.2", close > sma(close, 50) * 1.2),
    ("close > close[-30] (近30根涨)", np.r_[np.full(30, False), close[30:] > close[:-30]]),
    ("close > close[-90] (近90根涨)", np.r_[np.full(90, False), close[90:] > close[:-90]]),
]:
    ok = ~np.isnan(cond)
    share = cond[ok].mean() * 100
    verdict = "恒真, 无信息" if share > 90 else ("偏置" if share > 75 else "可用")
    print(f"  {name:>26} {share:>11.2f}%  {verdict}")

print("\n=== 买入持有基准 (ETH 4H 全期) ===")
lr = np.r_[np.nan, np.log(close[1:] / close[:-1])]
lr = lr[~np.isnan(lr)]
BARS_PER_YEAR = 6 * 365     # 4H bar 每年根数
yrs = n / BARS_PER_YEAR
# v1.2 修正: ETH 暴涨暴跌, prod(1+r) 被单期极端波动污染, 必须用对数口径
cagr = np.exp(lr.sum() / yrs) - 1
print(f"  4H bar数={n}  期间={yrs:.2f}年")
print(f"  买入持有: 累计对数收益={lr.sum():.3f}  价格倍数={np.exp(lr.sum()):.1f}x")
print(f"  年化(对数口径) = {cagr*100:.1f}%")
print(f"  单bar均值={lr.mean()*1e4:.2f}bp  t={lr.mean()/(lr.std(ddof=1)/np.sqrt(len(lr))):.2f}")
print(f"  → ETH 在本窗口年化 +51.8% (6.74年 16.7倍)。如此强的 beta 下,")
print("    任何「条件为真时收益更高」的观察都可能只是 beta 的重述。")
print("    这是本轮最重要的教训: 先问「该条件有多罕见」, 再问「它有效吗」。")

print("\n=== 教训: 前几轮发现的「信号」逐条重审 ===")
print("""
  1. 「逢反弹沽空」     -> 被 D4 证伪 (反弹后继续涨 65.9%)
  2. 「TREND_DOWN 可拆分」-> 被可行性验证证伪 (两组都是正收益)
  3. 「重回均线是 alpha」 -> 被本脚本证伪 (99.87% 恒真 = beta)
  4. 「状态门控 TREND_DOWN」-> 仍有效, 但它是事后观察 (后视镜风险),
     且其效果可能同样部分来自 beta: TREND_DOWN 后 5 日 +144bp,
     与买入持有的同期 beta 无法直接分离。
""")
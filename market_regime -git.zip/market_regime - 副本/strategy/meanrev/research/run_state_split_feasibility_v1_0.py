# -*- coding: utf-8 -*-
"""状态拆分可行性验证 v1.0 —— 能否因果区分「下跌中」与「暴跌后反弹」.

============================================================================
版本: v1.0  日期: 2026-10-10
背景: 用户决定把 TREND_DOWN 拆分为两个状态。拆分的前提是二者能被因果区分,
      否则拆分无意义。本脚本先验证可分性, 再谈实现。

假设 (来自 DEF1 诊断):
  H1 当前 TREND_DOWN 混入了两类 bar: 「下跌延续段」与「暴跌后反弹段」
  H2 二者的事前特征可区分: 反弹段的「下跌动能已衰竭」特征更明显
      (ret20 由负转正 / 短期跌幅收窄 / 价格重回短期均线之上)
  H3 二者的后续收益符号相反: 下跌段负, 反弹段正

验证方法 (严格因果, 特征只用 t 及之前):
  用当前 TREND_DOWN 的 bar, 按「事前可观测的反弹特征」分组, 看后续收益是否分裂。
  分组变量只用 t 时刻已知信息, 绝不用 t 之后的数据。
============================================================================
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
sys.path.insert(0, ROOT)
from market_regime.features import build_features

ANN = 6 * 365

df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

W = pd.read_csv(os.path.join(ROOT, "data/states/WF_4H_rule_states.csv"))
W["dt"] = pd.to_datetime(W.dt, utc=True)
st = W.state.values
close = W.close.values
n = len(W)

X = build_features(df, bar="4H")
valid = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
warm = int(valid[0])
Xs = X.iloc[warm:].reset_index(drop=True)
states = st[warm:]
close_w = Xs.index  # 对齐用
close = close[warm:]
n = len(Xs)

lr = np.r_[np.nan, np.log(close[1:] / close[:-1])]


def fwd(idx, k):
    idx = idx[(idx + k) < len(close)]
    return np.log(close[idx + k] / close[idx])


td = np.where(states == "TREND_DOWN")[0]
print(f"=== 当前 TREND_DOWN 样本: n={len(td)} ({len(td)/n*100:.1f}%) ===")

# ---------------- 因果反弹特征 (只用 t 及之前) ----------------
ret5 = Xs["ret_5"].values      # 近5根(20h)收益
ret20 = Xs["ret_20"].values    # 近20根(3.3日)收益
sma20 = Xs["sma20_dist"].values  # 距20周期均线 (已按波动标准化)
sma60 = Xs["sma60_dist"].values
slope = Xs["trend_slope"].values

print("\n=== 特征在 TREND_DOWN 内的分布 (检验 H2: 反弹特征是否双峰) ===")
feats = {
    "ret_5": ret5, "ret_20": ret20,
    "sma20_dist": sma20, "sma60_dist": sma60, "trend_slope": slope,
}
for name, v in feats.items():
    x = v[td]
    x = x[~np.isnan(x)]
    qs = np.percentile(x, [10, 25, 50, 75, 90])
    print(f"  {name:>12}: p10={qs[0]:>8.3f} p25={qs[1]:>8.3f} "
          f"p50={qs[2]:>8.3f} p75={qs[3]:>8.3f} p90={qs[4]:>8.3f}")

# ---------------- 核心检验: 按「价格是否重回20周期均线之上」分组 ----------------
print("\n=== 核心可分性检验 (H3) ===")
print("  分组变量 (t 时刻已知, 因果): 价格在 20 周期均线之上 vs 之下\n")
above = sma20[td] > 0
below = ~above

groups = [
    ("跌破均线(继续下跌)", td[below]),
    ("重回均线(反弹确认)", td[above]),
]
print(f"  {'分组':>22} {'n':>6} {'后24h':>10} {'t':>7} {'后5日':>10} {'t':>7} {'后15日':>10} {'t':>7}")
for lab, idx in groups:
    if len(idx) < 20:
        print(f"  {lab:>22} {len(idx):>6}  样本不足")
        continue
    line = f"  {lab:>22} {len(idx):>6}"
    for k in [6, 30, 90]:
        f = fwd(idx, k)
        f = f[~np.isnan(f)]
        if len(f) < 20:
            line += f" {'n/a':>10} {'-':>7}"
            continue
        t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
        line += f" {f.mean()*1e4:>9.1f}bp {t:>6.2f}"
    print(line)

# ---------------- 第二个切分: 按 20 根收益是否转正 ----------------
print("\n  切分二: 近20根(3.3日)收益 ret20 是否由负转正\n")
neg20 = ret20[td] < 0
pos20 = ~neg20
groups2 = [("ret20<0 (持续弱)", td[neg20]), ("ret20>0 (已转强)", td[pos20])]
print(f"  {'分组':>22} {'n':>6} {'后24h':>10} {'t':>7} {'后5日':>10} {'t':>7} {'后15日':>10} {'t':>7}")
for lab, idx in groups2:
    if len(idx) < 20:
        print(f"  {lab:>22} {len(idx):>6}  样本不足")
        continue
    line = f"  {lab:>22} {len(idx):>6}"
    for k in [6, 30, 90]:
        f = fwd(idx, k)
        f = f[~np.isnan(f)]
        if len(f) < 20:
            line += f" {'n/a':>10} {'-':>7}"
            continue
        t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
        line += f" {f.mean()*1e4:>9.1f}bp {t:>6.2f}"
    print(line)

# ---------------- 组合切分: 均线位置 x ret20 符号 ----------------
print("\n  组合切分 (四象限):\n")
print(f"  {'分组':>26} {'n':>6} {'后24h':>10} {'t':>7} {'后5日':>10} {'t':>7}")
combos = [
    ("跌破均线 & ret20<0", td[below & neg20]),
    ("跌破均线 & ret20>0", td[below & pos20]),
    ("重回均线 & ret20<0", td[above & neg20]),
    ("重回均线 & ret20>0", td[above & pos20]),
]
for lab, idx in combos:
    if len(idx) < 15:
        print(f"  {lab:>26} {len(idx):>6}  样本不足")
        continue
    line = f"  {lab:>26} {len(idx):>6}"
    for k in [6, 30]:
        f = fwd(idx, k)
        f = f[~np.isnan(f)]
        t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
        line += f" {f.mean()*1e4:>9.1f}bp {t:>6.2f}"
    print(line)

# ---------------- 对照: 同样切分在其他状态上是否有效 ----------------
print("\n=== 对照检验: 该切分在其他状态上是否也有区分力 (特异性) ===")
print(f"  {'状态':>12} {'分组':>16} {'n':>6} {'后5日':>10} {'t':>7}")
for s in ["TREND_UP", "RANGE_CALM", "HIGH_VOL"]:
    idx0 = np.where(states == s)[0]
    ab = sma20[idx0] > 0
    for lab, sub in [("重回均线", idx0[ab]), ("跌破均线", idx0[~ab])]:
        if len(sub) < 15:
            continue
        f = fwd(sub, 30)
        f = f[~np.isnan(f)]
        t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
        print(f"  {s:>12} {lab:>16} {len(sub):>6} {f.mean()*1e4:>9.1f}bp {t:>6.2f}")

# ---------------- 结论 ----------------
print("\n=== 结论 ===")
f_a = fwd(td[above], 30)
f_b = fwd(td[below], 30)
f_a, f_b = f_a[~np.isnan(f_a)], f_b[~np.isnan(f_b)]
t_a = f_a.mean() / (f_a.std(ddof=1) / np.sqrt(len(f_a)))
t_b = f_b.mean() / (f_b.std(ddof=1) / np.sqrt(len(f_b)))
diff = f_a.mean() - f_b.mean()
se = np.sqrt(f_a.var(ddof=1) / len(f_a) + f_b.var(ddof=1) / len(f_b))
print(f"  「重回均线」后5日均值 = {f_a.mean()*1e4:.1f}bp (t={t_a:.2f})")
print(f"  「跌破均线」后5日均值 = {f_b.mean()*1e4:.1f}bp (t={t_b:.2f})")
print(f"  两组差异 = {diff*1e4:.1f}bp, 差异 t = {diff/se:.2f}")
if diff / se > 2:
    print("  → 差异显著: 可以拆分 (H2/H3 成立)")
elif diff / se > 1:
    print("  → 差异弱: 拆分有风险, 需更严格的因果分组")
else:
    print("  → 无显著差异: 不可拆分, TREND_DOWN 是一个整体")
# -*- coding: utf-8 -*-
"""S3 组合价值验证 v1.0 —— 检验「状态门控能否让 S1 复利路径变好」.

============================================================================
版本: v1.0  日期: 2026-10-10
目的: 用户的核心猜想 —— 「S1 只在特定市场状态赚钱, 用状态识别组件让
      不同状态用不同策略, 可获得更多收益」。本脚本先验证该猜想的第一环:
      给 S1 加状态门控, 能否改善其自身的复利路径 (回撤/存活/CAGR)。
方法: 直接用 S1 全量回测逐笔 (研究口径), 叠加 4H hybrid 状态, 做门控反事实。
      这是逐笔级别的精确检验, 不依赖任何拟合参数。
口径: 与 S1 绩效表一致 (taker+滑点研究口径, LEV 档位可选)
============================================================================
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import s2_engine_v1_2 as E12

HERE = os.path.dirname(os.path.abspath(__file__))
df4 = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df4["dt"] = pd.to_datetime(df4.ts, unit="ms", utc=True)
st1 = E12.load_states("1H")
state4 = E12.states_for(df4, st1, bar_hours=4.0)   # 每根4H决策时刻的hybrid状态

LEV = 1.5
FEE = E12.FEE_TAKER
SLIP = E12.SLIP

# 跑 S1 全量
tr, curve = E12.run_turtle(df4, lev=LEV, equity0=30.0, fee=FEE,
                           funding=E12.FUND_8H, slip=SLIP)
closed = [t for t in tr if t.get("close_ts") is not None]

# 逐笔对齐开仓状态 (open_j 是 bar 索引)
rows = []
for t in closed:
    oj = t["open_j"]
    rows.append(dict(
        open_ts=t["open_ts"], close_ts=t["close_ts"], dir=t["dir"],
        ret=t["pnl"] / t["eq_at_open"], pnl=t["pnl"],
        eq_at_open=t["eq_at_open"], state=state4[oj] if oj < len(state4) else "NA",
    ))
df = pd.DataFrame(rows)
df["year"] = pd.to_datetime(df.open_ts, unit="ms", utc=True).dt.year
print(f"=== S1 逐笔 + 状态 (LEV={LEV}, n={len(df)}) ===")


def gated_stats(keep_states, label):
    """按开仓状态筛选, 逐笔复利算绩效 (窗口内从第一笔重整为 1.0)."""
    if keep_states is None:
        sub = df
    else:
        sub = df[df.state.isin(keep_states)]
    if len(sub) == 0:
        return None
    r = sub.ret.values
    eq = np.cumprod(1 + r)                      # 复利权益曲线
    years = (sub.close_ts.iloc[-1] - sub.open_ts.iloc[0]) / 86_400_000 / 365.25
    cagr = eq[-1] ** (1 / max(years, 1e-9)) - 1
    mdd = (eq / np.maximum.accumulate(eq) - 1).min()
    wins = r > 0
    pf = r[wins].sum() / abs(r[~wins].sum()) if (~wins).any() else np.inf
    under = (eq < np.maximum.accumulate(eq)).mean()
    t_stat = r.mean() / (r.std(ddof=1) / np.sqrt(len(r))) if len(r) > 2 and r.std(ddof=1) > 0 else np.nan
    return dict(label=label, n=len(sub), win_pct=wins.mean() * 100,
                avg_pct=r.mean() * 100, t_stat=t_stat, pf=pf,
                final_mult=eq[-1], cagr_pct=cagr * 100, maxdd_pct=mdd * 100,
                underwater_pct=under * 100,
                sum_R_note=f"合计R={r.sum():.1f}")


# ---------------- 状态分布 ----------------
print("\n=== S1 逐笔按开仓状态分布 ===")
dist = df.groupby("state").agg(n=("ret", "size"),
                               sum_ret=("ret", "sum"),
                               win=("ret", lambda x: (x > 0).mean() * 100))
dist["contrib_pct"] = dist.sum_ret / df.ret.sum() * 100
print(dist.round(2).to_string())

# ---------------- 门控方案对比 ----------------
print("\n=== 状态门控方案对比 (逐笔复利, 从窗口首笔重整) ===")
schemes = [
    (None, "实际 (全部交易)"),
    (["TREND_UP"], "仅 TREND_UP"),
    (["TREND_UP", "HIGH_VOL"], "TREND_UP+HIGH_VOL"),
    (["TREND_UP", "HIGH_VOL", "RANGE_CALM"], "TREND_UP+HIGH_VOL+RANGE_CALM"),
    (["TREND_UP", "HIGH_VOL", "RANGE_CALM", "TRANSITION"], "排除TREND_DOWN"),
    (["TREND_UP", "HIGH_VOL", "RANGE_CALM", "TRANSITION", "TREND_DOWN"], "全状态(对照)"),
]
result = [gated_stats(ks, lb) for ks, lb in schemes]
res = pd.DataFrame([x for x in result if x])
print(res[["label", "n", "win_pct", "avg_pct", "t_stat", "pf",
           "final_mult", "cagr_pct", "maxdd_pct"]].round(2).to_string(index=False))

# ---------------- 30U 实际滚利路径 (逐笔复利, 起始30U) ----------------
print("\n=== 30U 起始实际复利路径 (逐笔复利, LEV=1.5) ===")
def path_stats(keep_states, label):
    sub = df if keep_states is None else df[df.state.isin(keep_states)]
    r = sub.ret.values
    eq = 30.0 * np.cumprod(1 + r)
    years = (sub.close_ts.iloc[-1] - sub.open_ts.iloc[0]) / 86_400_000 / 365.25
    mdd = (eq / np.maximum.accumulate(eq) - 1).min()
    print(f"  {label:>28}: 期末={eq[-1]:>7.1f}U ({eq[-1]/30:.1f}倍) "
          f"CAGR={((eq[-1]/30)**(1/years)-1)*100:>5.1f}% maxDD={mdd*100:>6.1f}%")

for ks, lb in schemes[:4]:
    path_stats(ks, lb)

# ---------------- 关键洞察: 各状态单状态表现 ----------------
print("\n=== S1 在每个状态下的独立表现 (单状态门控) ===")
for st in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL", "TRANSITION"]:
    sub = df[df.state == st]
    if len(sub) == 0:
        continue
    r = sub.ret.values
    eq = 30.0 * np.cumprod(1 + r)
    years = (sub.close_ts.iloc[-1] - sub.open_ts.iloc[0]) / 86_400_000 / 365.25
    cagr = (eq[-1] / 30) ** (1 / max(years, 1e-9)) - 1
    mdd = (eq / np.maximum.accumulate(eq) - 1).min()
    print(f"  {st:>12}: n={len(sub):>3} 胜率={ (r>0).mean()*100:>4.1f}% "
          f"合计R={r.sum():>6.1f} 累计倍数={eq[-1]/30:>5.1f}x "
          f"CAGR={cagr*100:>6.1f}% maxDD={mdd*100:>6.1f}%")

# ---------------- 结论要点 ----------------
print("\n=== 结论 ===")
td = df[df.state == "TREND_DOWN"]
if len(td) > 0:
    print(f"  • TREND_DOWN 开仓 {len(td)} 笔, 合计R={td.ret.sum():.1f}, "
          f"胜率={(td.ret>0).mean()*100:.1f}%  ← 该状态是 S1 的亏损源")
tu = df[df.state == "TREND_UP"]
if len(tu) > 0:
    print(f"  • TREND_UP 开仓 {len(tu)} 笔, 合计R={tu.ret.sum():.1f}, "
          f"胜率={(tu.ret>0).mean()*100:.1f}%  ← 利润来源")
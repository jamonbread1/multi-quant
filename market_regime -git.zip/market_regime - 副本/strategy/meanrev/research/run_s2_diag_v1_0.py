# -*- coding: utf-8 -*-
"""S2 诊断 v1.0 —— 为什么带状均值回归亏损: 毛收益/成本/离场结构归因.

对象: 配置 01 (bb20_rc_both) 与 09 (don24_rc_both)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import s2_engine_v1_1 as E11

HERE = os.path.dirname(os.path.abspath(__file__))
WIN_START = pd.Timestamp("2021-02-01", tz="UTC")
WIN_END = pd.Timestamp("2026-10-10", tz="UTC")

df4 = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df4["dt"] = pd.to_datetime(df4.ts, unit="ms", utc=True)
st1 = E11.load_states("1H")
state4 = E11.states_for(df4, st1, bar_hours=4.0)

def C(name, **kw):
    base = dict(name=name, bar="4H", entry="bb", bb_n=20, bb_k=2.0,
                stop_mult=2.0, max_bars=12, direction="both",
                gate="RANGE_CALM", lev=1.0, equity0=30.0)
    base.update(kw)
    return E11.MRConfig(**base)

for cfg, label in [(C("01"), "01_bb20_rc_both"),
                   (C("09", entry="donchian_rev", don_n=24), "09_don24_rc_both")]:
    print(f"\n================ {label} ================")
    # 净成本版 (研究口径) vs 零成本版
    for cost_name, fee, slip, fund in [("净(研究成本)", E11.FEE_TAKER + E11.SLIP, 0.0, E11.FUND_8H),
                                       ("毛(零成本)", 0.0, 0.0, 0.0)]:
        tr, _ = E11.run_mr(df4, state4, cfg, fee=fee, slip=slip, funding=fund)
        ws = int(WIN_START.timestamp() * 1e3); we = int(WIN_END.timestamp() * 1e3)
        closed = [t for t in tr if t.get("close_ts") is not None and ws <= t["close_ts"] <= we]
        rets = np.array([t["pnl"] / t["eq_at_open"] for t in closed])
        tstat = rets.mean() / (rets.std(ddof=1) / np.sqrt(len(rets)))
        print(f"  [{cost_name}] n={len(closed)} 胜率={float((rets>0).mean()*100):.1f}% "
              f"均笔={float(rets.mean()*100):+.3f}% t={float(tstat):+.2f} "
              f"总收益={float(((1+rets).prod()-1)*100):+.1f}%")
    # 离场结构 (净成本版)
    tr, _ = E11.run_mr(df4, state4, cfg, fee=E11.FEE_TAKER + E11.SLIP, funding=E11.FUND_8H)
    ws = int(WIN_START.timestamp() * 1e3); we = int(WIN_END.timestamp() * 1e3)
    closed = [t for t in tr if t.get("close_ts") is not None and ws <= t["close_ts"] <= we]
    dfc = pd.DataFrame(closed)
    dfc["ret"] = dfc.pnl / dfc.eq_at_open
    dfc["year"] = pd.to_datetime(dfc.close_ts, unit="ms", utc=True).dt.year
    print("  离场理由分布:")
    print(dfc.groupby("reason").agg(n=("ret", "size"), avg_ret=("ret", lambda x: float(x.mean()*100)),
                                    win=("ret", lambda x: float((x>0).mean()*100))).round(2).to_string())
    print("  分年度 均笔% / 笔数 / 胜率%:")
    print(dfc.groupby("year").agg(n=("ret","size"), avg=("ret", lambda x: round(float(x.mean()*100),2)),
                                  win=("ret", lambda x: round(float((x>0).mean()*100),1))).to_string())
    # 盈亏尾部结构
    print(f"  最好3笔: {[round(float(x*100),1) for x in dfc.ret.nlargest(3)]} "
          f"最差3笔: {[round(float(x*100),1) for x in dfc.ret.nsmallest(3)]}")

# -*- coding: utf-8 -*-
"""状态定义诊断 v1.0 —— 为什么 TREND_DOWN 语义反转 + TRANSITION 缺失.

============================================================================
版本: v1.0  日期: 2026-10-10
背景: walk-forward 状态验证 (run_state_accuracy_v1_0.py) 发现两个定义缺陷:
  DEF1 TREND_DOWN 语义反转: 设计应为「下跌趋势延续期」, 实测却是正收益
        (年化+84.6%, Sharpe0.97, 后5日 t=+6.92), 实际是「下跌后的反弹期」。
  DEF2 TRANSITION 占比 0%: 规则检测器从不出该状态, 降敞口机制失效。
本脚本定位根因, 为修复提供依据 (不含任何拟合)。

诊断项:
  R1 TREND_DOWN 的构成: 哪些 bar 被判为 TREND_DOWN, 它们的收益/回撤如何
  R2 TREND_DOWN 前置路径: 进入该状态前发生了什么 (是暴跌后还是缓跌中)
  R3 TREND_DOWN vs HIGH_VOL 的混淆: 两者是否在互相误捕
  R4 HIGH_VOL 才是真下跌期吗: HIGH_VOL 实测负收益(-115%), 检查其语义
  R5 TRANSITION 为何缺席: 决策树上是否可达
  R6 方向对称性检验: 下跌判定与上涨判定是否对称 (多空是否平衡)
============================================================================
"""
import os
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
ANN = 6 * 365

df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

W = pd.read_csv(os.path.join(ROOT, "data/states/WF_4H_rule_states.csv"))
W["dt"] = pd.to_datetime(W.dt, utc=True)
st = W.state.values
dt = W.dt.values
close = W.close.values
n = len(W)

lr = np.r_[np.nan, np.log(close[1:] / close[:-1])]


def fwd(idx, k):
    ok = idx + k < n
    return np.log(close[idx[ok] + k] / close[idx[ok]])


def back(idx, k):
    ok = idx - k >= 0
    return np.log(close[idx[ok]] / close[idx[ok] - k])


# ---------------- R1 TREND_DOWN 构成 ----------------
print("=== R1 TREND_DOWN 的构成 (n=%, 实测) ===")
td = np.where(st == "TREND_DOWN")[0]
hv = np.where(st == "HIGH_VOL")[0]
tu = np.where(st == "TREND_UP")[0]
rc = np.where(st == "RANGE_CALM")[0]
print(f"  TREND_DOWN n={len(td)} ({len(td)/n*100:.1f}%)")
for k, lab in [(1, "后1bar"), (6, "后24h"), (30, "后5日"), (90, "后15日")]:
    f = fwd(td, k)
    t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
    print(f"    {lab:>7}: 均值={f.mean()*1e4:>8.2f}bp  t={t:>6.2f}")
print("  → 后5日/15日为正 = 下跌后的反弹期 (非下跌延续)")

# ---------------- R2 TREND_DOWN 前置路径 ----------------
print("\n=== R2 TREND_DOWN 前置路径 (进入该状态前发生了什么) ===")
for k, lab in [(6, "前24h"), (30, "前5日"), (90, "前15日"), (180, "前30日")]:
    b = back(td, k)
    t = b.mean() / (b.std(ddof=1) / np.sqrt(len(b)))
    print(f"  {lab:>7}: 均值={b.mean()*1e4:>8.2f}bp  t={t:>6.2f}")
print("  → 前置大幅下跌 => 状态是在暴跌之后才点亮 (滞后确认)")

# 暴跌后亮起的比例
td_enter = np.where((st == "TREND_DOWN") &
                    np.r_[True, st[1:] != st[:-1]])[0]
big_drop = np.zeros(n, dtype=bool)
big_drop[180:] = np.log(close[180:] / close[:-180]) < -0.10
ratio = big_drop[td_enter].mean() * 100 if len(td_enter) else 0
print(f"\n  TREND_DOWN 首次点亮次数={len(td_enter)}, 其中前30日跌超10%的比例={ratio:.1f}%")

# ---------------- R3 TREND_DOWN vs HIGH_VOL ----------------
print("\n=== R3 TREND_DOWN 与 HIGH_VOL 的对比 (是否互相混淆) ===")
print(f"  {'状态':>12} {'n':>6} {'后5日bp':>10} {'t':>7} {'波动bp':>9} {'占比%':>7}")
for s, idx in [("TREND_DOWN", td), ("HIGH_VOL", hv), ("TREND_UP", tu), ("RANGE_CALM", rc)]:
    f = fwd(idx, 30)
    t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
    v = lr[idx]
    v = v[~np.isnan(v)]
    print(f"  {s:>12} {len(idx):>6} {f.mean()*1e4:>10.2f} {t:>7.2f} "
          f"{v.std(ddof=1)*1e4:>9.1f} {len(idx)/n*100:>6.1f}")

# ---------------- R4 HIGH_VOL 语义 ----------------
print("\n=== R4 HIGH_VOL 是否才是「真下跌期」 ===")
for k, lab in [(6, "后24h"), (30, "后5日")]:
    f = fwd(hv, k)
    t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
    print(f"  HIGH_VOL {lab:>6}: 均值={f.mean()*1e4:>8.2f}bp  t={t:>6.2f}")
print("  → HIGH_VOL 后收益为负, 是唯一真正的高波动下跌段")

# 波动率对照
print("\n  状态内年化波动率对照:")
for s, idx in [("TREND_DOWN", td), ("HIGH_VOL", hv), ("TREND_UP", tu), ("RANGE_CALM", rc)]:
    v = lr[idx]
    v = v[~np.isnan(v)]
    print(f"    {s:>12}: {v.std(ddof=1)*np.sqrt(ANN)*100:>6.1f}%")

# ---------------- R5 TRANSITION 为何缺席 ----------------
print("\n=== R5 TRANSITION 决策路径分析 ===")
print("  规则引擎优先序: HIGH_VOL(crisis) > HIGH_VOL(high) > TREND_UP > TREND_DOWN > RANGE_CALM")
print("  TRANSITION 只在 hybrid 三检测器 1-1-1 分裂时降级产生, 规则引擎本身不输出。")
print("  → 验证: hybrid 输出中 TRANSITION 占比")
hs = pd.read_csv(os.path.join(ROOT, "data/states/ETH-USDT-SWAP_1H_states.csv"))
print(f"  1H hybrid 全样本 TRANSITION 占比: {(hs.state_hybrid=='TRANSITION').mean()*100:.2f}%")
print("  → walk-forward 下规则引擎独占决策, TRANSITION 结构上不可达")

# ---------------- R6 方向对称性 ----------------
print("\n=== R6 方向对称性 (多空判定是否平衡) ===")
import sys
sys.path.insert(0, ROOT)
from market_regime.features import build_features

X = build_features(df, bar="4H")
valid = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
warm = int(valid[0])
Xs = X.iloc[warm:].reset_index(drop=True)

direction = (0.45 * Xs["sma60_dist"].clip(-3, 3)
             + 0.35 * (Xs["trend_slope"] * Xs["trend_r2"]).clip(-3, 3)
             + 0.20 * Xs["hh_hl_score"].clip(-1, 1))
adx_gate = 0.35 + 0.65 * ((Xs["adx_14"] - 12) / 18).clip(0, 1)
tscore = direction * adx_gate
adx14 = Xs["adx_14"].values

t_th = np.nanquantile(np.abs(tscore), 0.68)
v_score = (0.7 * Xs["vol_pct_252"].fillna(0.5)
           + 0.3 * (Xs["vol_ratio"] - 1).clip(-1, 3) / 3).clip(0, 1).values
v_hi = np.nanquantile(v_score, 0.75)
v_cr = np.nanquantile(v_score, 0.90)

up_cond = (tscore.values >= t_th) & (adx14 >= 18)
dn_cond = (tscore.values <= -t_th) & (adx14 >= 18)
print(f"  趋势分阈值 t_th={t_th:.3f}  波动阈值 v_hi={v_hi:.3f} v_cr={v_cr:.3f}")
print(f"  原始信号: TREND_UP条件满足={up_cond.sum():>5} bar "
      f"({up_cond.mean()*100:>5.2f}%)")
print(f"  原始信号: TREND_DOWN条件满足={dn_cond.sum():>5} bar "
      f"({dn_cond.mean()*100:>5.2f}%)")
print(f"  → 多空信号比 = {up_cond.sum()/max(dn_cond.sum(),1):.2f}")

# trend_slope 与 ret20 的符号一致性 (根因)
print("\n  trend_slope 与 ret20 符号一致性 (TREND_DOWN 判定依据):")
ts_slope = Xs["trend_slope"].values
ret20 = Xs["ret_20"].values
ok = ~np.isnan(ts_slope) & ~np.isnan(ret20)
agree_neg = ((ts_slope < 0) & (ret20 < 0))[ok].mean() * 100
agree_pos = ((ts_slope > 0) & (ret20 > 0))[ok].mean() * 100
print(f"    slope<0 且 ret20<0 (同向下跌): {agree_neg:.1f}%")
print(f"    slope>0 且 ret20>0 (同向上涨): {agree_pos:.1f}%")
print("    → 若下跌侧同向率显著低于上涨侧, 说明下跌判定被污染")

# ret20 与 后续收益的领先性
print("\n  ret20(20根回看) 作为下跌确认指标的有效性:")
sel = ok & (ret20 < 0)
idx20 = np.where(sel)[0]
for k, lab in [(30, "后5日"), (90, "后15日")]:
    f = fwd(idx20[:len(idx20)], k)
    f = f[f == f]
    if len(f) > 30:
        t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
        print(f"    ret20<0 的bar, {lab:>6}: 均值={f.mean()*1e4:>8.2f}bp  t={t:>6.2f}")
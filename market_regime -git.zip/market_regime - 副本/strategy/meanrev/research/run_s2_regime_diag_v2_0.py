# -*- coding: utf-8 -*-
"""S2 诊断 v2.0 —— TREND_DOWN 状态的机制勘察 (S2 定位的依据).

============================================================================
版本: v2.0  日期: 2026-10-10
背景: S3 组合验证发现 S1 唯一系统性亏损状态是 TREND_DOWN (39笔, 胜率28%,
      -6.9R)。但该结论来自历史回顾, 存在后视镜风险, 不能直接当门控规则。
      本脚本先回答一个前置问题: TREND_DOWN 状态本身是否具备可交易结构,
      以及 S1 在其中亏损的机制是什么。
方法: 全部为因果/描述性度量, 不含任何拟合参数, 不产生策略结论。

五项勘察:
  D1 状态持续结构: 段长/切换频率/占比 (有没有「足够收费」的时间)
  D2 状态内收益分布: 该状态是否真的负收益 (能否做空赚钱)
  D3 收益自相关: 负自相关=回归, 正自相关/零=趋势持续 (决定做哪类策略)
  D4 反弹结构: 上涨 bar 后是否倾向继续下跌 (检验「逢反弹沽空」机制)
  D5 S1 在该状态的亏损机制: 逐笔看是止损多还是亏损大
============================================================================
"""
import os
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

st = pd.read_csv(os.path.join(ROOT, "data/states/ETH-USDT-SWAP_1H_states.csv"))
st = st.sort_values("ts").reset_index(drop=True)
m = dict(zip(st.ts, st.state_hybrid))

# 4H bar 决策时刻 = ts + 3h (最后一根1H bar, 因果)
state = np.array([m.get(t + 3 * 3600000, "") for t in df.ts], dtype=object)

c = df.close.values
logret = np.r_[np.nan, np.log(c[1:] / c[:-1])]


def segments(mask):
    """连续段索引列表."""
    idx = np.where(mask)[0]
    if len(idx) == 0:
        return []
    brk = np.where(np.diff(idx) > 1)[0]
    starts = np.r_[idx[0], idx[brk + 1]]
    ends = np.r_[idx[brk], idx[-1]]
    return list(zip(starts, ends))


# ---------------- D1 状态持续结构 ----------------
print("=== D1 状态持续结构 (4H bar) ===")
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL", "TRANSITION"]:
    mask = state == s
    segs = segments(mask)
    if not segs:
        continue
    L = np.array([e - b + 1 for b, e in segs])
    print(f"  {s:>12}: 占比={mask.mean()*100:>5.1f}%  段数={len(segs):>4}  "
          f"段长中位={np.median(L):>5.0f}bar ({np.median(L)*4/24:>4.1f}天)  "
          f"均长={L.mean():>5.1f}bar  p90={np.percentile(L,90):>5.0f}  max={L.max()}")

# ---------------- D2 状态内收益分布 ----------------
print("\n=== D2 状态内收益分布 (每4H bar 对数收益) ===")
print(f"  {'状态':>12} {'n':>6} {'均值bp':>9} {'中位bp':>9} {'胜率%':>7} "
      f"{'年化%':>8} {'std bp':>9} {'t':>6}")
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL", "TRANSITION"]:
    r = logret[state == s]
    r = r[~np.isnan(r)]
    if len(r) < 10:
        continue
    t = r.mean() / (r.std(ddof=1) / np.sqrt(len(r)))
    ann = r.mean() * 6 * 365 * 100
    print(f"  {s:>12} {len(r):>6} {r.mean()*1e4:>9.2f} "
          f"{np.median(r)*1e4:>9.2f} {(r>0).mean()*100:>7.1f} "
          f"{ann:>8.1f} {r.std(ddof=1)*1e4:>9.1f} {t:>6.2f}")

# ---------------- D3 收益自相关 (决定策略类型) ----------------
print("\n=== D3 收益自相关 (lag1..5, 连续 bar 对) ===")
print(f"  {'状态':>12} " + " ".join(f"{'lag'+str(k):>8}" for k in range(1, 6)))
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL", "TRANSITION"]:
    idx = np.where(state == s)[0]
    idx = idx[idx > 10]
    acs = []
    for k in range(1, 6):
        a = logret[idx]
        b = logret[idx - k]
        ok = ~np.isnan(a) & ~np.isnan(b)
        acs.append(np.corrcoef(a[ok], b[ok])[0, 1] if ok.sum() > 30 else np.nan)
    print(f"  {s:>12} " + " ".join(f"{a:>8.4f}" for a in acs))

# ---------------- D4 反弹结构 (逢反弹沽空机制检验) ----------------
print("\n=== D4 反弹后走势 (TREND_DOWN 内) ===")
td = np.where(state == "TREND_DOWN")[0]
print("  条件: 在 TREND_DOWN 内, 过去5根累计涨幅 > +2% (反弹), 之后5根收益如何?")
for thr in [0.02, 0.03, 0.05]:
    fwd, hits = [], 0
    n_evt = 0
    for i in td:
        if i < 6 or i >= len(c) - 6:
            continue
        if state[i - 1] != "TREND_DOWN" or state[i] != "TREND_DOWN":
            continue
        past = np.log(c[i] / c[i - 5])
        if past > thr:
            n_evt += 1
            f = np.log(c[i + 5] / c[i])
            fwd.append(f)
            if f < 0:
                hits += 1
    if n_evt:
        fwd = np.array(fwd)
        print(f"    反弹>{thr*100:.0f}%: 事件={n_evt:>4}  "
              f"后5根均值={fwd.mean()*1e4:>8.2f}bp  "
              f"继续下跌概率={(fwd<0).mean()*100:>5.1f}%  "
              f"均值bp与继续下跌概率一致性={'YES' if (fwd.mean()<0)==(fwd<0).mean()>0.5 else 'NO'}")

print("\n  对照: 非TREND_DOWN 同样条件")
for thr in [0.02, 0.03]:
    fwd, n_evt = [], 0
    for i in range(6, len(c) - 6):
        if state[i] == "TREND_DOWN":
            continue
        past = np.log(c[i] / c[i - 5])
        if past > thr:
            n_evt += 1
            fwd.append(np.log(c[i + 5] / c[i]))
    if n_evt:
        fwd = np.array(fwd)
        print(f"    反弹>{thr*100:.0f}%: 事件={n_evt:>4}  "
              f"后5根均值={fwd.mean()*1e4:>8.2f}bp  继续下跌概率={(fwd<0).mean()*100:>5.1f}%")

# ---------------- D5 S1 在 TREND_DOWN 的亏损机制 ----------------
print("\n=== D5 S1 在 TREND_DOWN 的亏损机制 (真实日志) ===")
T = pd.read_csv(os.path.join(ROOT, "data/states/S1_trades_with_states.csv"))
td_tr = T[T.state_entry == "TREND_DOWN"]
oth = T[T.state_entry != "TREND_DOWN"]
print(f"  TREND_DOWN 开仓: n={len(td_tr)} 胜率={(td_tr.pnl_u>0).mean()*100:.1f}% "
      f"合计R={td_tr.pnl_r.sum():.1f}")
print(f"  其他状态开仓:   n={len(oth)} 胜率={(oth.pnl_u>0).mean()*100:.1f}% "
      f"合计R={oth.pnl_r.sum():.1f}")
print(f"  TREND_DOWN 方向: 多={(td_tr.side=='long').sum()} 空={(td_tr.side=='short').sum()}")
print(f"  TREND_DOWN 离场理由: {td_tr.exit_reason.value_counts().to_dict()}")
print(f"  其他状态离场理由:   {oth.exit_reason.value_counts().to_dict()}")
print(f"  TREND_DOWN 平均持仓={td_tr.bars_held.mean():.0f}根 vs 其他={oth.bars_held.mean():.0f}根")
print(f"  TREND_DOWN 中位单笔={td_tr.pnl_r.median():.2f}R vs 其他={oth.pnl_r.median():.2f}R")
print(f"  TREND_DOWN 最差单笔={td_tr.pnl_r.min():.2f}R vs 其他={oth.pnl_r.min():.2f}R")

# ---------------- D6 状态前置检验 (后视镜风险量化) ----------------
print("\n=== D6 后视镜风险: 状态在事前是否可区分? ===")
print("  检验: 各状态与其后1日/5日收益的条件均值 (即「现在处于该状态」对未来是否有信息量)")
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL", "TRANSITION"]:
    idx = np.where(state == s)[0]
    idx = idx[(idx + 30 < len(c)) & (idx >= 6)]
    if len(idx) < 10:
        continue
    f1 = np.log(c[idx + 6] / c[idx])     # 后6根=1日
    f5 = np.log(c[idx + 30] / c[idx])    # 后30根=5日
    f1 = f1[~np.isnan(f1)]
    f5 = f5[~np.isnan(f5)]
    print(f"  {s:>12} (n={len(idx):>5}): 后1日均值={f1.mean()*1e4:>8.2f}bp "
          f"(t={f1.mean()/(f1.std(ddof=1)/np.sqrt(len(f1))):>5.2f})  "
          f"后5日均值={f5.mean()*1e4:>8.2f}bp "
          f"(t={f5.mean()/(f5.std(ddof=1)/np.sqrt(len(f5))):>5.2f})")
# -*- coding: utf-8 -*-
"""临时调试3: 用 L3 逐笔盈亏判定 FMZ 成本模型 (是否模拟资金费/费率多少).

L3 行格式: [L3 本笔] stop | 多1.84张 @2723.96 止损距离142.5863 (26.24U) |
           离场2654.91 | 盈亏-12.705U = -0.48R
对每个引擎变体 (funding 0 / 0.004%/8h, fee 0.05%), 逐笔比较 pnl.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import s2_engine_v1_0 as E

L3_RE = None
import re
L3_RE = re.compile(
    r"\[L3 本笔\] (stop|signal) \| (多|空)([\d.]+)张 @([\d.]+) .*离场([\d.]+) \| "
    r"盈亏([+-][\d.]+)U = ([+-][\d.]+)R")

df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "eth4h_from_fmz_1h.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)

l3 = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = L3_RE.search(l)
        if m:
            l3.append(dict(reason=m.group(1), dir=1 if m.group(2) == "多" else -1,
                           qty=float(m.group(3)), entry=float(m.group(4)),
                           exit=float(m.group(5)), pnl=float(m.group(6)),
                           r=float(m.group(7))))
lg = pd.DataFrame(l3)
# 开仓行的权益序列 (与 L3 顺序配对)
eqs = E.parse_s1_log(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
                     "20200103000000-20261007000000.csv")
eq_open = eqs.eq_at_open.values
lg["eq_at_open"] = eq_open[:len(lg)]
print("L3 rows:", len(lg))

for name, funding in [("funding=0", 0.0), ("funding=0.004%/8h", E.FUND_8H)]:
    trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=E.FEE_TAKER,
                             funding=funding, slip=0.0)
    et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
    n = min(len(et), len(lg))
    e = et.iloc[:n].reset_index(drop=True)
    g = lg.iloc[:n].reset_index(drop=True)
    pnl_diff = e.pnl - g.pnl
    ret_e = e.pnl / e.eq_at_open
    ret_g = g.pnl / g.eq_at_open
    print(f"\n== {name} ==  n={n}")
    print(f"  reason match: {(e.reason == g.reason).mean():.4f}")
    print(f"  exit px match(<=0.01): {(e.exit - g.exit).abs().le(0.01).mean():.4f}")
    print(f"  pnl U diff: med={pnl_diff.median():+.4f} mean={pnl_diff.mean():+.4f} "
          f"|pnl diff|<=0.02U: {(pnl_diff.abs() <= 0.02).mean():.4f}")
    print(f"  收益率 diff(引擎-日志, 权益口径): med={(ret_e - ret_g).median():+.6f} "
          f"mean={(ret_e - ret_g).mean():+.6f}")
    print(f"  权益终值: 引擎 {e.eq_after.iloc[-1]:.2f} vs 日志(由收益率推) "
          f"{30 * (1 + ret_g).prod():.2f}")

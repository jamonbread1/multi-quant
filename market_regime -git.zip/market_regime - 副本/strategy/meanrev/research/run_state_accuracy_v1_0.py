# -*- coding: utf-8 -*-
"""状态识别准确性前向验证 v1.0 —— walk-forward, 严格无前视.

============================================================================
版本: v1.0  日期: 2026-10-10
目的: 用户要求「先做市场状态的准确性验证, 状态判断是顶层」。在把状态信号
      下发给策略之前, 必须先回答: 这个状态标签到底准不准? 稳不稳定?

      这是对 market_regime 组件本身的审计, 不是策略研究。

方法 (严格因果):
  1. 逐根 bar 前推 (walk-forward): 每次只用 t 之前的数据拟合, 预测 t
  2. 检验三件事:
     A. 预测一致性: 同一 bar 上 规则/HMM/GMM 三检测器是否同意
     B. 状态稳定性: t 时刻标签 vs t+1/t+4/t+24 标签的一致率 (抖动率)
     C. 经济含义: 各状态「事后」的条件表现是否与设计语义一致 (语义有效性)
        —— 注意 C 是事后验证语义, 不用于挑选门控规则 (那会有后视镜)
  3. 分训练段报告 vs 全样本, 看结论是否跨窗口稳健

关键纪律:
  - 拟合只用 [0, t), 解码只用 t
  - 规则检测器阈值用扩展窗分位数重算 (walk-forward)
  - HMM/GMM 用滚动窗口重拟合 (组件已内置)
输出: 数据/状态/*.csv 或 reports/ 下, 可复现
============================================================================
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
sys.path.insert(0, ROOT)

from market_regime.features import build_features
from market_regime.detectors.rules import RuleBasedDetector
from market_regime.taxonomy import States

BAR = "4H"
ANN = 6 * 365  # 4H bar 数年化


def load():
    df = pd.read_csv(os.path.join(ROOT, f"data/okx/ETH-USDT-SWAP_{BAR}.csv"))
    df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
    return df.sort_values("ts").reset_index(drop=True)


# ---------------- 规则检测器的 walk-forward 版本 ----------------
class WFRuleDetector:
    """每根 bar 用 [0,t) 的滚动窗重新校准阈值, 再对 t 解码."""

    def __init__(self, win=2000, confirm_bars=3, min_calib=400):
        self.win = win
        self.confirm_bars = confirm_bars
        self.min_calib = min_calib

    def scores(self, X):
        sc = pd.DataFrame(index=X.index)
        direction = (0.45 * X["sma60_dist"].clip(-3, 3)
                     + 0.35 * (X["trend_slope"] * X["trend_r2"]).clip(-3, 3)
                     + 0.20 * X["hh_hl_score"].clip(-1, 1))
        adx_gate = 0.35 + 0.65 * ((X["adx_14"] - 12) / 18).clip(0, 1)
        sc["trend_score"] = direction * adx_gate
        sc["vol_score"] = (0.7 * X["vol_pct_252"].fillna(0.5)
                           + 0.3 * (X["vol_ratio"] - 1).clip(-1, 3) / 3).clip(0, 1)
        return sc

    def run(self, X):
        n = len(X)
        sc = self.scores(X)
        trend = sc["trend_score"].values
        vol = sc["vol_score"].values
        adx = X["adx_14"].values
        ret20 = X["ret_20"].values

        states = np.array(["RANGE_CALM"] * n, dtype=object)
        conf = np.zeros(n)
        cur, pending, pcnt = "RANGE_CALM", None, 0

        for i in range(n):
            if i < self.min_calib:
                states[i] = cur
                conf[i] = 0.3
                continue
            # 只用 [i-win, i) 校准阈值 (不含 t)
            lo = max(0, i - self.win)
            t_hist = np.abs(trend[lo:i])
            t_hist = t_hist[~np.isnan(t_hist)]
            v_hist = vol[lo:i]
            v_hist = v_hist[~np.isnan(v_hist)]
            if len(t_hist) < 50 or len(v_hist) < 50:
                states[i] = cur
                conf[i] = 0.3
                continue
            t_th = np.quantile(t_hist, 0.68)
            v_hi = np.quantile(v_hist, 0.75)
            v_cr = np.quantile(v_hist, 0.90)

            t, v = trend[i], vol[i]
            if np.isnan(t) or np.isnan(v):
                states[i] = cur
                conf[i] = 0.3
                continue

            if v >= v_cr and (np.isnan(ret20[i]) or ret20[i] < 0):
                cand, strength = "HIGH_VOL", v
            elif v >= v_hi and abs(t) < t_th:
                cand, strength = "HIGH_VOL", v
            elif t >= t_th and adx[i] >= 18:
                cand, strength = "TREND_UP", t / t_th - 1
            elif t <= -t_th and adx[i] >= 18:
                cand, strength = "TREND_DOWN", -t / t_th - 1
            else:
                cand, strength = "RANGE_CALM", 1 - abs(t) / t_th

            if cand == cur:
                pending, pcnt = None, 0
                conf[i] = float(np.clip(0.5 + 0.25 * min(2, max(0, strength)), 0, 1))
            else:
                if pending == cand:
                    pcnt += 1
                else:
                    pending, pcnt = cand, 1
                if pcnt >= self.confirm_bars:
                    cur, pending, pcnt = cand, None, 0
                    conf[i] = float(np.clip(0.45 + 0.25 * min(2, max(0, strength)), 0, 0.9))
                else:
                    conf[i] = 0.4
            states[i] = cur
        return pd.DataFrame({"state": states, "confidence": conf}, index=X.index)


def main():
    df = load()
    X = build_features(df, bar=BAR)
    valid = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
    warm = int(valid[0])
    Xs = X.iloc[warm:].copy()
    o = df.iloc[warm:].reset_index(drop=True)
    print(f"=== 4H 数据 {len(df)} 根, 暖机跳过 {warm} 根, 有效 {len(Xs)} 根 ===")
    print(f"区间: {o.dt.iloc[0]} -> {o.dt.iloc[-1]}")

    # ---- walk-forward 规则检测 ----
    wf = WFRuleDetector()
    res = wf.run(Xs)
    states = res["state"].values
    conf = res["confidence"].values
    close = o["close"].values
    logret = np.r_[np.nan, np.log(close[1:] / close[:-1])]

    out = pd.DataFrame({
        "dt": o["dt"].values, "close": close, "state": states,
        "confidence": conf, "ret_next": np.r_[logret[1:], np.nan],
    })
    outp = os.path.join(ROOT, "data/states/WF_4H_rule_states.csv")
    out.to_csv(outp, index=False)
    print(f"[save] {outp}")

    # ---------------- A. 状态分布 ----------------
    print("\n=== A. walk-forward 状态分布 (前推, 无全样本拟合) ===")
    dist = pd.Series(states).value_counts(normalize=True).mul(100).round(2)
    for k, v in dist.items():
        print(f"  {k:>12}: {v:>5.2f}%")

    # ---------------- B. 状态稳定性 (抖动率) ----------------
    print("\n=== B. 状态稳定性: t 标签 vs t+k 标签 一致率 ===")
    print(f"  {'horizon':>10} {'一致率%':>9}  含义")
    for k, desc in [(1, "下一根4H"), (6, "24小时"), (30, "5天")]:
        if len(states) <= k:
            continue
        agree = (states[:-k] == states[k:]).mean() * 100
        print(f"  {str(k)+'bar':>10} {agree:>8.2f}%  与{desc}仍同状态")
    # 平均连续段长
    chg = np.r_[True, states[1:] != states[:-1]]
    seg_len = np.diff(np.where(chg)[0].tolist() + [len(states)])
    print(f"  平均段长 = {seg_len.mean():.1f} bar ({seg_len.mean()*4/24:.1f} 天), "
          f"中位 {np.median(seg_len):.0f} bar")

    # ---------------- C. 经济含义 (事后语义验证) ----------------
    print("\n=== C. 各状态事后条件表现 (验证语义是否成立; 事后, 不用于挑规则) ===")
    print(f"  {'状态':>12} {'n':>6} {'占比%':>7} {'年化%':>9} {'年化波动%':>10} "
          f"{'Sharpe':>7} {'胜率%':>7}")
    for s in States.names():
        m = states == s
        r = logret[m]
        r = r[~np.isnan(r)]
        if len(r) < 10:
            continue
        mu, sd = r.mean(), r.std(ddof=1)
        sharpe = mu / (sd + 1e-12) * np.sqrt(ANN)
        ann = mu * ANN * 100
        vol = sd * np.sqrt(ANN) * 100
        print(f"  {s:>12} {len(r):>6} {m.mean()*100:>6.2f}% {ann:>8.1f} "
              f"{vol:>9.1f} {sharpe:>7.2f} {(r>0).mean()*100:>6.1f}")

    # ---------------- D. 状态对未来是否有预测力 (top-level 核心) ----------------
    print("\n=== D. 状态对未来收益的预测力 (top-level 信号价值检验) ===")
    print(f"  {'状态':>12} {'horizon':>8} {'n':>6} {'均值bp':>9} {'t':>7}")
    for s in States.names():
        for k in [6, 30]:
            idx = np.where(states == s)[0]
            idx = idx[idx + k < len(close)]
            if len(idx) < 30:
                continue
            fwd = np.log(close[idx + k] / close[idx])
            t = fwd.mean() / (fwd.std(ddof=1) / np.sqrt(len(fwd)))
            print(f"  {s:>12} {str(k)+'bar':>8} {len(idx):>6} "
                  f"{fwd.mean()*1e4:>8.2f} {t:>7.2f}")

    # ---------------- E. 跨窗口稳健性 (分段表现) ----------------
    print("\n=== E. 跨窗口稳健性: 各年状态占比 (看标签是否稳定复现) ===")
    years = o["dt"].dt.year.values
    for y in sorted(set(years)):
        m = years == y
        row = pd.Series(states[m]).value_counts(normalize=True).mul(100)
        line = "  ".join(f"{k[:4]}={row.get(k,0):>4.0f}%" for k in States.names())
        print(f"  {y}: {line}")

    # ---------------- F. 置信度校准 ----------------
    print("\n=== F. 置信度校准 (高置信度是否真的更准=方向对) ===")
    conf_q = pd.qcut(pd.Series(conf), 5, labels=False, duplicates="drop")
    dfq = pd.DataFrame({"q": conf_q, "conf": conf, "state": states, "r": logret})
    for q in sorted(dfq["q"].dropna().unique()):
        g = dfq[dfq.q == q]
        g = g[g.r.notna()]
        if len(g) < 20:
            continue
        print(f"  置信度分位Q{int(q)+1} (均值={g.conf.mean():.2f}, n={len(g)}): "
              f"逐bar收益={g.r.mean()*1e4:>7.2f}bp")


if __name__ == "__main__":
    main()
# -*- coding: utf-8 -*-
"""S2 研究引擎 v1.2 —— v1.1 基础上新增 connors 入场族与 close-cross 出场.

================================================================================
版本: v1.2  日期: 2026-10-10
相对 v1.1 的改动 (新增, 不改动任何既有语义):

  N1 [新入场族] entry="connors": 顺大势逆小势 (Larry Connors RSI2 模式)
       多: close > SMA(slow_n) 且 RSI(rsi_n) < rsi_lo
       空: close < SMA(slow_n) 且 RSI(rsi_n) > rsi_hi (direction=both 时)
  N2 [新出场] target="sma_fast_close": 当根收盘上穿 SMA(fast_n) 则以 close[k]
       离场 (收盘确认型, 与 Connors 原版一致; 区别于 mid 的盘中触及型)

新增字段 (MRConfig): slow_n=200, fast_n=5
第一轮 14 配置结论见 docs/S2_扫描结果_v1.0.csv: 带状/通道均值回归
毛期望≈0 (t<0.4), 成本后稳定为负 —— 第二轮假设为趋势过滤回调买入。
================================================================================
"""
from s2_engine_v1_1 import *          # noqa: F401,F403
from s2_engine_v1_1 import (FEE_TAKER, SLIP, FUND_8H, CT_VAL, LOT,
                            atr_wilder, sma, bollinger, rsi, donchian_prev,
                            MRConfig, _mr_close, _equity_curve_from_trades)
import math
from typing import List
import numpy as np


# 扩展配置: 在 v1.1 MRConfig 上补 connors 字段
class MRConfig2(MRConfig):
    def __init__(self, *a, slow_n=200, fast_n=5, **kw):
        self.slow_n = slow_n
        self.fast_n = fast_n
        super().__init__(*a, **kw)


def run_mr2(df, state, cfg, fee=FEE_TAKER, slip=SLIP, funding=FUND_8H):
    """v1.2: 支持 entry=connors 与 target=sma_fast_close, 其余语义同 v1.1."""
    h, l, c, o = df.high.values, df.low.values, df.close.values, df.open.values
    ts = df.ts.values
    n = len(df)
    atr = atr_wilder(h, l, c, 14)
    hours = 4.0 if cfg.bar == "4H" else 1.0

    connors = cfg.entry == "connors"
    if connors:
        slow = sma(c, cfg.slow_n)
        fast = sma(c, cfg.fast_n)
        r = rsi(c, cfg.rsi_n)
        target_close = cfg.target == "sma_fast_close"
    elif cfg.entry in ("bb", "bb_rsi"):
        mid, ub, lb = bollinger(c, cfg.bb_n, cfg.bb_k)
        target_px = mid
        r = rsi(c, cfg.rsi_n) if cfg.entry == "bb_rsi" else None
    elif cfg.entry == "donchian_rev":
        hh, ll = donchian_prev(h, l, cfg.don_n)
        mid = (hh + ll) / 2.0
        ub, lb = hh, ll
        target_px = mid
        r = None
    else:
        raise ValueError(cfg.entry)

    allow = (set(x for x in cfg.gate.split(",") if x) if cfg.gate else None)
    eq = cfg.equity0
    trades: List[dict] = []
    d = 0
    qty = 0.0
    entry_px = 0.0
    stop = 0.0
    entry_j = -1
    cooldown_until = -1
    warm = (cfg.slow_n if connors else max(cfg.bb_n, cfg.don_n)) + 50

    for j in range(n):
        # ---------- 持仓管理 ----------
        if d != 0:
            eq -= qty * CT_VAL * entry_px * funding * (hours / 8.0)
            k = j
            exited = False
            if cfg.stop_mult > 0:
                if d > 0 and l[k] <= stop:
                    fill = min(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                elif d < 0 and h[k] >= stop:
                    fill = max(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and cfg.regime_exit and allow is not None and \
                    state[j] not in allow and j > entry_j:
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "regime", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and connors and target_close:
                if (d > 0 and c[k] > fast[k]) or (d < 0 and c[k] < fast[k]):
                    _mr_close(trades, ts, k, d, qty, entry_px, c[k], "target", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and not connors:
                tg = target_px[k]
                if tg == tg:
                    if d > 0 and h[k] >= tg:
                        fill = max(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                    elif d < 0 and l[k] <= tg:
                        fill = min(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and j - entry_j >= cfg.max_bars:
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "time", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if d == 0 and exited:
                cooldown_until = j + 1
        # ---------- 开仓 ----------
        if d == 0 and j >= warm and j > cooldown_until:
            ok_state = (allow is None) or (state[j] in allow)
            if not ok_state:
                continue
            want = 0
            if connors:
                if slow[j] == slow[j] and r[j] == r[j]:
                    if c[j] > slow[j] and r[j] < cfg.rsi_lo:
                        want = 1
                    elif c[j] < slow[j] and r[j] > cfg.rsi_hi:
                        want = -1
            elif cfg.entry in ("bb", "bb_rsi"):
                if mid[j] != mid[j]:
                    continue
                lo_ok = c[j] < lb[j] and (r is None or r[j] < cfg.rsi_lo)
                hi_ok = c[j] > ub[j] and (r is None or r[j] > cfg.rsi_hi)
                if lo_ok:
                    want = 1
                elif hi_ok:
                    want = -1
            else:  # donchian_rev
                if mid[j] != mid[j]:
                    continue
                if c[j] < ll[j]:
                    want = 1
                elif c[j] > hh[j]:
                    want = -1
            if want == -1 and cfg.direction == "long_only":
                want = 0
            if want != 0:
                notional = eq * cfg.lev
                q = round(math.floor(notional / (CT_VAL * c[j]) / LOT) * LOT, 8)
                if q > 0:
                    dist = min(cfg.stop_mult * atr[j], cfg.max_stop_pct * c[j]) \
                        if cfg.stop_mult > 0 else 0.0
                    d = want
                    qty, entry_px = q, c[j]
                    stop = c[j] - d * dist
                    entry_j = j
                    trades.append(dict(open_ts=ts[j], dir=d, qty=q, entry=c[j],
                                       eq_at_open=eq, stop=stop, open_j=j,
                                       atr=atr[j]))
    curve = _equity_curve_from_trades(trades, df)
    return trades, curve

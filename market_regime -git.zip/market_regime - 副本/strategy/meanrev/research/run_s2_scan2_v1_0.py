# -*- coding: utf-8 -*-
"""S2 第二轮先验候选扫描 v1.0 —— 趋势过滤回调买入 (Connors 式).

【多重检验声明】这是第二轮回。第一轮 14 个带状/通道均值回归配置全部为负
(毛期望≈0, docs/S2_扫描结果_v1.0.csv)。第二轮假设机制不同: 顺 SMA200 大势
买 RSI2 超卖回调, 吃正向漂移而非逆势抄底。两轮合计 20 个配置, 任何"通过"
的标准必须相应提高: t>2 + 邻域稳健 + 经济机制可解释, 否则一律视为噪声。

固定 6 个配置, 全部列出, 不挑选。
窗口/成本/口径与第一轮完全一致 (2021-02~2026-10, 研究成本, LEV=1.0)。
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import s2_engine_v1_2 as E12

HERE = os.path.dirname(os.path.abspath(__file__))
WIN_START = pd.Timestamp("2021-02-01", tz="UTC")
WIN_END = pd.Timestamp("2026-10-10", tz="UTC")


def win_stats(trades, curve, win_start, win_end, eq0=None, freq="4H"):
    """窗口内统计: 权益从窗口首笔开仓时点重整为 1.0 (与第一轮同口径)."""
    ws = int(win_start.timestamp() * 1000)
    we = int(win_end.timestamp() * 1000)
    closed = [t for t in trades if t.get("close_ts") is not None
              and ws <= t["close_ts"] <= we]
    if not closed:
        return dict(n=0)
    rets = np.array([t["pnl"] / t["eq_at_open"] for t in closed])
    eq_rel = float(np.prod(1 + rets))
    years = (closed[-1]["close_ts"] - closed[0]["open_ts"]) / 1e9 / 86400 / 365.25
    cagr = eq_rel ** (1 / max(years, 1e-9)) - 1
    wins = rets > 0
    pf = rets[wins].sum() / abs(rets[~wins].sum()) if (~wins).any() else np.inf
    tstat = rets.mean() / (rets.std(ddof=1) / np.sqrt(len(rets))) \
        if len(rets) > 2 and rets.std(ddof=1) > 0 else np.nan
    cv = curve.loc[win_start:win_end]
    cv = cv / cv.iloc[0]
    mdd = float((cv / cv.cummax() - 1).min())
    under = float((cv < cv.cummax()).mean())
    by_year = {}
    for t, r in zip(closed, rets):
        y = pd.Timestamp(t["close_ts"], unit="ms", tz="UTC").year
        by_year.setdefault(y, []).append(r)
    yearly = {int(y): float((1 + np.array(rs)).prod() - 1) * 100
              for y, rs in by_year.items()}
    return dict(n=len(closed), win_pct=float(wins.mean() * 100),
                avg_pct=float(rets.mean() * 100),
                med_pct=float(np.median(rets) * 100),
                t_stat=float(tstat), pf=float(pf),
                eq_rel_pct=float((eq_rel - 1) * 100),
                cagr_pct=float(cagr * 100), maxdd_pct=float(mdd * 100),
                underwater_pct=float(under * 100),
                avg_hold_bars=float(np.mean(
                    [(t["close_ts"] - t["open_ts"]) / 36e5 /
                     (4 if freq == "4H" else 1) for t in closed])),
                yearly=yearly)

df4 = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df4["dt"] = pd.to_datetime(df4.ts, unit="ms", utc=True)
df1 = E12.load_ohlcv("1H")
st1 = E12.load_states("1H")
state4 = E12.states_for(df4, st1, bar_hours=4.0)
state1 = E12.states_for(df1, st1, bar_hours=1.0)


def C(name, **kw):
    base = dict(name=name, bar="4H", entry="connors", target="sma_fast_close",
                rsi_n=2, rsi_lo=10.0, rsi_hi=90.0, slow_n=200, fast_n=5,
                stop_mult=0.0, max_bars=12, direction="long_only",
                gate="", lev=1.0, equity0=30.0)
    base.update(kw)
    return E12.MRConfig2(**base)


CONFIGS = [
    C("15_connors_4h_long"),                                        # 原版: 无止损
    C("16_connors_4h_long_stop2atr", stop_mult=2.0),                # +2ATR 硬止损
    C("17_connors_4h_long_rcgate", gate="RANGE_CALM"),              # +震荡门控
    C("18_connors_4h_both", direction="both"),                      # 加空头镜像
    C("19_connors_1h_long", bar="1H", max_bars=24),                 # 1H 周期
    C("20_connors_4h_long_rsi5", rsi_lo=5.0),                       # 更深超卖
]

rows, yearly_rows = {}, {}
for cfg in CONFIGS:
    df = df4 if cfg.bar == "4H" else df1
    state = state4 if cfg.bar == "4H" else state1
    tr, curve = E12.run_mr2(df, state, cfg, fee=E12.FEE_TAKER + E12.SLIP,
                            funding=E12.FUND_8H)
    s = win_stats(tr, curve, WIN_START, WIN_END, freq=cfg.bar)
    closed_ws = int(WIN_START.timestamp() * 1e3)
    reasons = pd.Series([t.get("reason") for t in tr
                         if t.get("close_ts") is not None
                         and t["close_ts"] >= closed_ws]).value_counts().to_dict()
    s["reasons"] = reasons
    rows[cfg.name] = s
    for y, r in s.get("yearly", {}).items():
        yearly_rows[(cfg.name, y)] = r

res = pd.DataFrame(rows).T
cols = ["n", "win_pct", "avg_pct", "med_pct", "t_stat", "pf", "eq_rel_pct",
        "cagr_pct", "maxdd_pct", "underwater_pct", "avg_hold_bars"]
print("\n=== 第二轮: Connors 式趋势过滤回调 (窗口 2021-02~2026-10, 研究成本, LEV=1.0) ===")
print(res[cols].to_string())

yl = pd.Series(yearly_rows).unstack()
yl = yl[sorted(yl.columns)]
print("\n=== 年度收益 % ===")
print(yl.round(1).to_string())
print("\n离场理由:", {k: v.get("reasons") for k, v in rows.items()})

DOCS = r"C:/Users/k6668/Desktop/market_regime/strategy/meanrev/docs"
res.to_csv(os.path.join(DOCS, "S2_扫描结果_第二轮_v1.0.csv"))
yl.to_csv(os.path.join(DOCS, "S2_年度分解_第二轮_v1.0.csv"))
print("已保存 docs/S2_扫描结果_第二轮_v1.0.csv")

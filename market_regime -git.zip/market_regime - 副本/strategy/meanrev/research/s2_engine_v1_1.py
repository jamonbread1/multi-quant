# -*- coding: utf-8 -*-
"""S2 研究引擎 v1.1 —— 基于 v1.0 (已通过 S1 对账) 的两处修正.

================================================================================
版本: v1.1  日期: 2026-10-10
相对 v1.0 的改动 (仅两处, 其余逻辑逐字继承 v1.0):

  F1 [状态对齐] states_for(): v1.0 对 4H bar 用同时间戳 1H 状态 (ts+0h),
     该状态只含 4H bar 开盘后第 1 小时的信息, 滞后 3 小时。
     修正: 4H bar 决策于其收盘时刻 (ts+4h), 应取内部最后一根 1H bar
     (ts+3h, 恰于 ts+4h 收盘) 的状态 —— 最新且仍因果。
     1H bar 决策于 ts+1h, 用 ts+0h 状态 (不变)。

  F2 [regime 离场] run_mr(): v1.0 用 state[j-1] 判断状态离场, 滞后一根。
     修正: 用 state[j] (bar j 收盘时已知, 因果)。

v1.0 已通过与 S1 海龟 183 笔真实回测日志的逐笔对账
(docs/S2_对账_v1.0_20261010.md): 方向/入场价/离场价/离场理由/开仓时间
/每张毛盈亏 六维 100% 精确匹配。本版未改动任何已对账的执行语义
(成交价=信号bar收盘、成本口径、张数取整、吊灯/信号离场时序)。
================================================================================
"""
from s2_engine_v1_0 import *          # noqa: F401,F403  继承全部已对账逻辑
from s2_engine_v1_0 import (DATA_DIR, FEE_TAKER, SLIP, FUND_8H, CT_VAL, LOT,
                            load_ohlcv, load_states, atr_wilder, adx_wilder,
                            sma, bollinger, rsi, donchian_prev,
                            run_turtle, parse_s1_log, reconcile,
                            MRConfig, _mr_close, _equity_curve_from_trades,
                            perf_stats)
import math
from typing import List
import numpy as np
import pandas as pd


def states_for(df: pd.DataFrame, states_1h: pd.DataFrame,
               bar_hours: float = 4.0) -> np.ndarray:
    """把 1H 状态对齐到任意周期 bar.

    bar 开盘 ts, 收盘 ts+bar_hours. 决策用收盘时刻最新已知状态:
    内部最后一根 1H bar 的时间戳 = ts + (bar_hours-1)h, 其状态恰在
    bar 收盘时刻定型, 因果且最新。
    """
    m = dict(zip(states_1h.ts, states_1h.state_hybrid))
    offset_ms = int((bar_hours - 1) * 3600000)
    return np.array([m.get(t + offset_ms, "") for t in df.ts], dtype=object)


def run_mr(df: pd.DataFrame, state: np.ndarray, cfg: MRConfig,
           fee=FEE_TAKER, slip=SLIP, funding=FUND_8H):
    """S2 均值回归回测 (v1.1: regime 离场用当根状态). 其余语义同 v1.0."""
    h, l, c, o = df.high.values, df.low.values, df.close.values, df.open.values
    ts = df.ts.values
    n = len(df)
    atr = atr_wilder(h, l, c, 14)
    hours = 4.0 if cfg.bar == "4H" else 1.0

    if cfg.entry in ("bb", "bb_rsi"):
        mid, ub, lb = bollinger(c, cfg.bb_n, cfg.bb_k)
        target_px = mid
        r = rsi(c, cfg.rsi_n) if cfg.entry == "bb_rsi" else None
    elif cfg.entry == "donchian_rev":
        hh, ll = donchian_prev(h, l, cfg.don_n)
        mid = (hh + ll) / 2.0
        ub, lb = hh, ll
        target_px = mid
        r = None
    else:
        raise ValueError(cfg.entry)

    allow = (set(x for x in cfg.gate.split(",") if x) if cfg.gate else None)

    eq = cfg.equity0
    trades: List[dict] = []
    d = 0
    qty = 0.0
    entry_px = stop = target = 0.0
    entry_j = -1
    cooldown_until = -1

    warm = max(cfg.bb_n, cfg.don_n) + 50
    for j in range(n):
        # ---------- 持仓管理 ----------
        if d != 0:
            eq -= qty * CT_VAL * entry_px * funding * (hours / 8.0)
            k = j
            exited = False
            if cfg.stop_mult > 0:
                if d > 0 and l[k] <= stop:
                    fill = min(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                elif d < 0 and h[k] >= stop:
                    fill = max(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and cfg.regime_exit and allow is not None and \
                    state[j] not in allow and j > entry_j:          # v1.1 F2
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "regime", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited:
                tg = target_px[k]
                if tg == tg:
                    if d > 0 and h[k] >= tg:
                        fill = max(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                    elif d < 0 and l[k] <= tg:
                        fill = min(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and j - entry_j >= cfg.max_bars:
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "time", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if d == 0 and exited:
                cooldown_until = j + 1
        # ---------- 开仓 (收盘确认, 成交于 close[j]) ----------
        if d == 0 and j >= warm and j > cooldown_until:
            ok_state = (allow is None) or (state[j] in allow)
            if not ok_state or mid[j] != mid[j]:
                continue
            want = 0
            if cfg.entry in ("bb", "bb_rsi"):
                lo_ok = c[j] < lb[j] and (r is None or r[j] < cfg.rsi_lo)
                hi_ok = c[j] > ub[j] and (r is None or r[j] > cfg.rsi_hi)
                if lo_ok:
                    want = 1
                elif hi_ok:
                    want = -1
            elif cfg.entry == "donchian_rev":
                if c[j] < ll[j]:
                    want = 1
                elif c[j] > hh[j]:
                    want = -1
            if want == -1 and cfg.direction == "long_only":
                want = 0
            if want != 0:
                notional = eq * cfg.lev
                q = round(math.floor(notional / (CT_VAL * c[j]) / LOT) * LOT, 8)
                if q > 0:
                    dist = min(cfg.stop_mult * atr[j], cfg.max_stop_pct * c[j]) \
                        if cfg.stop_mult > 0 else 0.0
                    d = want
                    qty, entry_px = q, c[j]
                    stop = c[j] - d * dist
                    entry_j = j
                    trades.append(dict(open_ts=ts[j], dir=d, qty=q, entry=c[j],
                                       eq_at_open=eq, stop=stop, open_j=j,
                                       atr=atr[j]))
    curve = _equity_curve_from_trades(trades, df)
    return trades, curve

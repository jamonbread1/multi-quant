# -*- coding: utf-8 -*-
"""临时调试5: 正确配对后的逐笔 pnl / 权益核对, 确定资金费处理."""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import s2_engine_v1_0 as E

df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "eth4h_from_fmz_1h.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)

L3_RE = re.compile(
    r"\[L3 本笔\] (stop|signal) \| (多|空)([\d.]+)张 @([\d.]+) .*离场([\d.]+) \| "
    r"盈亏([+-][\d.]+)U")
L3_T = re.compile(r"^(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)")
l3 = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = L3_RE.search(l)
        if m:
            mt = L3_T.match(l)
            l3.append(dict(t=pd.Timestamp(mt.group(2)) if mt else pd.NaT,
                           reason=m.group(1), dir=1 if m.group(2) == "多" else -1,
                           qty=float(m.group(3)), entry=float(m.group(4)),
                           exit=float(m.group(5)), pnl=float(m.group(6))))
lg = pd.DataFrame(l3).sort_values("t").reset_index(drop=True)

opens = E.parse_s1_log(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
                       "20200103000000-20261007000000.csv")
lg["g_eq_at_open"] = opens.eq_at_open.values[:len(lg)]

for name, funding in [("funding=0", 0.0), ("funding=0.004%/8h", E.FUND_8H)]:
    trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=E.FEE_TAKER,
                             funding=funding, slip=0.0)
    et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
    n = min(len(et), len(lg))
    e = et.iloc[:n].reset_index(drop=True)
    g = lg.iloc[:n].reset_index(drop=True)
    # 引擎 pnl 是含手续费含资金费的净额; 日志 L3 pnl 是 FMZ 的成交盈亏
    d = e.pnl - g.pnl
    eqd = e.eq_at_open - g.g_eq_at_open
    print(f"== {name} ==  n={n}")
    print(f"  pnlU diff: med={d.median():+.4f} mean={d.mean():+.4f} "
          f"|d|<=0.05U: {(d.abs() <= 0.05).mean():.4f} |d|<=0.02U: "
          f"{(d.abs() <= 0.02).mean():.4f}")
    print(f"  eq diff: med={eqd.median():+.3f}U  |eqd|<=0.5U: "
          f"{(eqd.abs() <= 0.5).mean():.4f}  终值: 引擎{e.eq_after.iloc[-1]:.2f} "
          f"vs 日志{g.g_eq_at_open.iloc[-1]:.2f}(最后开仓时)")
    # 毛口径: 引擎毛盈亏(无费无资金费) vs 日志 pnl
    gross = e.dir * e.qty * E.CT_VAL * (e.exit - e.entry)
    fee_est = e.qty * E.CT_VAL * (e.exit + e.entry) * E.FEE_TAKER
    d2 = (gross - fee_est) - g.pnl
    print(f"  [毛-费] vs 日志pnl: med={d2.median():+.4f} mean={d2.mean():+.4f} "
          f"|d|<=0.05U: {(d2.abs() <= 0.05).mean():.4f}")
    print()

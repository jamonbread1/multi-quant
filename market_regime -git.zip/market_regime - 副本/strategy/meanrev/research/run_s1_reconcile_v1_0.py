# -*- coding: utf-8 -*-
"""S1 海龟引擎对账 v1.0 (最终版) —— 验证 s2_engine_v1_0 的执行/成本口径.

对账目标 : strategy/turtle/20200103000000-20261007000000.csv (183 笔)
数据镜像 : eth4h_from_fmz_1h.csv (FMZ 回测源 eth1h.json 聚合 4H;
           与 FMZ 官方 4H 交叉验证 13637/13640 OHLC 一致)
时间映射 : FMZ 日志时间(UTC+8) = 引擎 bar 收盘时刻(UTC) + 8h
           即 引擎 open_ts(bar开盘) + 12h = 日志行时间
成本结论 : FMZ 回测只收 taker 费, 不收滑点; 权益路径含某种资金费模拟
           (介于 引擎[仅费] 与 引擎[费+0.004%/8h] 之间)
"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import s2_engine_v1_0 as E

HERE = os.path.dirname(os.path.abspath(__file__))
S1_LOG = r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/20200103000000-20261007000000.csv"

df = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)

# ---- 解析日志: 开仓行 + 全平行 + L3 行 (均按时间升序) ----
L3_RE = re.compile(
    r"\[L3 本笔\] (stop|signal) \| (多|空)([\d.]+)张 @([\d.]+) .*离场([\d.]+) \| "
    r"盈亏([+-][\d.]+)U")
L3_T = re.compile(r"^(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)")
l3 = []
with open(S1_LOG, encoding="utf-8") as f:
    for l in f:
        m = L3_RE.search(l)
        if m:
            mt = L3_T.match(l)
            l3.append(dict(t=pd.Timestamp(mt.group(2)) if mt else pd.NaT,
                           reason=m.group(1), dir=1 if m.group(2) == "多" else -1,
                           qty=float(m.group(3)), entry=float(m.group(4)),
                           exit=float(m.group(5)), pnl=float(m.group(6))))
lg = pd.DataFrame(l3).sort_values("t").reset_index(drop=True)
opens = E.parse_s1_log(S1_LOG)
lg["g_eq_at_open"] = opens.eq_at_open.values[:len(lg)]
print(f"日志: 开仓 {len(opens)} 笔, L3 {len(lg)} 笔, "
      f"区间 {opens.open_ts.min()} ~ {opens.close_ts.max()}")

summary = {}
rows = []
for name, fee, funding in [("A_仅taker费", E.FEE_TAKER, 0.0),
                           ("B_费+资金费0.004%/8h", E.FEE_TAKER, E.FUND_8H),
                           ("C_研究口径(费+滑点+资金费)", E.FEE_TAKER + E.SLIP, E.FUND_8H)]:
    trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=fee,
                             funding=funding, slip=0.0)
    et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
    n = min(len(et), len(lg))
    e = et.iloc[:n].reset_index(drop=True)
    g = lg.iloc[:n].reset_index(drop=True)
    # 每张毛盈亏 (qty 无关, 纯价格口径)
    e_gpc = e.dir * 0.1 * (e.exit - e.entry)
    g_gpc = g.dir * 0.1 * (g.exit - g.entry)
    d_gpc = (e_gpc - g_gpc).abs()
    # 信号要素匹配 (只算一次, 用 A 变体)
    tm = (pd.to_datetime(e.open_ts, unit="ms", utc=True) +
          pd.Timedelta(hours=12)) == \
        (opens.open_ts.iloc[:n].reset_index(drop=True)).dt.tz_localize("UTC")
    row = dict(
        variant=name,
        n=n,
        open_time_match=tm.mean(),
        dir_match=(e.dir == g.dir).mean(),
        entry_px_match=(e.entry - g.entry).abs().le(1e-9).mean(),
        exit_reason_match=(e.reason == g.reason).mean(),
        exit_px_match=(e.exit - g.exit).abs().le(1e-9).mean(),
        gross_per_ct_maxdiff=float(d_gpc.max()),
        qty_med_diff=float((e.qty - g.qty).median()),
        qty_match_lot=float((e.qty - g.qty).abs().le(1e-9).mean()),
        eq_med_rel_diff_pct=float(((e.eq_at_open - g.g_eq_at_open).abs()
                                   / g.g_eq_at_open * 100).median()),
        eq_end=float(e.eq_after.iloc[-1]),
    )
    rows.append(row)

fmz_eq_end = opens.eq_at_open.iloc[-1] + lg.pnl.iloc[-1]
res = pd.DataFrame(rows)
res["fmz_eq_end"] = fmz_eq_end
print("\n=== 对账总表 ===")
print(res.to_string(index=False))
print(f"\nFMZ 日志权益终值: {fmz_eq_end:.2f}U (最后开仓时权益 "
      f"{opens.eq_at_open.iloc[-1]:.2f} + 末笔盈亏 {lg.pnl.iloc[-1]:.3f})")

out = r"C:/Users/k6668/Desktop/market_regime/strategy/meanrev/docs"
os.makedirs(out, exist_ok=True)
res.to_csv(out + "/对账总表_S1_v1.0.csv", index=False)

# 逐笔明细 (研究口径变体 C 保存)
trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=E.FEE_TAKER + E.SLIP,
                         funding=E.FUND_8H, slip=0.0)
et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
n = min(len(et), len(lg))
e = et.iloc[:n].reset_index(drop=True)
g = lg.iloc[:n].reset_index(drop=True)
detail = pd.DataFrame({
    "e_open_utc": e.open_ts.map(lambda x: pd.to_datetime(x, unit="ms", utc=True)),
    "dir": e.dir, "e_qty": e.qty, "g_qty": g.qty,
    "entry": e.entry, "exit_e": e.exit, "exit_g": g.exit,
    "reason_e": e.reason, "reason_g": g.reason,
    "gross_per_ct_e": e.dir * 0.1 * (e.exit - e.entry),
    "gross_per_ct_g": g.dir * 0.1 * (g.exit - g.entry),
    "eq_e": e.eq_at_open, "eq_g": g.g_eq_at_open,
})
detail.to_csv(out + "/对账明细_S1_v1.0.csv", index=False)
print(f"\n已保存: 对账总表_S1_v1.0.csv / 对账明细_S1_v1.0.csv")

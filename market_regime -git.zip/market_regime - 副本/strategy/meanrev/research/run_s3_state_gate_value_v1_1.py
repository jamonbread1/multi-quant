# -*- coding: utf-8 -*-
"""S3 组合价值验证 v1.1 —— 用官方归因数据检验「状态门控」对 S1 的价值.

============================================================================
版本: v1.1  日期: 2026-10-10
相对 v1.0 的改动 (数据源切换, 修正 v1.0 的状态对齐缺陷):

  F1 [数据源] v1.0 用引擎重跑 + states_for() 对齐, 但 eth4h_from_fmz_1h.csv
      有 2247/14884 根 4H bar 对不上 1H 状态 (暖机期空状态), 且引擎交易序列
      与 FMZ 真实日志不同源, 导致 TREND_DOWN 符号与报告相反 (v1.0 测出 +0.72R,
      报告为 -6.87R)。这是数据管线缺陷, 不是策略差异。
      v1.1 直接用官方归因产物 data/states/S1_trades_with_states.csv
      (183 笔 FMZ 真实日志 × 已对齐 hybrid 状态), 与报告口径逐笔一致。

  目的 (用户核心猜想): 「S1 只在特定状态赚钱, 用状态识别让不同状态用不同
      策略可获更多收益」。本脚本验证第一环: 给 S1 加状态门控能否改善复利路径。
方法: 逐笔复利, 按开仓状态筛选, 从窗口首笔重整权益为 30U。
============================================================================
"""
import os
import numpy as np
import pandas as pd

# 官方归因产物 (183 笔 FMZ 真实日志 × 已对齐 hybrid 状态)
T = pd.read_csv(r"C:/Users/k6668/Documents/../Desktop/market_regime/data/states/S1_trades_with_states.csv")
T["r"] = T["pnl_r"] / 10.0 / 3.0 if False else T["pnl_u"] / T["equity_entry"]  # 权益口径逐笔收益
T["r"] = T["pnl_r"] / 3.0   # R 倍数即逐笔期望, 用于门控敏感性
T["exit_time_utc"] = pd.to_datetime(T["exit_time_utc"])
T["entry_time_utc"] = pd.to_datetime(T["entry_time_utc"])

print("=== 数据源: S1_trades_with_states.csv (FMZ 真实日志, n=%d) ===" % len(T))
print("总R=%.1f 总U=%.1f 多/空=%d/%d" % (T.pnl_r.sum(), T.pnl_u.sum(),
      (T.side=='long').sum(), (T.side=='short').sum()))


def gated(keep, label, rcol="r"):
    """按开仓状态筛选, 逐笔复利 (R口径), 起始30U."""
    sub = T if keep is None else T[T.state_entry.isin(keep)]
    if len(sub) == 0:
        print(f"  {label:>30}: n=0"); return
    r = sub[rcol].values
    eq = 30.0 * np.cumprod(1 + r * 0.1)  # R*0.1 近似权益口径波动幅度, 用于路径形态
    # 真实口径用 pnl_u/equity_entry
    r2 = sub["pnl_u"].values / sub["equity_entry"].values
    eq = 30.0 * np.cumprod(1 + r2)
    years = (sub.exit_time_utc.iloc[-1] - sub.entry_time_utc.iloc[0]).days / 365.25
    cagr = (eq[-1] / 30.0) ** (1 / max(years, 1e-9)) - 1
    mdd = (eq / np.maximum.accumulate(eq) - 1).min()
    under = (eq < np.maximum.accumulate(eq)).mean()
    wins = r2 > 0
    pf = r2[wins].sum() / abs(r2[~wins].sum()) if (~wins).any() else np.inf
    print(f"  {label:>30}: n={len(sub):>3} 胜率={wins.mean()*100:>4.1f}% "
          f"期末={eq[-1]:>7.1f}U ({eq[-1]/30:>5.1f}x) CAGR={cagr*100:>6.1f}% "
          f"maxDD={mdd*100:>6.1f}% 水下={under*100:>4.0f}% PF={pf:.2f}")


print("\n=== 状态门控方案 (按开仓状态, R口径, 30U起始) ===")
schemes = [
    (None, "实际 (全部交易)"),
    (["TREND_DOWN"], "仅 TREND_DOWN"),
    (["TREND_UP"], "仅 TREND_UP"),
    (["RANGE_CALM"], "仅 RANGE_CALM"),
    (["HIGH_VOL"], "仅 HIGH_VOL"),
    (["TRANSITION"], "仅 TRANSITION"),
    (["RANGE_CALM", "TREND_UP"], "RANGE_CALM+TREND_UP"),
    (["RANGE_CALM", "TREND_UP", "HIGH_VOL"], "排除DOWN+TRANSITION"),
    (["RANGE_CALM", "TREND_UP", "HIGH_VOL", "TRANSITION"], "仅排除 TREND_DOWN"),
]
for keep, label in schemes:
    gated(keep, label)

print("\n=== 各状态对 S1 的贡献 (开仓口径) ===")
g = T.groupby("state_entry").agg(n=("pnl_r", "size"), sum_R=("pnl_r", "sum"),
                                 win=("pnl_u", lambda x: (x > 0).mean() * 100))
g["contrib%"] = g.sum_R / T.pnl_r.sum() * 100
print(g.round(2).to_string())

print("\n=== 关键结论 ===")
print("  盈利状态: RANGE_CALM(+38.0R) TREND_UP(+10.5R) HIGH_VOL(+3.7R)")
print("  亏损状态: TREND_DOWN(-6.9R 胜率28%) TRANSITION(+0.6R 但U亏)")
print("  -> 你的猜想成立: S1 在 TREND_DOWN 状态系统性亏损, 应配不同策略")
print("  -> 但 RANGE_CALM 占 S1 盈利 82.9%, 说明震荡市反而是突破策略的主战场")
print("  -> 报告的反事实: 跳过 TREND_DOWN 后 457->943U, maxDD -59.7%->-44.6%")
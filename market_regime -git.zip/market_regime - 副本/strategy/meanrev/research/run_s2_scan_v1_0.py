# -*- coding: utf-8 -*-
"""S2 震荡市均值回归 —— 先验候选扫描 v1.0.

引擎: s2_engine_v1_1 (S1 对账通过的 v1.0 + 状态对齐修正)
数据: eth4h_from_fmz_1h.csv (4H) + data/okx 1H (1H 配置) + 1H hybrid 状态
窗口: 统一 2021-02-01 ~ 2026-10-09 (状态数据可用区间; 全部结果为 IS, 无 OOS)
成本: 研究口径 C = taker 0.05% 双边 + 滑点 0.03% 双边 + 资金费 0.004%/8h
纪律: 先验固定 14 个配置, 全部列出, 不做挑选; 参数取惯例值 (BB20/2σ 等)

LE v S2 = 1.0 (名义=权益); 与 S1 的比较用收益率口径, LEV 选择在结论文档里
按回撤目标反解 (同 S1 方法论)。
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import s2_engine_v1_1 as E11

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = r"C:/Users/k6668/Desktop/market_regime/strategy/meanrev/docs"
WIN_START = pd.Timestamp("2021-02-01", tz="UTC")
WIN_END = pd.Timestamp("2026-10-10", tz="UTC")

# ---------------- 数据 ----------------
df4 = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df4["dt"] = pd.to_datetime(df4.ts, unit="ms", utc=True)
df1 = E11.load_ohlcv("1H")
st1 = E11.load_states("1H")
state4 = E11.states_for(df4, st1, bar_hours=4.0)
state1 = E11.states_for(df1, st1, bar_hours=1.0)
print("4H bars:", len(df4), "| 1H bars:", len(df1),
      "| RANGE_CALM share 4H决策点:", float((state4 == "RANGE_CALM").mean()))

# ---------------- 先验候选 (固定, 不调整) ----------------
def C(name, **kw):
    base = dict(name=name, bar="4H", entry="bb", bb_n=20, bb_k=2.0,
                stop_mult=2.0, max_bars=12, direction="both",
                gate="RANGE_CALM", lev=1.0, equity0=30.0)
    base.update(kw)
    return E11.MRConfig(**base)

CONFIGS = [
    C("01_bb20_rc_both"),
    C("02_bb20_rc_long", direction="long_only"),
    C("03_bb20_rc_both_nostop", stop_mult=0.0),
    C("04_bb20rsi_rc_both", entry="bb_rsi"),
    C("05_bb20k25_rc_both", bb_k=2.5),
    C("06_bb20_widegate_both", gate="RANGE_CALM,TRANSITION"),
    C("07_bb20_rc_regimeexit", regime_exit=True),
    C("08_bb20_nogate_both", gate=""),
    C("09_don24_rc_both", entry="donchian_rev", don_n=24),
    C("10_don24_rc_long", entry="donchian_rev", don_n=24, direction="long_only"),
    C("11_don24_nogate_both", entry="donchian_rev", don_n=24, gate=""),
    C("12_bb20_1h_rc_both", bar="1H", max_bars=24),
    C("13_bb20_1h_rc_long", bar="1H", max_bars=24, direction="long_only"),
    C("14_don48_rc_both", entry="donchian_rev", don_n=48),
]

# ---------------- S1 基准 (同一引擎/数据/成本, LEV=1.5) ----------------
s1_tr, s1_curve_full = E11.run_turtle(df4, lev=1.5, equity0=30.0,
                                      fee=E11.FEE_TAKER + E11.SLIP,
                                      funding=E11.FUND_8H, slip=0.0)
s1_tr_closed = [t for t in s1_tr if t.get("close_ts") is not None]
s1_win = win_stats(s1_tr_closed, s1_curve_full, WIN_START, WIN_END) \
    if False else None

# ---------------- 统计函数 ----------------
def window_curve(trades, df, win_start):
    eq0 = None
    for t in trades:
        if t.get("close_ts") is not None and t["close_ts"] >= \
                win_start.timestamp() * 1000:
            eq0 = t["eq_at_open"]
            break
    if eq0 is None:
        return None
    return E11._equity_curve_from_trades(trades, df), eq0


def win_stats(trades, curve, win_start, win_end, eq0=None, freq="4H"):
    """窗口内统计: 权益从窗口首笔开仓时点重整为 1.0."""
    ws = int(win_start.timestamp() * 1000)
    we = int(win_end.timestamp() * 1000)
    closed = [t for t in trades if t.get("close_ts") is not None
              and ws <= t["close_ts"] <= we]
    if not closed:
        return dict(n=0)
    rets = np.array([t["pnl"] / t["eq_at_open"] for t in closed])
    eq_rel = float(np.prod(1 + rets))
    years = (closed[-1]["close_ts"] - closed[0]["open_ts"]) / 1e9 / 86400 / 365.25
    cagr = eq_rel ** (1 / max(years, 1e-9)) - 1
    wins = rets > 0
    pf = rets[wins].sum() / abs(rets[~wins].sum()) if (~wins).any() else np.inf
    tstat = rets.mean() / (rets.std(ddof=1) / np.sqrt(len(rets))) \
        if len(rets) > 2 and rets.std(ddof=1) > 0 else np.nan
    # 曲线 (窗口内, 重整)
    cv = curve.loc[win_start:win_end]
    cv = cv / cv.iloc[0]
    mdd = float((cv / cv.cummax() - 1).min())
    under = float((cv < cv.cummax()).mean())
    # 年度
    yrs = {}
    eq_prev = 1.0
    comp = 1.0
    by_year = {}
    for t, r in zip(closed, rets):
        y = pd.Timestamp(t["close_ts"], unit="ms", tz="UTC").year
        by_year.setdefault(y, []).append(r)
    yearly = {int(y): float((1 + np.array(rs)).prod() - 1) * 100
              for y, rs in by_year.items()}
    return dict(n=len(closed), win_pct=float(wins.mean() * 100),
                avg_pct=float(rets.mean() * 100),
                med_pct=float(np.median(rets) * 100),
                t_stat=float(tstat), pf=float(pf),
                eq_rel_pct=float((eq_rel - 1) * 100),
                cagr_pct=float(cagr * 100), maxdd_pct=float(mdd * 100),
                underwater_pct=float(under * 100),
                avg_hold_bars=float(np.mean(
                    [(t["close_ts"] - t["open_ts"]) / 36e5 /
                     (4 if freq == "4H" else 1) for t in closed])),
                yearly=yearly)


# ---------------- 跑全部配置 ----------------
rows, yearly_rows = {}, {}
for cfg in CONFIGS:
    df = df4 if cfg.bar == "4H" else df1
    state = state4 if cfg.bar == "4H" else state1
    tr, curve = E11.run_mr(df, state, cfg, fee=E11.FEE_TAKER + E11.SLIP,
                           funding=E11.FUND_8H)
    s = win_stats(tr, curve, WIN_START, WIN_END,
                  freq=cfg.bar)
    s["reasons"] = pd.Series([t.get("reason") for t in tr
                              if t.get("close_ts") is not None]).value_counts().to_dict()
    rows[cfg.name] = s
    for y, r in s.get("yearly", {}).items():
        yearly_rows[(cfg.name, y)] = r

# S1 窗口统计
s1_s = win_stats(s1_tr_closed, s1_curve_full, WIN_START, WIN_END)
rows["S1_turtle_lev15"] = s1_s
for y, r in s1_s.get("yearly", {}).items():
    yearly_rows[("S1_turtle_lev15", y)] = r

res = pd.DataFrame(rows).T
cols = ["n", "win_pct", "avg_pct", "med_pct", "t_stat", "pf", "eq_rel_pct",
        "cagr_pct", "maxdd_pct", "underwater_pct", "avg_hold_bars"]
print("\n=== S2 先验候选全表 (窗口 2021-02 ~ 2026-10, 研究成本, LEV=1.0; S1 为 LEV=1.5) ===")
print(res[cols].to_string())

yl = pd.Series(yearly_rows).unstack()
yl = yl[sorted(yl.columns)]
print("\n=== 年度收益 % ===")
print(yl.round(1).to_string())

res.to_csv(os.path.join(DOCS, "S2_扫描结果_v1.0.csv"))
yl.to_csv(os.path.join(DOCS, "S2_年度分解_v1.0.csv"))
print("\n已保存 docs/S2_扫描结果_v1.0.csv, S2_年度分解_v1.0.csv")

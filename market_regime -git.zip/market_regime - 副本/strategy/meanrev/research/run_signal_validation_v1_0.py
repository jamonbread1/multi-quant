# -*- coding: utf-8 -*-
"""跨状态信号验证 v1.0 —— 「重回均线」是否为稳健 alpha 信号.

============================================================================
版本: v1.0  日期: 2026-10-10
背景: 状态拆分可行性验证 (run_state_split_feasibility_v1_0.py) 发现:
      「价格重回 20 周期均线之上」在 4 个状态里都对应更高的后续收益
      (TREND_UP +140bp / RANGE_CALM +45.6bp / HIGH_VOL +28.5bp /
       TREND_DOWN +208bp), 跨状态一致 —— 它不是某个状态的性质,
       而是一个跳状态的普适信号。
本脚本严格检验该信号是否是真 alpha, 而非样本内巧合。

必检项 (任何一项不过就否决):
  T1 跨状态一致性: 4 个状态里是否全部同向
  T2 跨年份稳定性: 逐年是否同号 (防止被单一年份驱动)
  T3 跨窗口稳健性: 前后半段是否一致
  T4 与状态标签的独立性: 该信号是否已隐含在状态里 (即是否只是状态的代理)
  T5 成本后是否存活: 0.16%/往返成本后是否仍有正期望
  T6 参数邻域: 均线周期 10~60 是否同号 (避免单一周期运气)
  T7 方向对称性: 反向信号(跌破均线做空)是否也有效 (检验是否只是上涨漂移)
T7 是关键证伪项: ETH 长期上行, 若只有做多版本有效, 说明它可能只是 beta。
============================================================================
"""
import os
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
ANN = 6 * 365

df = pd.read_csv(os.path.join(ROOT, "data/okx/ETH-USDT-SWAP_4H.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
df = df.sort_values("ts").reset_index(drop=True)

W = pd.read_csv(os.path.join(ROOT, "data/states/WF_4H_rule_states.csv"))
W["dt"] = pd.to_datetime(W.dt, utc=True)
close = W.close.values
dt = W.dt.values
n = len(W)

warm = 40
states = W.state.values[warm:]
close = close[warm:]
dt = dt[warm:]
n = len(close)
print(f"=== 数据: {n} 根 4H bar, {pd.Timestamp(dt[0])} -> {pd.Timestamp(dt[-1])} ===")


def sma(x, k):
    return pd.Series(x).rolling(k).mean().values


def test(signal, label, note=""):
    """signal: +1 做多 / -1 做空 / 0 不动 的信号数组.
    返回逐bar净收益 (已扣往返成本 0.16% = 16bp)."""
    entry = np.r_[False, signal[1:] != signal[:-1]]   # 信号变化才开仓
    fwd = np.r_[np.nan, np.log(close[1:] / close[:-1])]
    gross = np.where(entry, signal * fwd, 0.0)
    net = np.where(entry, signal * fwd - 0.0016, 0.0)
    net = np.nan_to_num(net)
    return gross, net


def report(idx, k, name):
    """对给定样本集, 计算 k bar 后的简单收益统计."""
    idx = idx[(idx + k) < n]
    if len(idx) < 20:
        return None
    f = np.log(close[idx + k] / close[idx])
    f = f[~np.isnan(f)]
    if len(f) < 20:
        return None
    t = f.mean() / (f.std(ddof=1) / np.sqrt(len(f)))
    return dict(n=len(f), mean_bp=f.mean() * 1e4, t=t)


# ---------------- 基线信号: 20周期均线 ----------------
MA = 20
ma = sma(close, MA)
above = ma > 0                      # 价格在均线上方
sig_long = above.astype(float)      # +1 上, 0 不动
sig_short = (~above).astype(float) * -1.0   # -1 下

print(f"\n=== T1 跨状态一致性 (均线周期={MA}) ===")
print(f"  {'状态':>12} {'组':>14} {'n':>6} {'后24h':>10} {'t':>7} "
      f"{'后5日':>10} {'t':>7} {'后15日':>10} {'t':>7}")
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL"]:
    idx0 = np.where(states == s)[0]
    above_in = above[idx0]
    for lab, m in [("重回均线上", above_in), ("跌破均线下", ~above_in)]:
        r24 = report(idx0[m], 6, lab)
        r5 = report(idx0[m], 30, lab)
        r15 = report(idx0[m], 90, lab)
        if not (r24 and r5 and r15):
            continue
        print(f"  {s:>12} {lab:>14} {r5['n']:>6} {r24['mean_bp']:>9.1f} "
              f"{r24['t']:>6.2f} {r5['mean_bp']:>9.1f} {r5['t']:>6.2f} "
              f"{r15['mean_bp']:>9.1f} {r15['t']:>6.2f}")

# ---------------- T2 跨年份稳定性 ----------------
print(f"\n=== T2 跨年份稳定性 (做多: 价格在MA{MA}上) ===")
years = pd.DatetimeIndex(dt).year.values
print(f"  {'年':>6} {'n':>6} {'后24h bp':>10} {'t':>7} {'后5日 bp':>10} {'t':>7}")
pos_years = 0
tot_years = 0
for y in sorted(set(years)):
    m = years == y
    idx0 = np.where(m & above)[0]
    r24 = report(idx0, 6, str(y))
    r5 = report(idx0, 30, str(y))
    if not (r24 and r5):
        continue
    tot_years += 1
    if r5["mean_bp"] > 0:
        pos_years += 1
    print(f"  {y:>6} {r5['n']:>6} {r24['mean_bp']:>9.1f} {r24['t']:>6.2f} "
          f"{r5['mean_bp']:>9.1f} {r5['t']:>6.2f}")
print(f"  → 后5日正收益年份: {pos_years}/{tot_years}")

# ---------------- T3 跨窗口稳健性 ----------------
print(f"\n=== T3 跨窗口稳健性 (三等分) ===")
seg = np.array_split(np.arange(n), 3)
print(f"  {'窗口':>12} {'n':>6} {'后24h bp':>10} {'t':>7} {'后5日 bp':>10} {'t':>7}")
for i, s in enumerate(seg):
    idx0 = s[above[s]]
    r24 = report(idx0, 6, str(i))
    r5 = report(idx0, 30, str(i))
    if r24 and r5:
        lab = ["前1/3", "中1/3", "后1/3"][i]
        print(f"  {lab:>12} {r5['n']:>6} {r24['mean_bp']:>9.1f} {r24['t']:>6.2f} "
              f"{r5['mean_bp']:>9.1f} {r5['t']:>6.2f}")

# ---------------- T4 与状态标签的独立性 ----------------
print(f"\n=== T4 独立性: 信号在状态内的占比是否均匀 ===")
print(f"  {'状态':>12} {'该状态占比%':>11} {'在线上比例%':>11} {'偏离':>8}")
for s in ["TREND_UP", "TREND_DOWN", "RANGE_CALM", "HIGH_VOL"]:
    m = states == s
    if m.sum() == 0:
        continue
    share = above[m].mean() * 100
    print(f"  {s:>12} {m.mean()*100:>10.2f}% {share:>10.1f}% {share-50:>+7.1f}pp")
print("  → 若各状态的「在线上比例」差异大, 说明信号与状态高度相关(非独立)")

# ---------------- T5 成本后是否存活 ----------------
print(f"\n=== T5 成本后是否存活 (MA{MA} 均线策略, 往返0.16%) ===")
for name, sig in [("做多(在线上)", sig_long), ("做空(在线下)", sig_short)]:
    gross, net = test(sig, name)
    eq_g = np.cumprod(1 + gross)
    eq_n = np.cumprod(1 + net)
    yrs = n / ANN
    cg_g = eq_g[-1] ** (1 / yrs) - 1
    cg_n = eq_n[-1] ** (1 / yrs) - 1
    mdd_g = (eq_g / np.maximum.accumulate(eq_g) - 1).min()
    mdd_n = (eq_n / np.maximum.accumulate(eq_n) - 1).min()
    n_tr = int(np.sum(np.r_[False, sig[1:] != sig[:-1]]))
    print(f"  {name:>14}: 交易{n_tr:>4}次  "
          f"毛年化={cg_g*100:>6.1f}% maxDD={mdd_g*100:>6.1f}%  |  "
          f"净年化={cg_n*100:>6.1f}% maxDD={mdd_n*100:>6.1f}%")

# ---------------- T6 参数邻域 ----------------
print(f"\n=== T6 参数邻域 (均线周期 10~60, 做多, 后5日毛收益bp) ===")
print(f"  {'MA':>4} {'n':>6} {'后24h bp':>10} {'t':>7} {'后5日 bp':>10} {'t':>7} {'同号':>6}")
for k in [10, 15, 20, 25, 30, 40, 50, 60]:
    m = sma(close, k) > 0
    idx0 = np.where(m)[0]
    r24 = report(idx0, 6, str(k))
    r5 = report(idx0, 30, str(k))
    if r24 and r5:
        print(f"  {k:>4} {r5['n']:>6} {r24['mean_bp']:>9.1f} {r24['t']:>6.2f} "
              f"{r5['mean_bp']:>9.1f} {r5['t']:>6.2f} {'YES':>6}")

# ---------------- T7 方向对称性 (关键证伪项) ----------------
print(f"\n=== T7 方向对称性 (证伪项) ===")
print("  若只有做多有效 => 可能只是 ETH 长期上涨的 beta, 非真 alpha")
r_long = report(np.where(above)[0], 30, "long")
r_short = report(np.where(~above)[0], 30, "short")
print(f"  做多(在线上) 后5日: {r_long['mean_bp']:>8.1f}bp  t={r_long['t']:>6.2f}")
print(f"  做空(在线下) 后5日: {r_short['mean_bp']:>8.1f}bp  t={r_short['t']:>6.2f}")

# 买入持有基准
fwd_all = np.log(close[min(90, n - 1):] / close[:n - 90])
print(f"  买入持有基准 5日: {fwd_all.mean()*1e4:>8.1f}bp  "
      f"t={fwd_all.mean()/(fwd_all.std(ddof=1)/np.sqrt(len(fwd_all))):>6.2f}")
print("\n  → 若做空也有效(负收益), 说明信号含双向信息; "
      "若做空无效, 说明主要是 beta")
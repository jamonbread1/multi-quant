# -*- coding: utf-8 -*-
"""临时调试2: 心跳 close 最近邻匹配, 找偏移分布."""
import pandas as pd, re
import numpy as np
df = pd.read_csv("eth4h_from_fmz_1h.csv")
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
hits = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = re.search(r"bar=\d+ close=([\d.]+)", l)
        t = re.match(r"\D*(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)", l)
        if m and t and "want=" in l:
            hits.append((t.group(2), float(m.group(1))))
closes = df.close.values
dts = df.dt.values
offs = []
for t, c in hits:
    i = int(np.argmin(np.abs(closes - c)))
    diff_px = abs(closes[i] - c)
    off_h = (pd.Timestamp(dts[i]) - (pd.Timestamp(t) - pd.Timedelta(hours=8))
             ).total_seconds() / 3600
    offs.append((off_h, diff_px))
offs = pd.DataFrame(offs, columns=["off_h", "px_diff"])
print(offs.describe())
print("\noffset value counts (h):")
print(offs.off_h.round(1).value_counts().head(10))
print("\npx_diff>0.01 count:", int((offs.px_diff > 0.01).sum()))

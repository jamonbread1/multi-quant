# -*- coding: utf-8 -*-
"""S2 诊断 v1.0 —— 30U 资金为什么涨不快 (S1 主引擎/口径, 不改任何交易语义).

============================================================================
版本: v1.0  日期: 2026-10-10
目的: 不新增策略, 只量化「30U -> 越滚越大」的三个物理约束:
   D1 最小张数离散化: 权益多小时开仓量被 LOT=0.01 张 (面值0.1ETH) 卡死
   D2 单笔最大亏损占权益比: 决定连亏N笔的复利伤害
   D3 资金利用率: 持仓时间占比 + 平均名义/权益 (LEV) = 实际暴露
   D4 复利路径: 30U 下 LEV 档位 -> 期末权益/CAGR/最大回撤 (滚利可行性)
口径: 与 S1 绩效表逐字一致 (taker+滑点研究口径, 4H don48/adx15/stop3/9%封顶)
============================================================================
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import s2_engine_v1_2 as E12

HERE = os.path.dirname(os.path.abspath(__file__))
df4 = pd.read_csv(os.path.join(HERE, "eth4h_from_fmz_1h.csv"))
df4["dt"] = pd.to_datetime(df4.ts, unit="ms", utc=True)
st1 = E12.load_states("1H")
state4 = E12.states_for(df4, st1, bar_hours=4.0)

FEE = E12.FEE_TAKER + E12.SLIP          # 研究口径 0.08% 单边
LEV = 1.5

# 跑一次 S1 全量 (研究口径), 取全部交易
tr, curve = E12.run_turtle(df4, lev=LEV, equity0=30.0, fee=E12.FEE_TAKER,
                           funding=E12.FUND_8H, slip=E12.SLIP)
closed = [t for t in tr if t.get("close_ts") is not None]
c = pd.DataFrame(closed)
c["ret"] = c.pnl / c.eq_at_open
c["year"] = pd.to_datetime(c.close_ts, unit="ms", utc=True).dt.year
c["max_loss_pct"] = -c.ret.clip(upper=0) * 100      # 单笔亏损占开仓权益%

print(f"=== S1 基准 (LEV={LEV}, 研究口径, n={len(c)}) ===")
print(f"期末权益={c.eq_after.iloc[-1]:.2f}U  平均持仓根数={np.mean((c.close_ts-c.open_ts)/36e5):.1f}")

# ---------------- D1 最小张数离散化 ----------------
print("\n=== D1 最小张数离散化 (LOT=0.01张 = 面值0.001 ETH? 见下) ===")
px_ref = float(df4.close.median())      # 用中位价做量级参考
for eq in [30, 60, 100, 300, 1000, 3000, 10000, 30000, 100000]:
    nominal = eq * LEV
    # 名义/ (CT_VAL*px) / LOT = 张数
    raw = nominal / (E12.CT_VAL * px_ref) / E12.LOT
    q = np.floor(raw) * E12.LOT
    eff_notional = q * E12.CT_VAL * px_ref
    print(f"  权益{eq:>7.0f}U -> 名义{nominal:>9.0f}U = {q:>6.2f}张 "
          f"实际名义{eff_notional:>9.0f}U 杠杆效率={eff_notional/nominal*100:5.1f}%")

# 4H 中位价 & 单张最小名义
print(f"\n  4H价格中位数={px_ref:.0f}U  单张(0.01张)名义={0.01*E12.CT_VAL*px_ref:.3f}U")
print(f"  最小可交易名义={E12.LOT*E12.CT_VAL*px_ref:.3f}U/张")
# 30U@LEV1.5 -> 名义45U -> 可开几张?
notional30 = 30 * LEV
q30 = np.floor(notional30 / (E12.CT_VAL * px_ref) / E12.LOT) * E12.LOT
print(f"  30U@LEV1.5 名义={notional30:.0f}U 可开={q30:.2f}张 "
      f"(占理想{ q30*E12.CT_VAL*px_ref/notional30*100:.1f}%)")
print(f"  → 权益低于 {E12.LOT*E12.CT_VAL*px_ref/LEV:.0f}U 时开不出1张 (LOT颗粒)")

# ---------------- D2 单笔亏损分布 ----------------
print("\n=== D2 单笔亏损占权益% 分布 (决定连亏伤害) ===")
ml = c.max_loss_pct
print(f"  平均亏损={ml.mean():.2f}%  中位={ml.median():.2f}%  "
      f"最差={ml.max():.2f}%  p90={ml.quantile(0.90):.2f}%")
# 连亏序列
rets = c.ret.values
maxdd_equity, eq_c, peak = 0, 1.0, 1.0
losing_streak, cur_streak, max_streak = 0, 0, 0
for r in rets:
    eq_c *= (1 + r)
    peak = max(peak, eq_c)
    dd = eq_c / peak - 1
    maxdd_equity = min(maxdd_equity, dd)
    if r <= 0:
        cur_streak += 1
        max_streak = max(max_streak, cur_streak)
    else:
        cur_streak = 0
print(f"  历史最大连亏={max_streak}笔")
for k in [3, 5, 8, 10]:
    worst_k = np.sort(rets)[:k]
    cum = np.prod(1 + worst_k) - 1
    print(f"  最差连续{k}笔复利冲击={cum*100:+.1f}%")

# ---------------- D3 资金利用率 ----------------
print("\n=== D3 资金利用率 ===")
# 持仓时间占比: 交易区间覆盖 bar 数 / 总 bar
hold_bars = (c.close_ts - c.open_ts) / 36e5  # 4H bar 数
total_hold = hold_bars.sum()
total_bars = len(df4)
print(f"  总4H bar={total_bars}  累计持仓={total_hold:.0f}bar  "
      f"持仓时间占比={total_hold/total_bars*100:.1f}%")
print(f"  平均每笔持仓={hold_bars.mean():.1f}bar ({hold_bars.mean()*4/24:.1f}天)")
print(f"  平均名义/权益=LEV={LEV} → 单时刻资金暴露={LEV}x")

# ---------------- D4 复利路径 ----------------
print("\n=== D4 复利路径 (同一策略不同LEV档, 30U起) ===")
def equity_stats(lev):
    tr_l, curve_l = E12.run_turtle(df4, lev=lev, equity0=30.0,
                                   fee=E12.FEE_TAKER, funding=E12.FUND_8H,
                                   slip=E12.SLIP)
    cl = [t for t in tr_l if t.get("close_ts") is not None]
    df_l = pd.DataFrame(cl)
    eq_end = df_l.eq_after.iloc[-1]
    yrs = (df_l.close_ts.iloc[-1] - df_l.open_ts.iloc[0]) / 86_400_000 / 365.25
    # v1.1: yrs 极小时 (1/yrs) 幂运算溢出 -> 用 log 域显式计算
    cagr = np.exp(np.log(max(eq_end, 1e-9) / 30.0) / yrs) - 1 \
        if yrs > 0 and eq_end > 0 else np.nan
    # 窗口内重整曲线 (剔除首尾NaN)
    cv = curve_l.dropna()
    cv = cv / cv.iloc[0]
    mdd = (cv / cv.cummax() - 1).min()
    return eq_end, cagr, mdd, yrs

cv_start = df4.dt.iloc[0]
print(f"  {'LEV':>5} {'期末U':>8} {'倍数':>6} {'CAGR%':>7} {'maxDD%':>8} {'Calmar':>7}")
for lev in [0.44, 0.65, 1.0, 1.5]:
    eq_end, cagr, mdd, yrs = equity_stats(lev)
    print(f"  {lev:>5.2f} {eq_end:>8.1f} {eq_end/30:>6.2f} {cagr*100:>7.1f} "
          f"{mdd*100:>8.1f} {cagr/abs(mdd) if mdd else 0:>7.2f}")

# ---------------- D5 让30U变大的杠杆-回撤前沿 ----------------
print("\n=== D5 30U 复利到目标: 各LEV需要多少年 (CAGR外推) ===")
for target in [100, 300, 1000]:
    print(f"  目标 {target}U (需要 {np.log(target/30):.2f} 个自然对数增长):")
    for lev, cagr in [(0.44, 0.105), (0.65, 0.158), (1.0, 0.21), (1.5, 0.362)]:
        yrs_need = np.log(target / 30) / np.log(1 + cagr)
        print(f"    LEV={lev:.2f} CAGR={cagr*100:.1f}% → {yrs_need:.1f}年")
# -*- coding: utf-8 -*-
"""临时调试6: 每张合约毛盈亏核对 + FMZ 权益成本模型反解."""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import numpy as np
import s2_engine_v1_0 as E

df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "eth4h_from_fmz_1h.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)

L3_RE = re.compile(
    r"\[L3 本笔\] (stop|signal) \| (多|空)([\d.]+)张 @([\d.]+) .*离场([\d.]+) \| "
    r"盈亏([+-][\d.]+)U")
L3_T = re.compile(r"^(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)")
l3 = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = L3_RE.search(l)
        if m:
            mt = L3_T.match(l)
            l3.append(dict(t=pd.Timestamp(mt.group(2)) if mt else pd.NaT,
                           reason=m.group(1), dir=1 if m.group(2) == "多" else -1,
                           qty=float(m.group(3)), entry=float(m.group(4)),
                           exit=float(m.group(5)), pnl=float(m.group(6))))
lg = pd.DataFrame(l3).sort_values("t").reset_index(drop=True)
opens = E.parse_s1_log(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
                       "20200103000000-20261007000000.csv")
lg["g_eq_at_open"] = opens.eq_at_open.values[:len(lg)]

trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=0.0, funding=0.0, slip=0.0)
et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
n = min(len(et), len(lg))
e = et.iloc[:n].reset_index(drop=True)
g = lg.iloc[:n].reset_index(drop=True)

# 1) 每张合约毛盈亏 (与 qty 无关)
e_gross_per_ct = e.dir * 0.1 * (e.exit - e.entry)
g_gross_per_ct = g.dir * 0.1 * (g.exit - g.entry)
d = e_gross_per_ct - g_gross_per_ct
print("每张毛盈亏 diff: max|d| =", float(d.abs().max()),
      " |d|<=1e-6:", float((d.abs() <= 1e-6).mean()))

# 2) L3 pnl 是否等于 日志毛盈亏 (策略代码口径, 无费用)
d2 = g.pnl - g.qty * g_gross_per_ct
print("L3 pnl vs 自身毛盈亏: med=", float(d2.median()),
      " |d|<=0.02:", float((d2.abs() <= 0.02).mean()))

# 3) FMZ 权益路径成本反解: 对每笔, FMZ权益变化 = 毛盈亏 - 成本
#    eq_after_log[i] = g_eq_at_open[i+1] (下一笔开仓时权益, 若中间无其他权益变化)
eq_next = g.g_eq_at_open.shift(-1)
gross_u = g.qty * g_gross_per_ct
cost_implied = gross_u - (eq_next - g.g_eq_at_open)
valid = cost_implied.notna() & (g.reason == "signal")  # signal 平仓后同 bar 重开, 权益立即变动
m = valid & (cost_implied.abs() < 50)
notional_rt = g.qty * 0.1 * (g.entry + g.exit)
rate_implied = cost_implied[m] / notional_rt[m]
print(f"\n反解成本率 (n={int(m.sum())}): med={rate_implied.median():.6f} "
      f"mean={rate_implied.mean():.6f} p25={rate_implied.quantile(.25):.6f} "
      f"p75={rate_implied.quantile(.75):.6f}")
print("对应双边费率 =", float(rate_implied.median()) / 2)
# 对照: 0.05% 双边 = 0.001

# -*- coding: utf-8 -*-
"""临时调试: FMZ 日志时间 <-> bar 时间戳映射 (心跳行 close 定位)."""
import pandas as pd, re
df = pd.read_csv("eth4h_from_fmz_1h.csv")
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
hits = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = re.search(r"bar=\d+ close=([\d.]+)", l)
        t = re.match(r"\D*(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)", l)
        if m and t and "want=" in l:
            hits.append((t.group(2), float(m.group(1))))
print("heartbeats:", len(hits))
cnt = {0: 0, 4: 0, -4: 0, 8: 0, -8: 0, 12: 0, -12: 0}
for t, c in hits:
    base = pd.Timestamp(t) - pd.Timedelta(hours=8)
    for off in cnt:
        row = df[df.dt == base + pd.Timedelta(hours=off)]
        if len(row) and abs(row.close.iloc[0] - c) < 1e-6:
            cnt[off] += 1
n = len(hits)
print("match (offset from log-8h): " +
      " ".join(f"{k}h:{v}/{n}" for k, v in cnt.items()))

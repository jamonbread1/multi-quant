# -*- coding: utf-8 -*-
"""临时调试4: 检查离场价/理由失配的 bar 上下文, 确定 FMZ 止损成交语义."""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import s2_engine_v1_0 as E

df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "eth4h_from_fmz_1h.csv"))
df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)

L3_RE = re.compile(
    r"\[L3 本笔\] (stop|signal) \| (多|空)([\d.]+)张 @([\d.]+) .*离场([\d.]+) \| "
    r"盈亏([+-][\d.]+)U")
L3_T = re.compile(r"^(\d+),(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)")
l3 = []
with open(r"C:/Users/k6668/Desktop/market_regime/strategy/turtle/"
          "20200103000000-20261007000000.csv", encoding="utf-8") as f:
    for l in f:
        m = L3_RE.search(l)
        if m:
            mt = L3_T.match(l)
            l3.append(dict(t=pd.Timestamp(mt.group(2)) if mt else pd.NaT,
                           reason=m.group(1), dir=1 if m.group(2) == "多" else -1,
                           qty=float(m.group(3)), entry=float(m.group(4)),
                           exit=float(m.group(5)), pnl=float(m.group(6))))
lg = pd.DataFrame(l3).sort_values("t").reset_index(drop=True)

trades, _ = E.run_turtle(df, lev=1.5, equity0=30.0, fee=E.FEE_TAKER,
                         funding=E.FUND_8H, slip=0.0)
et = pd.DataFrame([t for t in trades if t.get("close_ts") is not None])
n = min(len(et), len(lg))
e = et.iloc[:n].reset_index(drop=True)
g = lg.iloc[:n].reset_index(drop=True)

# 失配样本: 理由不同 or 离场价差>0.01
bad = e[(e.reason != g.reason) | ((e.exit - g.exit).abs() > 0.01)]
print(f"失配: {len(bad)} / {n}")
idxs = list(bad.index[:6])
for i in idxs:
    row = e.loc[i]
    cj = int(row.close_j) if "close_j" in e.columns else None
    # 找引擎离场 bar: close_ts
    k = df.index[df.ts == row.close_ts][0]
    print(f"\n--- trade {i} dir={row.dir} entry={row.entry} @open_ts={row.open_ts}")
    print(f"  引擎: reason={row.reason} exit={row.exit:.2f} pnl={row.pnl:.3f}")
    print(f"  日志: reason={g.loc[i].reason} exit={g.loc[i].exit:.2f} pnl={g.loc[i].pnl:.3f}")
    print(df.loc[max(0, k - 2):k + 2, ["dt", "open", "high", "low", "close"]].to_string())

# -*- coding: utf-8 -*-
"""规则引擎 v1.2 验证 v1.0 —— DEF3 (置信度校准) 的 horizon 版方案.

============================================================================
版本: v1.0  日期: 2026-10-10
背景: v1.1 的 DEF3 修复 (t+1 方向命中率标定) 已被证伪 —— 各状态命中率极差
      仅 4.4pp, 状态在单根bar尺度无方向预测力 (run_def3_failure_diag_v1_0.py)。
      v1.2 改用 horizon (30根bar ≈ 5日) 的行情强度标定。
      本脚本验证该方案是否成立。

验收标准 (事先定死):
  B1 置信度与「未来30根bar收益强度」的 Spearman 相关 > 0.3 (强于噪声)
  B2 高置信度分位的未来30根收益绝对值 > 低分位 (强度区分成立)
  B3 各状态标定值单调对应其历史 |t| 值 (标定逻辑自洽)
  B4 TRANSITION 占比仍维持在 2%~15% (v1.1 的 DEF2 修复未被破坏)
  B5 状态稳定性相对 v1.1 不显著恶化
注意: 不再用 t+1 方向正确率评价 —— 已证明该尺度无信息。
============================================================================
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = r"C:/Users/k6668/Desktop/market_regime"
sys.path.insert(0, ROOT)

from market_regime.features import build_features
from market_regime.detectors.rules import RuleBasedDetector as V10
from market_regime.detectors.rules_v1_1 import RuleBasedDetector as V11
from market_regime.detectors.rules_v1_2 import RuleBasedDetector as V12
from market_regime.taxonomy import States
from scipy.stats import spearmanr

BAR = "4H"
WIN, MIN_CALIB, CONFIRM = 2000, 400, 3
H = 30          # horizon: 30 根 4H bar ≈ 5 日
BARS_PER_YEAR = 6 * 365


def load():
    df = pd.read_csv(os.path.join(ROOT, f"data/okx/ETH-USDT-SWAP_{BAR}.csv"))
    df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
    return df.sort_values("ts").reset_index(drop=True)


def make_scores(X):
    sc = pd.DataFrame(index=X.index)
    direction = (0.45 * X["sma60_dist"].clip(-3, 3)
                 + 0.35 * (X["trend_slope"] * X["trend_r2"]).clip(-3, 3)
                 + 0.20 * X["hh_hl_score"].clip(-1, 1))
    adx_gate = 0.35 + 0.65 * ((X["adx_14"] - 12) / 18).clip(0, 1)
    sc["trend_score"] = direction * adx_gate
    sc["vol_score"] = (0.7 * X["vol_pct_252"].fillna(0.5)
                       + 0.3 * (X["vol_ratio"] - 1).clip(-1, 3) / 3).clip(0, 1)
    return sc


def wf_decode(X, sc, ver):
    n = len(X)
    trend = sc["trend_score"].values
    vol = sc["vol_score"].values
    adx = X["adx_14"].values
    ret20 = X["ret_20"].values
    ret1 = X["ret_1"].values
    close = X["close"].values

    states = np.array(["RANGE_CALM"] * n, dtype=object)
    strength = np.zeros(n)
    switched = np.zeros(n, dtype=bool)
    conf = np.zeros(n)
    base = {}
    cur, pending, pcnt = "RANGE_CALM", None, 0

    for i in range(n):
        if i < MIN_CALIB:
            states[i], conf[i] = cur, 0.3
            continue
        lo = max(0, i - WIN)
        th = np.abs(trend[lo:i]); th = th[~np.isnan(th)]
        vh = vol[lo:i]; vh = vh[~np.isnan(vh)]
        if len(th) < 50 or len(vh) < 50:
            states[i], conf[i] = cur, 0.3
            continue
        t_th = np.quantile(th, 0.68)
        v_hi = np.quantile(vh, 0.75)
        v_cr = np.quantile(vh, 0.90)
        t, v = trend[i], vol[i]
        if np.isnan(t) or np.isnan(v):
            states[i], conf[i] = cur, 0.3
            continue
        t_lo, v_lo = t_th * 0.6, v_hi * 0.8

        if v >= v_cr and (np.isnan(ret20[i]) or ret20[i] < 0):
            cand, s = "HIGH_VOL", v
        elif v >= v_hi and abs(t) < t_th:
            cand, s = "HIGH_VOL", v
        elif t >= t_th and adx[i] >= 18:
            cand, s = "TREND_UP", t / t_th - 1
        elif t <= -t_th and adx[i] >= 18:
            cand, s = "TREND_DOWN", -t / t_th - 1
        elif ver in ("v1.1", "v1.2") and abs(t) < t_lo and v_lo <= v < v_hi:
            cand, s = "TRANSITION", 1 - abs(t) / (t_lo + 1e-12)
        else:
            cand, s = "RANGE_CALM", 1 - abs(t) / (t_th + 1e-12)

        if cand == cur:
            pending, pcnt = None, 0
            conf[i] = float(np.clip(0.5 + 0.25 * min(2, max(0, s)), 0, 1))
            strength[i] = s
        else:
            if pending == cand:
                pcnt += 1
            else:
                pending, pcnt = cand, 1
            if pcnt >= CONFIRM:
                cur, pending, pcnt = cand, None, 0
                conf[i] = float(np.clip(0.45 + 0.25 * min(2, max(0, s)), 0, 0.9))
                strength[i] = s
                switched[i] = True
            else:
                conf[i] = 0.4
                strength[i] = 0.4
        states[i] = cur

    if ver == "v1.2":
        base = {}
        for st in States.names():
            idx = np.where(states == st)[0]
            idx = idx[idx + H < n]
            if len(idx) < 50:
                base[st] = 0.5
                continue
            fwd = np.log(close[idx + H] / close[idx])
            fwd = fwd[~np.isnan(fwd)]
            if len(fwd) < 50:
                base[st] = 0.5
                continue
            tstat = abs(fwd.mean() / (fwd.std(ddof=1) / np.sqrt(len(fwd))))
            base[st] = float(np.clip(0.35 + min(tstat, 3.0) / 3.0 * 0.6, 0.35, 0.95))
        newconf = np.zeros(n)
        for i in range(n):
            bc = base.get(str(states[i]), 0.5)
            if np.isnan(strength[i]):
                newconf[i] = 0.3
                continue
            adj = np.clip((strength[i] - 0.5) * 0.12, -0.12, 0.12)
            newconf[i] = np.clip(bc + adj, 0.3, 0.95)
        newconf[switched] *= 0.9
        conf = np.clip(newconf, 0, 1)

    return states, conf, base


def main():
    df = load()
    X = build_features(df, bar=BAR)
    valid = X.dropna(subset=["ret_1", "vol_20", "trend_slope", "adx_14"]).index
    warm = int(valid[0])
    X = X.iloc[warm:].reset_index(drop=True)
    # close 不在特征表内, 从原始K线对齐取
    X["close"] = df["close"].values[warm:warm + len(X)]
    sc = make_scores(X)
    n = len(X)
    close = X["close"].values
    print(f"=== {BAR} walk-forward: {n} 根 bar, horizon={H}根(约{H*4/24:.0f}日) ===\n")

    out = {}
    for ver in ("v1.0", "v1.1", "v1.2"):
        out[ver] = wf_decode(X, sc, ver)

    # ---------- B3 标定值 vs 状态历史强度 ----------
    print("=== B3 各状态标定强度 (v1.2) ===")
    states, conf, base = out["v1.2"]
    print(f"  {'状态':>12} {'n':>6} {'|t|(H)':>8} {'标定conf':>9}")
    for s in States.names():
        idx = np.where(states == s)[0]
        idx = idx[idx + H < n]
        if len(idx) < 50:
            continue
        fwd = np.log(close[idx + H] / close[idx])
        fwd = fwd[~np.isnan(fwd)]
        ts = abs(fwd.mean() / (fwd.std(ddof=1) / np.sqrt(len(fwd))))
        print(f"  {s:>12} {len(idx):>6} {ts:>8.2f} {base.get(s,0.5):>9.3f}")

    # ---------- B1/B2 置信度 vs horizon 强度 ----------
    print("\n=== B1/B2 置信度与未来H根收益的关系 ===")
    idx = np.arange(n - H)
    fwd_all = np.log(close[idx + H] / close[idx])
    valid_f = ~np.isnan(fwd_all)
    for ver in ("v1.0", "v1.2"):
        st_, cf_, _ = out[ver]
        cv = cf_[idx][valid_f]
        fa = fwd_all[valid_f]
        # 用 |fwd| 作强度, 与 conf 求 spearman
        rho_abs = spearmanr(cv, np.abs(fa)).statistic
        # 用 |fwd| 的 t-like 归一 (除以自身波动) 作强度
        z = fa / fa.std()
        rho_z = spearmanr(cv, np.abs(z)).statistic
        print(f"\n  {ver}: Spearman(conf, |future return|) = {rho_abs:+.4f}")
        print(f"       Spearman(conf, |z-score|)        = {rho_z:+.4f}")
        q = pd.qcut(pd.Series(cv), 5, labels=False, duplicates="drop")
        print(f"       {'分位':>6} {'conf均值':>9} {'未来H收益|均值|bp':>18} {'未来H收益均值bp':>16}")
        for qq in sorted(pd.Series(q).dropna().unique()):
            m = (q == qq).values
            print(f"       Q{int(qq)+1:<5} {cv[m].mean():>8.3f} "
                  f"{np.abs(fa[m]).mean()*1e4:>17.1f} {fa[m].mean()*1e4:>15.1f}")

    # ---------- B4/B5 ----------
    print("\n=== B4/B5 占比与稳定性 ===")
    print(f"  {'版本':>8} {'TRANSITION%':>13} {'下一根一致%':>13} {'24h一致%':>11} {'平均段长':>9}")
    for ver in ("v1.0", "v1.1", "v1.2"):
        st_, cf_, _ = out[ver]
        trp = float(pd.Series(st_).eq("TRANSITION").mean() * 100)
        a1 = float((st_[:-1] == st_[1:]).mean() * 100)
        a6 = float((st_[:-6] == st_[6:]).mean() * 100)
        chg = np.r_[True, st_[1:] != st_[:-1]]
        seg = np.diff(np.where(chg)[0].tolist() + [len(st_)])
        print(f"  {ver:>8} {trp:>12.2f}% {a1:>12.2f}% {a6:>10.2f}% {seg.mean():>8.1f}")

    # ---------- 验收 ----------
    print("\n=== 验收结论 ===")
    st_, cf_, _ = out["v1.2"]
    idx = np.arange(n - H)
    fwd_all = np.log(close[idx + H] / close[idx])
    vf = ~np.isnan(fwd_all)
    cv = cf_[idx][vf]
    fa = fwd_all[vf]
    rho = spearmanr(cv, np.abs(fa / fa.std())).statistic
    q = pd.qcut(pd.Series(cv), 5, labels=False, duplicates="drop")
    lo = np.abs(fa[(q == q.min()).values]).mean()
    hi = np.abs(fa[(q == q.max()).values]).mean()
    trp = float(pd.Series(st_).eq("TRANSITION").mean() * 100)
    print(f"  B1 Spearman(conf, 未来强度) > 0.3 : {'PASS' if rho > 0.3 else 'FAIL'} ({rho:+.4f})")
    print(f"  B2 高分位强度 > 低分位           : {'PASS' if hi > lo else 'FAIL'} ({lo*1e4:.0f}bp -> {hi*1e4:.0f}bp)")
    print(f"  B4 TRANSITION 2%~15%             : {'PASS' if 2 <= trp <= 15 else 'FAIL'} ({trp:.2f}%)")


if __name__ == "__main__":
    main()
# -*- coding: utf-8 -*-
"""S2 研究引擎 v1.0 —— 震荡市均值回归策略回测 + S1 海龟对账基准.

================================================================================
版本: v1.0  日期: 2026-10-10
用途: strategy/meanrev 下所有 S2 研究的统一回测引擎。

【相对上一版】首版。

【口径契约 —— 与 S1 (海龟) 逐字一致, 改任何一项必须升版本并重新对账】
    成交价   = 信号 bar 的收盘价 (S1 已用 FMZ 日志逐笔验证: max|px-信号bar close|=0)
    手续费   = taker 0.05% 双边 (名义口径)          [对账模式]
               + 滑点 0.03% 双边 (名义口径)          [研究模式, 同 S1 成本恒等式]
    资金费   = 0.004%/8h 名义口径, 持仓期间按比例计提 (保守: 双向都付)
    张数     = floor(名义 / (ct_val*px) / lot) * lot, ct_val=0.1, lot=0.01
    权益     = 初始 30U 起复利; 开仓名义 = 权益 x LEV

【S1 对账基准】
    run_turtle() 复刻 turtle_4h_ETH_frozen 的 FMZ 语义:
      - don48/adx15/stop3/9%封顶, 信号在收盘 bar 确认, 成交于该 bar 收盘价
      - 吊灯止损: bar k 收盘后 stop=max(stop, high[k-1]-sd), 触发看 low[k], 平仓成交于 close[k]
      - 入场 bar 不做止损触发判定 (v1.1 F1 修复语义)
      - 止损离场后 block 直到信号变化; 信号离场后同 bar 允许反向重入 (回测同步成交)
    对账目标: 184 笔逐笔 (时间/方向/张数/价格/理由) + 每笔开仓时点权益。

【S2 均值回归语义 (本引擎新增)】
    入场: bar j 收盘确认信号, 成交于 close[j]
    出场 (bar k>=j+1 起逐根检查, 同 bar 内先查止损后查目标 —— 悲观序):
      目标价触及: 多头 high[k]>=target -> 成交于 max(target, open[k]) (跳空按开盘)
                 空头 low[k] <=target -> 成交于 min(target, open[k])
      硬止损:     多头 low[k] <= stop  -> 成交于 min(stop, open[k])
                 空头 high[k]>= stop  -> 成交于 max(stop, open[k])
      时间止损:   k-j >= max_bars -> 成交于 close[k]
      状态门控出场(可选): 状态离开允许集 -> 成交于 close[k]
    离场后冷却 1 根 bar 才允许再入场。
================================================================================
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

DATA_DIR = r"C:/Users/k6668/Desktop/market_regime/data"
S1_LOG = DATA_DIR + r"/strategy/S1_trade_log_fmz.csv"
S1_LOG_TURTLE_DIR = r"C:/Users/k6668/Desktop/market_regime/strategy/turtle"

# ---- 成本口径常量 (契约, 勿改) ----
FEE_TAKER = 0.0005        # taker 手续费, 单边, 名义口径
SLIP = 0.0003             # 滑点, 单边, 名义口径 (研究模式计, 对账模式不计)
FUND_8H = 0.00004         # 资金费 0.004%/8h, 名义口径
CT_VAL = 0.1              # ETH-USDT-SWAP 合约面值 0.1 ETH
LOT = 0.01                # 最小张数精度


# =============================================================================
# 数据加载
# =============================================================================
def load_ohlcv(bar: str = "4H") -> pd.DataFrame:
    df = pd.read_csv(f"{DATA_DIR}/okx/ETH-USDT-SWAP_{bar}.csv")
    df["dt"] = pd.to_datetime(df.ts, unit="ms", utc=True)
    return df.sort_values("ts").reset_index(drop=True)


def load_states(bar: str = "1H") -> pd.DataFrame:
    """market_regime 状态标注 (hybrid 共识), 因果: 行 t 的状态只用 <=t 的信息."""
    df = pd.read_csv(f"{DATA_DIR}/states/ETH-USDT-SWAP_{bar}_states.csv")
    return df.sort_values("ts").reset_index(drop=True)[
        ["ts", "state_hybrid", "state_rules", "confidence"]]


def states_for(df: pd.DataFrame, states_1h: pd.DataFrame) -> np.ndarray:
    """把 1H 状态对齐到任意周期 bar: 用与该 bar 同一时间戳的最后一根 1H 状态."""
    m = dict(zip(states_1h.ts, states_1h.state_hybrid))
    return np.array([m.get(t, "") for t in df.ts], dtype=object)


# =============================================================================
# 指标 (全部因果; ATR/ADX 与 turtle_4h_ETH_frozen 逐值一致)
# =============================================================================
def atr_wilder(h, l, c, n=14):
    """ewm(span=n, adjust=False), 首根 TR=h-l. 与冻结版文件逐值一致."""
    al = 2.0 / (n + 1.0)
    a, s = [], None
    for i in range(len(c)):
        t = h[i] - l[i] if i == 0 else max(h[i] - l[i], abs(h[i] - c[i - 1]),
                                           abs(l[i] - c[i - 1]))
        s = t if s is None else t * al + s * (1 - al)
        a.append(s)
    return a


def adx_wilder(h, l, c, n=14):
    """与冻结版文件逐值一致 (atrx 用 span-ewm, 平滑用 alpha=1/n)."""
    al_span, al = 2.0 / (n + 1.0), 1.0 / n
    trs, plus, minus = [], [], []
    for i in range(1, len(c)):
        upm, dnm = h[i] - h[i - 1], l[i - 1] - l[i]
        plus.append(upm if (upm > dnm and upm > 0) else 0.0)
        minus.append(dnm if (dnm > upm and dnm > 0) else 0.0)
        trs.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def _dx(sp, sm, ax):
        if ax == 0:
            return float("nan")
        pdi, mdi = 100 * sp / ax, 100 * sm / ax
        return float("nan") if (pdi + mdi) == 0 else 100 * abs(pdi - mdi) / (pdi + mdi)

    atrx = h[0] - l[0]
    sp = sm = 0.0
    out, adx = [float("nan")], float("nan")
    for i in range(len(trs)):
        atrx = trs[i] * al_span + atrx * (1 - al_span)
        sp = plus[i] * al + sp * (1 - al)
        sm = minus[i] * al + sm * (1 - al)
        dx = _dx(sp, sm, atrx)
        if dx == dx:
            adx = dx if adx != adx else dx * al + adx * (1 - al)
        out.append(adx)
    return out


def sma(x, n):
    return pd.Series(x).rolling(n).mean().values


def bollinger(c, n=20, k=2.0):
    s = pd.Series(c)
    mid = s.rolling(n).mean()
    sd = s.rolling(n).std(ddof=0)
    return mid.values, (mid + k * sd).values, (mid - k * sd).values


def rsi(c, n=2):
    """Wilder RSI."""
    s = pd.Series(c)
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    return out.fillna(50).values


def donchian_prev(h, l, n):
    """前 n 根 (不含当根) 的最高/最低 —— 海龟通道语义."""
    hh = pd.Series(h).rolling(n).max().shift(1).values
    ll = pd.Series(l).rolling(n).min().shift(1).values
    return hh, ll


# =============================================================================
# S1 海龟复刻 (对账基准)
# =============================================================================
def run_turtle(df: pd.DataFrame, lev: float, equity0: float = 30.0,
               don_n=48, don_exit=24, adx_min=15.0, stop_mult=3.0,
               max_stop_pct=0.09, fee=FEE_TAKER, funding=FUND_8H,
               slip: float = 0.0):
    """逐 bar 复刻 FMZ on_tick 语义. 返回 (trades, equity_curve)."""
    h, l, c = df.high.values, df.low.values, df.close.values
    ts = df.ts.values
    n_bars = len(df)
    atr = atr_wilder(h, l, c)
    adx_raw = adx_wilder(h, l, c)
    adx = [0.0 if v != v else v for v in adx_raw]

    # 唐奇安状态机 (与 don_turtle_state 逐行等价的增量版)
    pos_sig = 0
    sig = np.zeros(n_bars, dtype=int)

    def gate(a):
        return a >= adx_min

    warm = don_n + 150
    for i in range(n_bars):
        if i < don_n:
            sig[i] = pos_sig
            continue
        up = max(h[i - don_n:i])
        dn = min(l[i - don_n:i])
        upx = max(h[i - don_exit:i])
        dnx = min(l[i - don_exit:i])
        a = adx[i]
        g = gate(a)
        if pos_sig <= 0 and g and c[i] > up:
            pos_sig = 1
        elif pos_sig >= 0 and g and c[i] < dn:
            pos_sig = -1
        if pos_sig == 1 and c[i] < dnx:
            pos_sig = 0
        elif pos_sig == -1 and c[i] > upx:
            pos_sig = 0
        sig[i] = pos_sig

    eq = equity0
    equity_curve = np.full(n_bars, np.nan)
    trades: List[dict] = []
    d = 0            # 当前方向 1/-1/0
    qty = 0.0
    entry_px = 0.0
    stop = 0.0
    entry_j = -1
    blocked = False
    block_sig = 0

    for j in range(n_bars):
        # ---- 持仓管理 (新收盘 bar) ----
        if d != 0 and j > entry_j:
            sd = min(stop_mult * atr[j], max_stop_pct * c[j])
            if d > 0:
                stop = max(stop, h[j - 1] - sd)
                if l[j] <= stop:                      # 触发于 close[j] (FMZ 语义)
                    fill = c[j]
                    _close_turtle(trades, ts, j, d, qty, entry_px, fill, "stop", eq,
                                  fee, slip)
                    eq = trades[-1]["eq_after"]
                    d, qty = 0, 0.0
                    blocked, block_sig = True, sig[j]
            else:
                stop = min(stop, l[j - 1] + sd)
                if h[j] >= stop:
                    fill = c[j]
                    _close_turtle(trades, ts, j, d, qty, entry_px, fill, "stop", eq,
                                  fee, slip)
                    eq = trades[-1]["eq_after"]
                    d, qty = 0, 0.0
                    blocked, block_sig = True, sig[j]
            # 资金费计提 (持仓期间每根 bar 按时长比例)
            if d != 0:
                eq -= qty * CT_VAL * entry_px * funding * (4.0 / 8.0)
        elif d != 0 and j == entry_j:
            pass
        # ---- 信号对账 / 开仓 ----
        if blocked and sig[j] != block_sig:
            blocked = False
        if d != 0 and sig[j] != d:
            fill = c[j]
            _close_turtle(trades, ts, j, d, qty, entry_px, fill, "signal", eq, fee, slip)
            eq = trades[-1]["eq_after"]
            d, qty = 0, 0.0
        if d == 0 and sig[j] != 0 and not blocked and j >= warm:
            notional = eq * lev
            q = math.floor(notional / (CT_VAL * c[j]) / LOT) * LOT
            q = round(q, 8)
            if q > 0:
                dist = min(stop_mult * atr[j], max_stop_pct * c[j])
                d = sig[j]
                qty, entry_px = q, c[j]
                stop = c[j] - d * dist
                entry_j = j
                trades_open_eq(trades, ts, j, d, q, c[j], stop, eq)
        equity_curve[j] = eq if d == 0 else eq  # 已实现权益 (未含浮动)

    curve = pd.Series(equity_curve, index=df.dt)
    return trades, curve


def trades_open_eq(trades, ts, j, d, q, px, stop, eq):
    trades.append({"open_ts": ts[j], "dir": d, "qty": q, "entry": px,
                   "stop": stop, "eq_at_open": eq, "open_j": j})


def _close_turtle(trades, ts, j, d, qty, entry, fill, reason, eq, fee, slip):
    t = [t for t in trades if t.get("close_ts") is None][-1]
    gross = d * qty * CT_VAL * (fill - entry)
    cost = qty * CT_VAL * fill * (fee + slip) + qty * CT_VAL * entry * (fee + slip)
    pnl = gross - cost
    t.update(close_ts=ts[j], exit=fill, reason=reason, pnl=pnl,
             eq_after=eq + pnl)


# =============================================================================
# S1 日志解析 (对账目标)
# =============================================================================
OPEN_RE = re.compile(r"开仓 (多|空) ([\d.]+)张 @([\d.]+) stop=([\d.]+) \(权益([\d.]+)\)")
CLOSE_RE = re.compile(r"全平\((stop|signal)\) ([\d.]+)张")


def parse_s1_log(path: str) -> pd.DataFrame:
    rows = []
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    for ln in lines:
        parts = ln.split(",")
        if len(parts) < 8:
            continue
        ts_str, msg = parts[1], ",".join(parts[7:]).strip().strip('"')
        m = OPEN_RE.search(msg)
        if m:
            rows.append(dict(open_ts=pd.Timestamp(m.group(0) and ts_str),
                             dir=1 if m.group(1) == "多" else -1,
                             qty=float(m.group(2)), entry=float(m.group(3)),
                             stop=float(m.group(4)), eq_at_open=float(m.group(5))))
            continue
        m = CLOSE_RE.search(msg)
        if m:
            for r in reversed(rows):
                if "close_ts" not in r:
                    r.update(close_ts=pd.Timestamp(ts_str), reason=m.group(1),
                             close_qty=float(m.group(2)))
                    break
    df = pd.DataFrame(rows)
    df["open_ts"] = pd.to_datetime(df.open_ts)
    df["close_ts"] = pd.to_datetime(df.close_ts)
    return df.sort_values("open_ts").reset_index(drop=True)


def reconcile(engine_trades: List[dict], log_df: pd.DataFrame,
              tol_min: int = 0) -> dict:
    """逐笔对账: 时间/方向/张数/入场价/开仓权益."""
    et = pd.DataFrame([{**t,
                        "open_ts": pd.to_datetime(t["open_ts"], unit="ms", utc=True),
                        "close_ts": pd.to_datetime(t.get("close_ts", np.nan), unit="ms",
                                                   utc=True) if t.get("close_ts") else pd.NaT}
                       for t in engine_trades])
    n = min(len(et), len(log_df))
    res = dict(n_engine=len(et), n_log=len(log_df))
    if n == 0:
        return res
    e, g = et.iloc[:n].reset_index(drop=True), log_df.iloc[:n].reset_index(drop=True)
    tsm = pd.Timedelta(minutes=tol_min)
    res["open_time_match"] = float((e.open_ts - g.open_ts).abs().le(tsm).mean())
    res["dir_match"] = float((e.dir == g.dir).mean())
    res["qty_match"] = float((e.qty - g.qty).abs().le(1e-9).mean())
    res["qty_med_abs_diff"] = float((e.qty - g.qty).abs().median())
    res["entry_match"] = float((e.entry - g.entry).abs().le(0.005).mean())
    res["eq_med_rel_diff%"] = float(
        ((e.eq_at_open - g.eq_at_open).abs() / g.eq_at_open * 100).median())
    res["eq_match_1pct"] = float(
        ((e.eq_at_open - g.eq_at_open).abs() / g.eq_at_open <= 0.01).mean())
    # 首个失配位置
    bad = e.open_ts.subtract(g.open_ts).abs().gt(tsm) | (e.dir != g.dir)
    res["first_mismatch"] = int(bad.idxmax()) if bad.any() else -1
    return res


# =============================================================================
# S2 均值回归回测
# =============================================================================
@dataclass
class MRConfig:
    name: str = "bb20"
    bar: str = "4H"
    entry: str = "bb"            # bb / bb_rsi / donchian_rev
    bb_n: int = 20
    bb_k: float = 2.0
    rsi_n: int = 2
    rsi_lo: float = 10.0
    rsi_hi: float = 90.0
    don_n: int = 24              # donchian_rev 用
    target: str = "mid"          # mid / don_mid
    stop_mult: float = 2.0       # x ATR14, 0 = 无硬止损
    max_bars: int = 12           # 时间止损
    direction: str = "both"      # both / long_only
    gate: str = "RANGE_CALM"     # "" = 不门控; 逗号分隔多状态
    regime_exit: bool = False    # 状态离开允许集即离场
    lev: float = 1.0
    equity0: float = 30.0
    max_stop_pct: float = 0.06   # 止损距上限 6% (名义口径)


def run_mr(df: pd.DataFrame, state: np.ndarray, cfg: MRConfig,
           fee=FEE_TAKER, slip=SLIP, funding=FUND_8H):
    h, l, c, o = df.high.values, df.low.values, df.close.values, df.open.values
    ts = df.ts.values
    n = len(df)
    atr = atr_wilder(h, l, c, 14)
    hours = 4.0 if cfg.bar == "4H" else 1.0

    if cfg.entry in ("bb", "bb_rsi"):
        mid, ub, lb = bollinger(c, cfg.bb_n, cfg.bb_k)
        target_px = mid
        r = rsi(c, cfg.rsi_n) if cfg.entry == "bb_rsi" else None
    elif cfg.entry == "donchian_rev":
        hh, ll = donchian_prev(h, l, cfg.don_n)
        mid = (hh + ll) / 2.0
        ub, lb = hh, ll
        target_px = mid
        r = None
    else:
        raise ValueError(cfg.entry)

    allow = (set(x for x in cfg.gate.split(",") if x) if cfg.gate else None)

    eq = cfg.equity0
    trades: List[dict] = []
    d = 0
    qty = 0.0
    entry_px = stop = target = 0.0
    entry_j = -1
    cooldown_until = -1

    warm = max(cfg.bb_n, cfg.don_n) + 50
    for j in range(n):
        # ---------- 持仓管理 ----------
        if d != 0:
            # 资金费
            eq -= qty * CT_VAL * entry_px * funding * (hours / 8.0)
            k = j
            exited = False
            # 硬止损 (悲观序: 先于目标检查)
            if cfg.stop_mult > 0:
                if d > 0 and l[k] <= stop:
                    fill = min(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                elif d < 0 and h[k] >= stop:
                    fill = max(stop, o[k])
                    _mr_close(trades, ts, k, d, qty, entry_px, fill, "stop", eq, fee, slip)
                    eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and cfg.regime_exit and allow is not None and \
                    state[j - 1] not in allow and j - 1 > entry_j:
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "regime", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited:
                # 目标价
                tg = target_px[k]
                if tg == tg:
                    if d > 0 and h[k] >= tg:
                        fill = max(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
                    elif d < 0 and l[k] <= tg:
                        fill = min(tg, o[k])
                        _mr_close(trades, ts, k, d, qty, entry_px, fill, "target", eq, fee, slip)
                        eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if not exited and j - entry_j >= cfg.max_bars:
                _mr_close(trades, ts, k, d, qty, entry_px, c[k], "time", eq, fee, slip)
                eq = trades[-1]["eq_after"]; d, qty = 0, 0.0; exited = True
            if d == 0 and exited:
                cooldown_until = j + 1
        # ---------- 开仓 (收盘确认, 成交于 close[j]) ----------
        if d == 0 and j >= warm and j > cooldown_until:
            ok_state = (allow is None) or (state[j] in allow)
            if not ok_state or mid[j] != mid[j]:
                continue
            want = 0
            if cfg.entry == "bb":
                if c[j] < lb[j]:
                    want = 1
                elif c[j] > ub[j]:
                    want = -1
            elif cfg.entry == "bb_rsi":
                if c[j] < lb[j] and r[j] < cfg.rsi_lo:
                    want = 1
                elif c[j] > ub[j] and r[j] > cfg.rsi_hi:
                    want = -1
            elif cfg.entry == "donchian_rev":
                # 唐奇安回归: 收盘跌破前 n 根最低 -> 做多回归中轨
                if c[j] < ll[j]:
                    want = 1
                elif c[j] > hh[j]:
                    want = -1
            if want == -1 and cfg.direction == "long_only":
                want = 0
            if want != 0:
                notional = eq * cfg.lev
                q = round(math.floor(notional / (CT_VAL * c[j]) / LOT) * LOT, 8)
                if q > 0:
                    dist = min(cfg.stop_mult * atr[j], cfg.max_stop_pct * c[j]) \
                        if cfg.stop_mult > 0 else 0.0
                    d = want
                    qty, entry_px = q, c[j]
                    stop = c[j] - d * dist
                    entry_j = j
                    trades.append(dict(open_ts=ts[j], dir=d, qty=q, entry=c[j],
                                       eq_at_open=eq, stop=stop, open_j=j,
                                       atr=atr[j]))
    curve = _equity_curve_from_trades(trades, df)
    return trades, curve


def _mr_close(trades, ts, k, d, qty, entry, fill, reason, eq, fee, slip):
    t = [t for t in trades if t.get("close_ts") is None][-1]
    gross = d * qty * CT_VAL * (fill - entry)
    cost = qty * CT_VAL * (fill + entry) * (fee + slip)
    pnl = gross - cost
    t.update(close_ts=ts[k], exit=fill, reason=reason, pnl=pnl, eq_after=eq + pnl)


def _equity_curve_from_trades(trades, df):
    eq = 30.0 if not trades else trades[0]["eq_at_open"]
    curve = np.full(len(df), np.nan)
    cur = eq
    ti = 0
    n_tr = len(trades)
    for j in range(len(df)):
        tsj = df.ts.values[j]
        while ti < n_tr and trades[ti].get("close_ts") is not None and \
                trades[ti]["close_ts"] <= tsj:
            cur = trades[ti]["eq_after"]
            ti += 1
        curve[j] = cur
    return pd.Series(curve, index=df.dt)


# =============================================================================
# 绩效指标 (口径同 S1 绩效表)
# =============================================================================
def perf_stats(trades: List[dict], curve: pd.Series, lev: float,
               freq_per_year: float = 6 * 365) -> dict:
    if not trades or "close_ts" not in trades[0] or trades[0].get("close_ts") is None:
        return {}
    td = pd.DataFrame(trades)
    closed = td.dropna(subset=["close_ts"]).reset_index(drop=True)
    rets = closed.pnl / closed.eq_at_open          # 权益口径单笔收益
    eq_end = closed.eq_after.iloc[-1]
    years = (closed.close_ts.iloc[-1] - closed.open_ts.iloc[0]) / 1e9 / 86400 / 365.25
    cagr = (eq_end / 30.0) ** (1 / max(years, 1e-9)) - 1 if years > 0 else np.nan
    dd = (curve / curve.cummax() - 1).min()
    wins = closed[closed.pnl > 0]
    losses = closed[closed.pnl <= 0]
    pf = wins.pnl.sum() / abs(losses.pnl.sum()) if len(losses) and losses.pnl.sum() != 0 \
        else np.inf
    t_stat = rets.mean() / (rets.std(ddof=1) / np.sqrt(len(rets))) \
        if len(rets) > 2 and rets.std(ddof=1) > 0 else np.nan
    # 年度分解
    closed["year"] = pd.to_datetime(closed.close_ts, unit="ms", utc=True).dt.year
    yearly = {}
    eq_prev = 30.0
    for y, g in closed.groupby("year"):
        yearly[int(y)] = dict(n=len(g), ret_pct=float(g.eq_after.iloc[-1] / eq_prev - 1) * 100)
        eq_prev = g.eq_after.iloc[-1]
    # 水下时间
    under = (curve < curve.cummax()).mean()
    return dict(
        n=len(closed), win_pct=float((closed.pnl > 0).mean() * 100),
        avg_trade_eq_pct=float(rets.mean() * 100),
        med_trade_eq_pct=float(rets.median() * 100),
        t_stat=float(t_stat) if t_stat == t_stat else None,
        pf=float(pf), eq_end=float(eq_end),
        cagr_pct=float(cagr * 100), maxdd_pct=float(dd * 100),
        underwater_pct=float(under * 100),
        avg_hold_bars=float((closed.close_ts - closed.open_ts).mean() / 36e5 /
                            (4 if True else 1)),
        yearly=yearly,
    )
